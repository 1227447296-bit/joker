/* 第六篇的短篇演出规则；临时牌面不是永久解锁，也不是可反复刷取的抽奖。 */
const NightProvocation=(()=>{
 'use strict';
 const fresh=()=>({phase:'ready',ridicule:0,acts:[],phantom:null,outcome:null,notes:[]});
 const copy=x=>JSON.parse(JSON.stringify(x)),ids=['trick','yield','answer'];
 function note(a,t){a.notes.push(t);if(a.notes.length>12)a.notes.shift()}
 function init(s){if(!s.flags.provocation)s.flags.provocation={revision:1,scene:fresh()};return s.flags.provocation}
 function view(s){return {...copy(init(s).scene),clock:false}}
 function act(s,mode){const a=init(s).scene,r={redraw:true};
  if(mode==='prov-next'){if(a.phase!=='resolved')throw Error('先完成当前现场');return {next:a.outcome==='redirected'?'hAfter6':'hStopped6'}}
  if(mode==='prov-start'){if(a.phase!=='ready')throw Error('这场课堂已经开始');a.phase='running';note(a,'叶凌天站在已经标记的训练台旁。闻岑要求双方不得离开防护范围。');return r}
  if(a.phase!=='running')throw Error('请先开始课堂挑战');
  if(mode==='prov-trick'){if(a.acts.length)throw Error('这次表演不能反复刷取');a.acts.push('trick');a.ridicule=1;note(a,'你故意让硬币从指缝落下。有人笑了，掌心却没有回应。仅仅失手，还不足以解释变牌。');return r}
  if(mode==='prov-yield'){if(a.acts.join(',')!=='trick')throw Error('先完成这次失手');a.acts.push('yield');a.ridicule=2;note(a,'你不争辩。叶凌天说你只会装神弄鬼，笑声汇成一片。陌生的方块J突然浮起；这只是一次出现，不证明嘲讽越多牌越强。');a.phantom='D-J';return r}
  if(mode==='prov-answer'){if(a.acts.join(',')!=='trick,yield')throw Error('还没有出现可用的临时牌面');if(s.mp<46)throw Error('折径需要46精神力，可以请教员停止示范');s.mp-=46;a.acts.push('answer');a.outcome='redirected';a.phase='resolved';note(a,'消耗46精神力。你沿训练台与空防护墙的现有标记开启一次折径，让演示块落入通道。Joker随即恢复；不是绝对防御。');return {...r,cast:'D-J'}}
  if(mode==='prov-stop'){a.outcome='stopped';a.phase='resolved';note(a,'你叫停示范。闻岑收起器材，要求叶凌天停止针对同学；你没有为证明自己继续冒险。');return r}
  throw Error('当前没有这个操作');
 }
 function validate(s){const p=s.flags.provocation,visited=s.visited||[],current=/^h[A-Z]/.test(s.node),fail=()=>{throw Error('第六篇现场记录损坏')};if(!p){if(current||visited.some(id=>/^h[A-Z]/.test(id)))fail();return}
  const a=p.scene;if(p.revision!==1||!a||!['ready','running','resolved'].includes(a.phase)||!Array.isArray(a.acts)||a.acts.length>3||a.acts.some((x,i)=>x!==ids[i])||a.ridicule!==Math.min(a.acts.length,2)||a.phantom!==(a.acts.length>=2?'D-J':null)||!['redirected','stopped',null].includes(a.outcome)||!Array.isArray(a.notes)||a.notes.length>12||a.notes.some(t=>typeof t!=='string'||t.length>300))fail();
  if(!visited.includes('gEnd5')||!visited.includes('hMorning6')||!s.flags.term?.witness?.done||!current||!visited.includes(s.node))fail();
  if(a.phase==='ready'&&(a.acts.length||a.outcome)||a.phase==='running'&&(a.outcome||a.acts.length>2)||a.phase==='resolved'&&!a.outcome||a.outcome==='redirected'&&a.acts.length!==3||a.outcome==='stopped'&&a.acts.length===3)fail();
  if(s.node==='hMorning6'&&a.phase!=='ready'||s.node!=='hMorning6'&&!visited.includes('hChallenge6')||['hAfter6','hStopped6','hEnd6'].some(id=>visited.includes(id))&&a.phase!=='resolved')fail();
 }
 return {init,view,act,validate};
})();
