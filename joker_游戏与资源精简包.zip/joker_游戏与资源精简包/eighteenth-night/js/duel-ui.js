const NightDuelUI=(()=>{
 const names={watch:'观察你的动作',approach:'正在靠近',guard:'停住脚步，望着你的手',windup:'压低肩膀',lunge:'伸手扑取',recover:'扑空，正在收势'};
 function screen(s,h){const a=NightDuel.view(s),b=a.bout,privateScene=NightStory.nodes[s.node].kind==='private';const btn=(mode,label,target='',enabled=true)=>h.action(mode,label,target,enabled?'':'disabled');
  const results=a.results.map((r,i)=>`第${i+1}局：${r==='won'?'你摘到布带':'许照摘到布带'}`).join(' · ');
  let body;
  if(privateScene){body=`<div class="duel-private"><img id="duel-face" src="${NightCards.art(a.face)}" alt="周客私下查看的牌面"><div><h3>学生证只登记了梅花2。</h3><p>掌心却已经多了一张红桃。第一次变成它的原因，仍然没有答案。</p><p>${results}</p>${['JOKER','C-2','H-2'].map(id=>btn('duel-face',id==='JOKER'?'大王':id==='C-2'?'♣2 指路':'♥2 听心',id)).join('')}<p>这里只是翻看，不消耗精神力。</p>${btn('duel-end','结束第二篇 →')}</div></div>`;}
  else{const active=b.status==='running';body=`<div class="duel-top"><b>第${b.round}局 / 两次尝试</b><span id="duel-status">${b.status==='ready'?'尚未开始':b.status==='won'?'你摘到了布带':b.status==='lost'?'许照摘到了布带':'目标：靠近并摘下他的布带'}</span></div>
   <div class="duel-arena" data-status="${b.status}" data-phase="${b.phase}" aria-label="连续练习场，蓝色是周客，金色是许照"><div class="duel-floor"></div><div class="duel-boundary">软垫练习区 · 不许击打</div><div id="duel-lock" class="duel-lock" hidden></div><div id="duel-player" class="duelist player"><span class="reach"></span><i></i><b>你 · 周客</b><em>蓝带</em></div><div id="duel-opponent" class="duelist opponent"><span class="reach"></span><i></i><b>许照</b><em>金带</em></div></div>
   <p id="duel-tell" class="duel-tell" role="status"></p><div class="duel-readouts"><span id="duel-range"></span><span id="duel-dash-time"></span><span id="duel-grab-time"></span></div>
   <div class="duel-controls"><div class="duel-dpad" aria-label="移动方向">${btn('duel-move','↑','up',active)}${btn('duel-move','←','left',active)}${btn('duel-move','↓','down',active)}${btn('duel-move','→','right',active)}</div><div class="duel-hands">${btn('duel-dash','冲刺 · Shift','',active)}${btn('duel-grab','摘带 · 空格','',active)}</div></div>
   <p class="game-fine">方向键 / WASD 点按移动，可连续按；冲刺沿上次移动方向。压低肩膀时离开原位，扑空后靠近摘带。不是击打对手。</p>
   <div class="duel-skills">${btn('duel-guide','♣2 指路 · 4精神力','',active)}${s.known.includes('H-2')?btn('duel-listen','♥2 听心 · 4精神力','',active):''}<small>袖口遮住牌面。翻牌与心声只有你能看见。</small></div>
   <div class="duel-intel"><p id="duel-guide"></p><p id="duel-thought"></p></div>
   <div class="game-controls">${b.status==='ready'||b.status==='lost'?btn('duel-start',b.status==='lost'?'重试本局（恢复本局起始精神力）':'开始切磋'):''}${!active?btn('duel-slow',b.slow?'速度：慢速 · 切回标准':'切换慢速'):''}${['won','lost'].includes(b.status)?btn('duel-next',b.round===1?'记下结果，去场边休息 →':'接受本局结果，继续故事 →'):''}</div><p class="game-fine">${results||'普通走位也能赢；输赢都能继续故事，练习没有淘汰惩罚。'}</p>`;}
  return `<section class="academy-screen duel-screen"><div class="academy-heading"><div><div class="eyebrow">ONE REGISTERED CARD / PRIVATE FACES</div><h2>${privateScene?'宿舍 · 袖口里的另一张牌':'练习院 · 夺带'}</h2></div><span id="field-mp">精神力 ${s.mp}/${s.maxMp}</span></div><section class="academy-objective"><small>当前目标</small><h3>${privateScene?'回看两次切磋与掌心的牌':'摘下许照肩上的金色布带，守住自己的蓝带'}</h3><p>${privateScene?'学院没有重新检测你的牌。':'两人都空手。摘带要走到身边，再找他来不及收手的时机。'}</p><button data-action="title">保存并回到标题</button></section>${body}<aside class="academy-notes"><h3>刚刚发生</h3><div id="field-notes">${h.notesHTML(a)}</div></aside></section>`;
 }
 function live(s){const a=NightDuel.view(s),b=a.bout,$=id=>document.getElementById(id);if(!$('duel-player'))return;const arena=document.querySelector('.duel-arena');arena.dataset.phase=b.phase;arena.dataset.status=b.status;
  for(const [id,p] of [['duel-player',b.player],['duel-opponent',b.opponent],['duel-lock',b.lock]]){const el=$(id);el.style.left=p.x+'%';el.style.top=p.y+'%';}
  $('duel-lock').hidden=!(a.tell||b.phase==='lunge');const reach=$('duel-player').querySelector('.reach');reach.style.width=arena.clientWidth*.26+'px';reach.style.height=arena.clientHeight*.26+'px';$('duel-tell').textContent=b.status==='running'?'许照：'+names[b.phase]:b.status==='ready'?'开始前先看看方向与摘带按钮。':b.status==='won'?'你赢了这一局。可以带着实际结果继续。':'这一局许照拿到了布带。可以重试，也可以接受结果继续。';
  $('duel-range').textContent='距离 '+Math.round(a.distance)+' / 摘带需 ≤13';$('duel-dash-time').textContent=b.dash>0?'冲刺恢复 '+(b.dash/1000).toFixed(1)+'秒':'冲刺就绪';$('duel-grab-time').textContent=b.grab>0?'收手中':'摘带就绪';
  for(const [id,slot,label] of [['duel-guide','guide','♣ 眼前倾向'],['duel-thought','thought','♥ 此刻表层念头']]){const intel=b[slot],fresh=slot==='guide'?a.guideFresh:a.thoughtFresh;$(id).textContent=intel?label+'：'+intel.text+(fresh?'':'（动作已改变，此条已过时）'):label+'：尚未施术';$(id).classList.toggle('stale',!!intel&&!fresh);}
  for(const [mode,cool] of [['duel-dash',b.dash],['duel-grab',b.grab]]){const el=document.querySelector(`[data-mode="${mode}"]`);if(el)el.disabled=b.status!=='running'||cool>0;}
 }
 return {screen,live};
})();
