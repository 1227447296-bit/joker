/* 邀请赛：行动前固定预告，行动后结算；观察与无效尝试不会推进。 */
const NightMatch=(()=>{
 const W=7,H=5,blocks=[[3,1],[3,3]],items=[['opponent','雷恩',5,2,'♠'],['sealTop','北侧铜印',6,0,'◆'],['sealBottom','南侧铜印',6,4,'◆'],['home','交印台',0,2,'⚑'],['rope','沙袋拉索',2,1,'⌁'],['landing','沙袋落点',4,2,'◎'],['smoke','遮光帘机关',1,3,'▥'],['rail','金属地槽',4,3,'ϟ']];
 const distance=(x,y,u,v)=>Math.abs(x-u)+Math.abs(y-v);
 const inside=(x,y)=>Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&x<W&&y>=0&&y<H;
 const blocked=(x,y)=>blocks.some(p=>p[0]===x&&p[1]===y);
 function note(f,t){f.notes.push(t);if(f.notes.length>30)f.notes.shift()}
 function spend(s,id){const c=NightCards.card(id);if(!c?.implemented||!s.known.includes(id))throw Error('还未掌握这个印记');if(s.mp<c.cost)throw Error('精神力不足；普通移动、借用场地和夺印路线不消耗精神力');s.mp-=c.cost;if(!s.used.includes(id))s.used.push(id)}
 function plan(m){
  if(m.stun>0)return {kind:'recover',cells:[],text:'沙袋震住了雷恩：本次行动后他无法攻击。可趁机靠近夺分。'};
  if(m.recovery>0)return {kind:'recover',cells:[],text:'收刃空隙还可行动'+m.recovery+'次：可以先靠近，再「操作」雷恩夺1分。'};
  if(distance(m.x,m.y,m.ex,m.ey)<=2){const cells=[];for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(distance(x,y,m.ex,m.ey)<=1||(x===m.x&&y===m.y))cells.push([x,y]);return {kind:'slash',cells,text:'短刃突刺：你行动后，红格受到攻击。离开红格，再利用收刃空隙。'};}
  const next=[[m.ex-1,m.ey],[m.ex,m.ey-1],[m.ex,m.ey+1],[m.ex+1,m.ey]].filter(([x,y])=>inside(x,y)&&!blocked(x,y)&&(x!==m.x||y!==m.y)).sort((a,b)=>distance(a[0],a[1],m.x,m.y)-distance(b[0],b[1],m.x,m.y))[0];
  return {kind:'advance',cells:[],next:next||[m.ex,m.ey],text:'雷恩正逼近：这次只移动，不攻击。可调整位置或利用场地。'};
 }
 function start(s){const f=s.flags.field;if(!f?.done.includes('trial'))throw Error('先通过资格测试，才能进入正式比赛');if(f.arena)throw Error('先结束当前练习并返回日程');if(f.match)throw Error('比赛日已经开始');f.match={phase:'briefing',attempt:0,practice:false};f.slots=0;s.mp=s.maxMp;note(f,'你结束了赛前日程。翌日清晨，精神力恢复，裁判叫到你的名字。');return {}}
 function begin(s,practice=false){const f=s.flags.field,old=f.match;f.match={phase:'duel',attempt:(old.attempt||0)+1,practice,x:0,y:2,ex:5,ey:2,hp:3,guard:3,seals:[],turn:0,last:'none',recovery:0,stun:0,smoke:0,ropeUsed:false,smokeUsed:false,focus:false,exposed:false,blades:0,understanding:[],result:null,winBy:null};f.match.intent=plan(f.match);note(f,'裁判：三枚护身标记耗尽即判负；打掉对手三枚标记，或把两枚铜印带回交印台，即可获胜。');return {}}
 function objects(m){return items.filter(o=>!m.seals.includes(o[0])).map(o=>o[0]==='opponent'?[o[0],o[1],m.ex,m.ey,o[4]]:o)}
 function hidden(m,target){return m.smoke>0&&m.x<=2&&(target!=='opponent'||m.ex<=2)}
 function expose(s,id,target){if(id==='D-3')return;const f=s.flags.field,m=f.match;if(!hidden(m,target)){m.exposed=true;s.flags.matchExposed=true;note(f,'看台看见了未登记的'+NightCards.card(id).name+'。多花色疑点已记入赛后记录，不会因为重试而抹去。')}else note(f,'遮光帘挡住了看台视线。这次施法没有形成公开的第二花色记录。')}
 function learn(s){const f=s.flags.field,m=f.match;if(m.understanding.length>=2&&!s.known.includes('S-3')){s.known.push('S-3');note(f,'你理解了「近身凝刃」与「停止供给后消散」。大王留下新印记：♠3·刃造，消耗7精神力。')}}
 function inspect(s,target){const f=s.flags.field,m=f.match;if(target==='opponent'){if(!m.understanding.includes('shape'))m.understanding.push('shape');if(m.blades>0&&!m.understanding.includes('limit'))m.understanding.push('limit');note(f,m.blades?'刃锋不是被收回袖中，而是在收势时散掉了。它依赖持续供给，离手不能维持太远。':'雷恩掌中凝出一把短刃。他的威胁在近身，而不是隔着全场发射武器。等他完成一次出手后，再观察刃锋。');learn(s);return {}}
  const text={sealTop:'北侧铜印：靠近后选「操作」取走。集齐两枚，再回左侧交印台获胜。',sealBottom:'南侧铜印：拿印后不会立刻获胜，必须把两枚都带回交印台。',home:'交印台：集齐南北两枚铜印后，在相邻位置「操作」提交。夺印与击败对手是两条不同的赢法。',rope:'拉索控制中央偏右「◎沙袋落点」上方的沙袋。先走到拉索旁，等雷恩接近◎再操作；沙袋会打掉1枚标记并牵制他两次。',landing:'◎是沙袋落点。雷恩走到这里或旁边一格时，拉下左侧拉索可以击中他。拉索只可使用一次。',smoke:'靠近机关操作，放下左侧遮光帘，持续3次后续行动。你与施法目标都在左侧时，看台无法直接目击。雷恩仍可能看见，遮帘不等于消除所有证人。',rail:'金属地槽连着附近的潮湿地面。雷恩在它旁边时，电弧可沿槽传播，打掉2枚标记；在远处使用不会生效。'};
  if(!text[target])throw Error('请观察有名字的现场目标');note(f,text[target]);return {}}
 function finish(s,win,by){const f=s.flags.field,m=f.match;m.phase='result';m.result=win?'胜利':'落败';m.winBy=by;if(win&&!m.practice){if(!f.done.includes('matchWin'))f.done.push('matchWin');s.flags.matchMethod=by;}note(f,win?(by==='夺印'?'你将两枚铜印按在交印台上。裁判举旗：方块选手，夺印获胜！':'第三枚护身标记熄灭。雷恩收手，裁判宣布你获胜。'):'你的第三枚护身标记熄灭，裁判中止比赛。可重试，不会删除已有线索与印记。');return {}}
 function step(s){const f=s.flags.field,m=f.match;m.guard=Math.max(0,m.guard);if(m.guard<=0)return finish(s,true,'破防');const intent=m.intent;if(m.stun>0){m.stun--;m.last='recover';note(f,'雷恩被沙袋牵制，错过这次行动。')}else if(intent.kind==='advance'){if(intent.next[0]!==m.x||intent.next[1]!==m.y){[m.ex,m.ey]=intent.next;note(f,'雷恩向你逼近一步。')}else note(f,'你抢到他的预定落点，雷恩停步，准备近身出刃。');m.last='advance'}else if(intent.kind==='slash'){m.blades++;m.recovery=2;if(intent.cells.some(p=>p[0]===m.x&&p[1]===m.y)){const escape=m.focus&&[[m.x-1,m.y],[m.x+1,m.y],[m.x,m.y-1],[m.x,m.y+1]].find(([x,y])=>inside(x,y)&&!blocked(x,y)&&(x!==m.ex||y!==m.ey)&&!intent.cells.some(p=>p[0]===x&&p[1]===y));if(escape){[m.x,m.y]=escape;m.focus=false;note(f,'先前读到的意图让你提前侧身，避开了这次短刃。')}else{m.hp--;note(f,'短刃命中预告区域，你的护身标记-1。')}}else note(f,'短刃划过你刚才的位置，落空。');m.last='slash';}else{if(m.recovery>0)m.recovery--;m.last='recover';note(f,m.recovery?'雷恩仍在收刃，你还有一次靠近或夺分的空隙。':'雷恩完成收刃，准备重新逼近。')}
  m.turn++;if(m.smoke>0)m.smoke--;if(m.hp<=0)return finish(s,false,null);m.intent=plan(m);return {}}
 function after(s,mode,target){const f=s.flags.field,m=f.match;
  if(mode==='match-observe')return inspect(s,'opponent');
  if(['match-talk','match-ledger','match-medic'].includes(mode)){target=mode.slice(6);mode='interact';}
  if(mode==='match-retry'){if(m.result!=='落败'&&!m.practice)throw Error('这场已经获胜，使用切磋入口重玩即可');s.mp=s.maxMp;return begin(s,m.practice)}
  if(mode==='match-rematch'){if(!f.done.includes('matchWin'))throw Error('先完成正式比赛');s.mp=s.maxMp;return begin(s,true)}
  if(mode==='match-lobby'){m.phase='aftermath';return {}}
  if(mode==='inspect'&&target==='opponent')return inspect(s,target);
  if(mode!=='interact')throw Error('本场已结束，请选择赛后交流、重试或返回标题');
  if(target==='talk'){note(f,s.flags.matchExposed?'雷恩：你登记的不是方块吗？那一手我会记住。裁判也保留了异常记录。':'雷恩：你没跟我的刃硬拼。昨晚那批器材是临时换的，我也觉得不对。');m.talked=true;return {}}
  if(target==='ledger'){m.checked=true;note(f,f.clues.includes('archive')&&f.clues.includes('roster')?'交接单、领用记录和赛场铭牌的编号对上了。你确认有人借赛事运输档案，线索指向赛后器材室。':'你拿到器材室编号，但手中缺少完整交接证据，暂时只能把它当调查方向。');return {}}
  if(target==='medic'){if(m.healed)throw Error('已经接受过赛后恢复');s.mp=s.maxMp;m.healed=true;note(f,'医务员让你休息，精神力恢复；这不是修为增长。');return {}}
  throw Error('请点雷恩交谈、器材记录或医务处')
 }
 function act(s,mode,target){const f=s.flags.field,m=f.match;if(!m)throw Error('尚未进入比赛日');
  if(m.phase==='briefing'){if(mode!=='match-begin')throw Error('先阅读比赛规则，再点击「进入赛场」');return begin(s)}
  if(m.phase==='result'||m.phase==='aftermath')return after(s,mode,target);
  if(mode==='inspect')return inspect(s,target);
  if(mode==='match-abandon')return finish(s,false,null);
  if(mode==='move'||mode==='D-3'){const parts=String(target).split(',');const [x,y]=parts.map(Number);if(parts.length!==2||!inside(x,y)||blocked(x,y)||(x===m.ex&&y===m.ey))throw Error('请选择未被柱子或对手占据的空格');const d=distance(x,y,m.x,m.y);if(d===0)throw Error('你已在这里');if(mode==='move'&&d!==1)throw Error('普通移动只走相邻一格；远处请使用移步');if(mode==='D-3'){if(d>4)throw Error('移步最多跨4格，请先靠近');spend(s,mode)}m.x=x;m.y=y;note(f,mode==='D-3'?'你以登记的方块能力移到空位。':'你调整了站位。');return step(s)}
  if(mode==='match-wait'){note(f,'你稳住脚步，等待对手完成预告动作。');return step(s)}
  if(mode==='interact'){
   const object=objects(m).find(o=>o[0]===target);if(!object)throw Error('请指定现场目标');if(distance(m.x,m.y,object[2],object[3])>1)throw Error('还够不到；先移动到目标相邻一格，再操作');
   if(target==='opponent'){if(m.intent.kind!=='recover')throw Error('雷恩正在戒备。先躲过出手，再抓收刃空隙');m.guard--;note(f,'你抓住收刃空隙，触中雷恩的护身标记：对手-1。');}
   else if(target==='sealTop'||target==='sealBottom'){m.seals.push(target);note(f,'你拿到'+object[1]+'，已收集'+m.seals.length+'/2。带回左侧交印台才能获胜。');}
   else if(target==='home'){if(m.seals.length<2)throw Error('还需要集齐南北两枚铜印');return finish(s,true,'夺印')}
   else if(target==='rope'){if(m.ropeUsed)throw Error('沙袋已经落下');m.ropeUsed=true;if(distance(m.ex,m.ey,4,2)<=1){m.guard--;m.stun=2;note(f,'沙袋撞开雷恩的短刃！对手标记-1，接下来两次行动被牵制。');}else note(f,'沙袋落空。先前的落点不在雷恩附近，这次机关已用掉。');}
   else if(target==='smoke'){if(m.smokeUsed)throw Error('这道遮光帘本场已经用过');m.smokeUsed=true;m.smoke=4;note(f,'左侧遮光帘落下。接下来3次行动中，左侧施法可避开看台直接目击。');}
   else throw Error('这个目标只能观察，或尝试异能');
   return step(s)
  }
  if(mode==='S-2'&&(target==='opponent'||target==='rail')){if(distance(m.x,m.y,target==='rail'?4:m.ex,target==='rail'?3:m.ey)>3)throw Error('电弧距离不够，请靠近到3格以内');if(target==='rail'&&distance(m.ex,m.ey,4,3)>1)throw Error('雷恩还没靠近金属地槽，此时放电无法命中');spend(s,mode);expose(s,mode,target==='rail'?'opponent':target);const damage=target==='rail'?2:1;m.guard-=damage;note(f,target==='rail'?'电弧沿湿地金属槽跳向雷恩，对手标记-2！':'电弧击中雷恩，对手标记-1。');return step(s)}
  if(mode==='S-3'&&target==='opponent'){if(distance(m.x,m.y,m.ex,m.ey)>1)throw Error('刃造只能近身使用；先靠近雷恩');spend(s,mode);expose(s,mode,target);m.guard--;note(f,'Joker翻为黑桃3，短刃在你掌中成形：对手标记-1。');return step(s)}
  if(mode==='H-2'&&target==='opponent'){if(m.focus)throw Error('你已读到意图，先利用这次预判');if(distance(m.x,m.y,m.ex,m.ey)>3)throw Error('距离太远，听不清他的表层念头');spend(s,mode);expose(s,mode,target);m.focus=true;note(f,'你听见他决定刺向的方向。下一次被短刃命中时，若有相邻安全格，你会按预判侧身一次。');return step(s)}
  if(mode==='C-2'&&['home','sealTop','sealBottom'].includes(target)){spend(s,mode);expose(s,mode,target);note(f,m.seals.length===2?'两枚铜印齐了，眼前有利的目标是左侧交印台。':'眼前有利的方向是尚未拿到的铜印；不必击倒雷恩也能赢。');return step(s)}
  throw Error('这个能力不能作用于该目标；没有消耗精神力或行动')
 }
 function view(s){const f=s.flags.field,m=f.match;return {match:m,name:'邀请赛 · 雷恩',scene:'hall',objects:m.phase==='duel'?objects(m):[],width:W,height:H,blocks,hidden:m.phase==='duel'&&hidden(m,'opponent')}}
 function validate(m){if(!m)return;if(!['briefing','duel','result','aftermath'].includes(m.phase)||!Number.isInteger(m.attempt)||m.attempt<0||typeof m.practice!=='boolean')throw Error('比赛记录损坏');if(m.phase==='briefing')return;const integer=(n,lo,hi)=>Number.isInteger(n)&&n>=lo&&n<=hi;if(!inside(m.x,m.y)||!inside(m.ex,m.ey)||blocked(m.x,m.y)||blocked(m.ex,m.ey)||!integer(m.hp,0,3)||!integer(m.guard,0,3)||!integer(m.turn,0,100000)||!integer(m.recovery,0,2)||!integer(m.stun,0,2)||!integer(m.smoke,0,4)||!integer(m.blades,0,100000)||!Array.isArray(m.seals)||m.seals.length>2||new Set(m.seals).size!==m.seals.length||m.seals.some(id=>!['sealTop','sealBottom'].includes(id))||!Array.isArray(m.understanding)||m.understanding.length>2||m.understanding.some(id=>!['shape','limit'].includes(id))||!['ropeUsed','smokeUsed','focus','exposed'].every(k=>typeof m[k]==='boolean')||![null,'胜利','落败'].includes(m.result)||![null,'夺印','破防'].includes(m.winBy)||!m.intent||!['advance','slash','recover'].includes(m.intent.kind)||!Array.isArray(m.intent.cells)||m.intent.cells.length>35||m.intent.cells.some(p=>!Array.isArray(p)||p.length!==2||!inside(...p))||typeof m.intent.text!=='string'||(m.intent.kind==='advance'&&(!Array.isArray(m.intent.next)||m.intent.next.length!==2||!inside(...m.intent.next)||blocked(...m.intent.next))))throw Error('比赛记录损坏')}
 return {start,act,view,validate};
})();
