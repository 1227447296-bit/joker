/* Chapters 3–5: deterministic, DOM-free activities. Integration uses term:true nodes. */
const NightTerm=(()=>{
 'use strict';
 const docs=[
  {id:'register',title:'入室登记簿',tag:'登记原件',text:'17日 18:20 · 学生证授权复印件随附。经手栏只留了缩写。',date:'17th 18:20'},
  {id:'receipt',title:'门岗复写回执',tag:'门岗留底',text:'17日 18:42 · 同一授权号送达。碳纸压痕完整，不能据此确认实际经手人。',date:'17th 18:42'},
  {id:'index',title:'缺页目录与授权附件',tag:'目录对照',text:'缺页索引：梅花附录24。学生证授权复印件所列调阅项目也是 梅花附录24。相符只说明授权指向这份附件。',date:null}
 ];
 const places=[['门厅',15,20],['有顶走道',48,20],['服务台',82,20],['庭院',32,66],['发运点',70,66],['校内出口',87,90]];
 const edges=[[0,1],[0,3],[1,2],[1,3],[1,4],[2,4],[3,4],[3,5],[4,5]],route=[1,4,3,5];
 const statements=[
  {id:'voice',title:'走道传来的话',time:'18:35',type:'heard',text:'志愿者听到有人说「授权已经核过了」。他没有看到谁核验，也没有看到盖章。'},
  {id:'cart',title:'庭院里的推车',time:'18:40',type:'seen',text:'志愿者亲眼看到推车停在庭院，两件外观相近的档案包被并排放下；标签朝里，看不清编号。'},
  {id:'parcel',title:'发运台的封口',time:'18:42',type:'seen',text:'志愿者亲眼看到其中一包被送到发运台，封口线与交接前的照片不同；他不知道谁换过，也不能确认包内内容。'}
 ];
 const facts={archive:['register:17th 18:20','receipt:17th 18:42','missing:梅花附录24','authorization:梅花附录24','finding:discrepancy-not-crime-proof'],courier:['parcel:held-for-staff-check-not-guilt'],witness:['18:35:heard-authorization-claim','18:40:seen-courtyard-cart','18:42:seen-dispatch-seal','finding:identity-and-contents-unconfirmed']};
 const copy=x=>JSON.parse(JSON.stringify(x));
 const freshCourier=()=>({status:'planning',player:0,step:0,trace:[0],stop:null,outcome:null});
 function chapterOf(s){const n=NightStory.nodes[s.node];if(!n||!n.term)return null;return n.kind==='archive'?3:n.kind==='courier'?4:['witness','private'].includes(n.kind)?5:null}
 function init(s,chapter){const ch=chapter===undefined?chapterOf(s):chapter;if(![3,4,5].includes(ch))throw Error('未知的后续篇章');if(!s.flags.term)s.flags.term={revision:1,chapter:ch,notes:[],face:'JOKER',archive:null,courier:null,witness:null,evidence:{archive:[],courier:[],witness:[]},outcomes:{archive:null,courier:null,witness:null}};const a=s.flags.term;
  if(ch===4&&!a.archive?.done)throw Error('请先提交档案差异');if(ch===5&&!['staff','rendezvous'].includes(a.courier?.outcome))throw Error('请先留住档案包');
  a.chapter=Math.max(a.chapter,ch);if(ch===3&&!a.archive)a.archive={inspected:[],selected:[],done:false};if(ch===4&&!a.courier)a.courier=freshCourier();if(ch===5&&!a.witness)a.witness={inspected:[],chain:[],consent:false,done:false};return a;
 }
 function note(a,text){a.notes.push(text);if(a.notes.length>24)a.notes.shift()}
 const adjacent=(a,b)=>edges.some(e=>e.includes(a)&&e.includes(b));
 function view(s){const a=init(s);return {...copy(a),kind:NightStory.nodes[s.node].kind,clock:false,docs:copy(docs),places:copy(places),edges:copy(edges),statements:copy(statements),courierAt:a.courier?route[a.courier.step]:null,courierNext:a.courier?route[Math.min(3,a.courier.step+1)]:null}}
 function finish(a,kind,outcome,text){a.outcomes[kind]=outcome;a.evidence[kind]=facts[kind].slice();note(a,text)}
 function spend(s,id){if(!s.known.includes(id)||s.mp<4)throw Error('需要已显现的牌面与4点精神力');s.mp-=4;if(!s.used.includes(id))s.used.push(id)}
 function act(s,mode,target=''){const ch=chapterOf(s);if(ch===null)throw Error('当前不是后续篇章现场');const a=init(s,ch),kind=NightStory.nodes[s.node].kind,r={redraw:true};
  if(mode==='term-next'){const next={archive:'gArchiveAfter',courier:'gCourierAfter',witness:'gWitnessAfter',private:'gEnd5'};if(kind==='archive'&&!a.archive.done||kind==='courier'&&!a.courier.outcome||kind==='witness'&&!a.witness.done||kind==='private'&&!a.witness.done)throw Error('请先完成当前记录');return {next:next[kind]}}
  if(mode==='term-face'&&kind==='private'){if(!['JOKER',...s.known].includes(target)||!['JOKER','C-2','H-2'].includes(target))throw Error('未知牌面');a.face=target;return r}
  if(mode==='term-consent'&&kind==='witness'&&!a.witness.done){a.witness.consent=true;note(a,'近旁志愿者明确同意：只感知此刻最强的一点念头，可以随时停止。');return r}
  if(mode==='term-guide'||mode==='term-listen'){
   if(kind==='private'||kind==='archive'&&a.archive.done||kind==='courier'&&a.courier.status!=='planning'||kind==='witness'&&a.witness.done)throw Error('这里不需要施术');
   const heart=mode==='term-listen';if(heart&&(kind!=='witness'||!a.witness.consent))throw Error('听心仅用于近旁明确同意的志愿者');const id=heart?'H-2':'C-2';spend(s,id);
   note(a,heart?'私人感知，不作证据：他此刻担心，把听见的话写成亲眼所见会害错人。':kind==='archive'?'梅花只指眼前一步：先把登记簿与门岗留底并排，不急着指认人。':kind==='courier'?'梅花只指眼前一步：看下一站；到服务台可请工作人员留包，别追出校外。':'梅花只指眼前一步：先读最早那张卡，分清听到一句话与看到核验。');return {...r,cast:id};
  }
  if(kind==='archive'){
   const x=a.archive;if(x.done)throw Error('档案差异已提交');
   if(mode==='term-inspect'){if(!docs.some(d=>d.id===target))throw Error('未知文书');if(!x.inspected.includes(target))x.inspected.push(target);note(a,docs.find(d=>d.id===target).text);return r}
   if(mode==='term-mark'){if(!x.inspected.includes(target))throw Error('请先翻阅这份文书');if(x.selected.includes(target))x.selected=x.selected.filter(t=>t!==target);else if(x.selected.length<2)x.selected.push(target);else note(a,'对照夹只能放两份：先取消一份再标记。');return r}
   if(mode==='term-compare'){if(x.inspected.length!==3){note(a,'还缺目录核对：请读完三份来源，再提交差异。');return r}if(x.selected.length!==2||!['register','receipt'].every(id=>x.selected.includes(id))){note(a,'目录指出调阅对象，不是第二个时间。请对照同一授权号的入室登记时间与门岗回执时间。没有扣费。');return r}x.done=true;finish(a,'archive','discrepancy','已记录：17日18:20与18:42不符；梅花附录24与复印授权相符。这是待核查差异，不是犯罪证明。');return r}
  }
  if(kind==='courier'){
   const c=a.courier;
   if(mode==='term-restart'){if(c.outcome)throw Error('包件已由工作人员留存，不能撤销交接');a.courier=freshCourier();note(a,'免费回到原路线起点；施术消耗不返还，不会生成重复证据。');return r}
   if(c.status!=='planning')throw Error('这次路线已结束；错过可以免费重新规划');
   if(mode==='term-desk'){if(c.player!==2)throw Error('先走到服务台');c.stop='desk';c.status='held';c.outcome='staff';finish(a,'courier','staff','你请服务台联系发运员留包核对。包件安全留在校内，是否有人调换仍由工作人员查验。');return r}
   if(mode==='term-move'){if(!/^[0-5]$/.test(String(target)))throw Error('未知地点');const to=Number(target);if(!adjacent(c.player,to))throw Error('只能沿连线走到相邻地点');if(c.trace.length>=8)throw Error('请重新规划');c.player=to;c.trace.push(to);c.step=Math.min(3,c.step+1);if(c.player===route[c.step]){c.status='held';c.stop='meeting';c.outcome='rendezvous';finish(a,'courier','rendezvous','你在同一站会合，出示盖教员印的停发核验单，请递送员与工作人员一起核对封签。留包不等于证明递送员有罪。')}else if(c.step===3){c.status='missed';note(a,'递送员到了出口；你没有追出校外。免费重排路线，或尝试从服务台联系工作人员。')}else note(a,'你到达'+places[to][0]+'，递送员随后到达'+places[route[c.step]][0]+'。只有移动会推进一站。');return r}
  }
  if(kind==='witness'){
   const w=a.witness;if(w.done)throw Error('时间线已提交');
   if(mode==='term-inspect'){if(!statements.some(t=>t.id===target))throw Error('未知证言');if(!w.inspected.includes(target))w.inspected.push(target);note(a,statements.find(t=>t.id===target).text);return r}
   if(mode==='term-chain-clear'){w.chain=[];return r}
   if(mode==='term-chain'){const [id,type]=String(target).split(':');if(!w.inspected.includes(id)||!['heard','seen'].includes(type)||String(target)!==id+':'+type)throw Error('先读证言，再标注来源');if(w.chain.some(t=>t.id===id)){note(a,'这张卡已在链中；清空后可重排。');return r}if(w.chain.length<3)w.chain.push({id,type});return r}
   if(mode==='term-reconstruct'){if(w.inspected.length!==3||w.chain.length!==3){note(a,'先翻阅三张卡，将每张按时间放入链中，并标明听说或目击。');return r}const wrong=w.chain.findIndex((t,i)=>t.id!==statements[i].id||t.type!==statements[i].type);if(wrong>=0){const t=w.chain[wrong],d=statements.find(t2=>t2.id===t.id);note(a,t.type!==d.type?d.title+'：'+(d.type==='heard'?'只听到有人声称核验，没看见核验动作。':'这是他亲眼所见，不是转述；但所见不能推出谁换包。'):'第'+(wrong+1)+'格时间不符：按18:35、18:40、18:42排列。清空可免费重建。');return r}w.done=true;finish(a,'witness','qualified-chain','已形成带来源的链：听到授权声称 → 目击庭院推车 → 目击发运封口变化。仅凭证人所见，不能推出操作者身份、当时包内内容或犯罪结论。');return r}
  }
  throw Error('当前没有这个操作');
 }
 function validate(s){const a=s.flags.term,ch=chapterOf(s),fail=()=>{throw Error('后续篇章现场记录损坏')},obj=x=>x&&typeof x==='object'&&!Array.isArray(x),same=(x,y)=>JSON.stringify(x)===JSON.stringify(y),subset=(x,ids,max)=>Array.isArray(x)&&x.length<=max&&new Set(x).size===x.length&&x.every(v=>ids.includes(v));
  const visited=s.visited||[],isTerm=id=>/^g[A-Z]/.test(id),chapters={3:['gMorning3','gOffice3','gArchive','gArchiveAfter','gEnd3'],4:['gMorning4','gCourier','gCourierAfter','gEnd4'],5:['gMorning5','gWitness','gWitnessAfter','gNight5','gPrivate','gEnd5','hMorning6','hChallenge6','hAfter6','hStopped6','hEnd6']};
  if(!a){if(isTerm(s.node)||visited.some(isTerm))fail();return}
  if(!obj(a)||a.revision!==1||![3,4,5].includes(a.chapter)||!subset([a.face],['JOKER',...s.known].filter(id=>['JOKER','C-2','H-2'].includes(id)),1)||!Array.isArray(a.notes)||a.notes.length>24||a.notes.some(t=>typeof t!=='string'||t.length>500)||!obj(a.evidence)||!obj(a.outcomes)||ch!==null&&a.chapter!==ch)fail();
  if(!obj(a.archive)||!subset(a.archive.inspected,['register','receipt','index'],3)||!subset(a.archive.selected,a.archive.inspected,2)||typeof a.archive.done!=='boolean')fail();
  if(a.archive.done&&(a.archive.inspected.length!==3||a.archive.selected.length!==2||!['register','receipt'].every(id=>a.archive.selected.includes(id))))fail();
  if(a.chapter===3&&a.courier!==null||a.chapter<5&&a.witness!==null)fail();
  if(a.chapter>=4&&(!a.archive.done||!obj(a.courier)))fail();
  if(a.courier){const c=a.courier;if(!['planning','held','missed'].includes(c.status)||!Number.isInteger(c.player)||c.player<0||c.player>5||!Number.isInteger(c.step)||c.step<0||c.step>3||!Array.isArray(c.trace)||c.trace.length!==c.step+1||c.trace[0]!==0||c.trace.some(n=>!Number.isInteger(n)||n<0||n>5)||c.player!==c.trace[c.trace.length-1])fail();
   for(let i=1;i<c.trace.length;i++)if(!adjacent(c.trace[i-1],c.trace[i])||i<c.step&&c.trace[i]===route[i])fail();
   const meeting=c.player===route[c.step];if(c.status==='held'){if(c.outcome==='staff'){if(c.stop!=='desk'||c.player!==2||meeting||c.step>=3)fail()}else if(c.outcome==='rendezvous'){if(c.stop!=='meeting'||!meeting||c.step===0)fail()}else fail()}else if(c.stop!==null||c.outcome!==null||meeting||c.status!==(c.step===3?'missed':'planning'))fail();
  }
  if(a.chapter>=5&&(!a.courier.outcome||!obj(a.witness)))fail();
  if(a.witness){const w=a.witness;if(!subset(w.inspected,statements.map(t=>t.id),3)||typeof w.consent!=='boolean'||typeof w.done!=='boolean'||!Array.isArray(w.chain)||w.chain.length>3||new Set(w.chain.map(t=>t&&t.id)).size!==w.chain.length||w.chain.some(t=>!obj(t)||!w.inspected.includes(t.id)||!['heard','seen'].includes(t.type)))fail();if(w.done&&(w.inspected.length!==3||!same(w.chain,statements.map(t=>({id:t.id,type:t.type})))))fail()}
  const expected={archive:a.archive.done?'discrepancy':null,courier:a.courier?.outcome||null,witness:a.witness?.done?'qualified-chain':null};if(!same(Object.keys(a.evidence).sort(),['archive','courier','witness'])||!same(Object.keys(a.outcomes).sort(),['archive','courier','witness']))fail();for(const k of Object.keys(expected))if(a.outcomes[k]!==expected[k]||!same(a.evidence[k],expected[k]?facts[k]:[]))fail();
  if(!visited.includes('fEnd')||!visited.includes('gMorning3')||!chapters[a.chapter].includes(s.node)||!visited.includes(s.node))fail();
  for(const n of [4,5]){const entered=visited.includes('gMorning'+n);if(entered!==(a.chapter>=n)||entered&&!visited.includes('gEnd'+(n-1)))fail();if(visited.some(id=>chapters[n].includes(id))&&!entered)fail()}
  if(!visited.includes('gArchive')&&(a.archive.inspected.length||a.archive.selected.length||a.archive.done))fail();
  if(a.courier&&!visited.includes('gCourier')&&!same(a.courier,freshCourier()))fail();
  if(a.witness&&!visited.includes('gWitness')&&(a.witness.inspected.length||a.witness.chain.length||a.witness.consent||a.witness.done))fail();
  if(['gArchiveAfter','gEnd3'].some(id=>visited.includes(id))&&!a.archive.done||['gCourierAfter','gEnd4'].some(id=>visited.includes(id))&&!a.courier?.outcome||['gWitnessAfter','gNight5','gPrivate','gEnd5'].some(id=>visited.includes(id))&&!a.witness?.done)fail();
 }
 return {init,view,act,validate};
})();
