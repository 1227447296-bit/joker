/* 第二篇纯规则：逻辑时钟、协作机关、目标心声与安全复位。 */
const NightCampus=(()=>{
 const kinds=['pack','lesson','practice','survey','listen','rescue','private'];
 const objects={brace:'支架仍在晃动。靠控制室一侧有空支撑槽，另一槽被变形件占住。',rope:'应急索连着侧门，不是吊装整座支架的绳子。门开启后会缓慢回位。',grille:'隔栅后有人回应，是近处的林见微。这里不是可以钻过去的出口。'};
 function init(s){if(!s.flags.campus)s.flags.campus={notes:[],packed:[],lesson:false,lessonTries:0,contact:false,seen:[],listened:false,asked:false,rested:false,mind:'',hints:[],face:'JOKER',practice:{stage:0,running:false,elapsed:0,gate:0,bridge:0,helper:false,travel:0,phase:'ready',mistakes:0,slow:false},rescue:{phase:'brace',balance:25,target:65,preparing:false,prep:0,ready:false,door:0,progress:0,latch:false,retries:0,slow:false}};return s.flags.campus}
 const note=(a,t)=>{a.notes.push(t);if(a.notes.length>24)a.notes.shift()};
 function spend(s,id){const c=NightCards.card(id);if(!c||!s.known.includes(id))throw Error('这个牌面尚未显现');if(s.mp<c.cost)throw Error('精神力不足，可以继续观察、沟通与普通操作');s.mp-=c.cost;if(!s.used.includes(id))s.used.push(id);init(s).face=id}
 function positions(p){return {gate:p.helper||p.gate>0?50:50+45*Math.sin(p.elapsed/1100),bridge:p.bridge>0?50:50+45*Math.sin(p.elapsed/1500+1.8)}}
 function view(s){const a=init(s),kind=NightStory.nodes[s.node].kind;return {kind,...a,positions:positions(a.practice),clock:kind==='practice'&&a.practice.running||kind==='rescue'&&a.rescue.phase==='door'&&(a.rescue.preparing||a.rescue.door>0)}}
 function retryRescue(a,text){const r=a.rescue;r.preparing=false;r.prep=0;r.ready=false;r.door=0;r.progress=0;r.retries++;note(a,text+' 没有人受伤，调整好后可重新协调。')}
 function pulse(s,a,dt){if(!Number.isFinite(dt)||dt<=0||dt>100)throw Error('无效的小游戏时钟');const kind=NightStory.nodes[s.node].kind;
  if(kind==='practice'){const p=a.practice;if(!p.running)return {};const step=dt*(p.slow?.65:1);p.elapsed=(p.elapsed+step)%120000;
   if(p.phase==='moving'){
    if((p.stage!==1&&!p.helper&&p.gate<=0)||(p.stage!==0&&p.bridge<=0)){p.phase='failed';p.running=false;p.mistakes++;note(a,'机关先复位了，假人落入安全网。请留足通行时间，重试当前段。');return {redraw:true}}
    p.travel+=step;if(p.travel>=1200){p.stage++;p.running=false;p.phase=p.stage===3?'passed':'ready';p.travel=0;p.gate=0;p.bridge=0;p.helper=false;note(a,p.stage===3?'三段完成。许照拍了拍假人：送到了。下次换你推我们。':'这一段通过。下一段的机关会增加变化，准备好再开始。');return {redraw:true}}
   }
   p.gate=Math.max(0,p.gate-step);p.bridge=Math.max(0,p.bridge-step);return {live:true}
  }
  if(kind==='rescue'){const r=a.rescue;if(r.phase!=='door')return {};const step=dt*(r.slow?.65:1);
   if(r.preparing&&!r.ready){r.prep=Math.min(1600,r.prep+step);if(r.prep>=1600){r.ready=true;r.preparing=false;note(a,'林见微：我站稳了。现在开门，我自己走。')}}
   if(r.door>0){if(r.ready)r.progress=Math.min(100,r.progress+step/28);r.door=Math.max(0,r.door-step);if(r.progress>=100){r.phase='done';r.door=0;note(a,'她穿过侧门。检修人员接手现场，闻岑让两人去医务室检查。');return {redraw:true}}if(r.door===0){retryRescue(a,'门已回位。刚才开得太早，没留够她通行的时间。');return {redraw:true}}}return {live:true}
  }return {}
 }
 function act(s,mode,target){const a=init(s),kind=NightStory.nodes[s.node].kind;if(!kinds.includes(kind))throw Error('当前不是第二篇现场');if(mode==='pulse')return pulse(s,a,target);
  if(mode==='campus-guide'){
   const p=a.practice,r=a.rescue,key=kind==='practice'?'practice'+p.stage:kind==='rescue'?'rescue'+r.phase:kind;if(!['practice','survey','rescue'].includes(kind))throw Error('这里先观察和沟通');if(a.hints.includes(key))throw Error('这一阶段的方向已记录，不必重复施法');spend(s,'C-2');a.hints.push(key);
   note(a,kind==='practice'?'梅花倾向：先等桥接近对齐位置，再固定机关；也可以请许照帮忙延长制动。':kind==='survey'?'梅花倾向：先查看支架的空支撑槽。它没有告诉你隔栅后的人在想什么。':r.phase==='brace'?'眼前较有利的是空槽，不是被变形件占住的槽。':r.phase==='balance'?'先让横杆回到标出的稳定区，再请她确认。':'先确认她准备好，再开门；也可先装手动卡扣延长开门时间。');return {cast:'C-2',redraw:true}
  }
  if(kind==='pack'){
   if(mode==='pack-item'){if(!['id','schedule','book'].includes(target))throw Error('请选择桌上物品');if(!a.packed.includes(target)){a.packed.push(target);note(a,{id:'学生证：周客，梅花2，铜级。脑海里的声音没有写进任何一栏。',schedule:'东教学楼公共基础课。梅花课程安排待教务复核。',book:'你在第一页写下「指路」，又补了两个字：一步。'}[target])}return {redraw:true}}
   if(mode==='pack-leave'){if(a.packed.length!==3)throw Error('先带好三件物品');return {next:'cClass'}}
  }
  if(kind==='lesson'){
   if(mode==='lesson-goal'){if(!['map','future','read'].includes(target))throw Error('先选一个明确目标');a.lessonTries++;if(target==='map'){a.lesson=true;note(a,'周客：可我刚看见地图在哪个信封。闻岑：所以这次不用花精神力，能看清的事不必再证明一次。')}else note(a,target==='future'?'闻岑：眼前的信封不能承担一学期的结果。把目标缩小到现在能做的一件事。':'闻岑：读取信封全部内容，不等于判断眼前哪个选择有利。梅花2不是读字术。');return {redraw:true}}
   if(mode==='lesson-next'){if(!a.lesson)throw Error('先完成具体目标练习');return {next:'cDemo'}}
  }
  if(kind==='practice'){
   const p=a.practice;
   if(mode==='practice-next'){if(p.stage!==3)throw Error('先完成三段协作');return {next:'cAfter'}}
   if(mode==='practice-slow'){if(p.running)throw Error('本段开始前才能切换速度');p.slow=!p.slow;return {redraw:true}}
   if(mode==='practice-start'){if(p.stage===3||p.running)throw Error('当前不能重新开始');p.running=true;p.phase='working';p.gate=0;p.bridge=0;p.helper=false;p.travel=0;note(a,'先观察标线与运动，再准备机关。通行需要完整的1.2秒。');return {redraw:true}}
   if(!p.running||p.phase!=='working')throw Error('先开始练习；运送途中不能调整机关');
   if(mode==='practice-helper'){if(p.stage!==2)throw Error('第三段才需要分工');p.helper=!p.helper;note(a,p.helper?'许照接住制动杆，挡板持续固定。剩下的桥与运送台由你控制。':'许照松开手动杆，挡板重新转动。');return {redraw:true}}
   if(mode==='practice-gate'||mode==='practice-bridge'){const pos=positions(p),gate=mode==='practice-gate';if(gate&&p.stage===1||!gate&&p.stage===0)throw Error('这一段没有使用这个机关');if(Math.abs((gate?pos.gate:pos.bridge)-50)>18){note(a,'还没对齐标出的通道区，机关没有锁住。等它靠近中间再试，不扣精神力。');return {redraw:true}}if(gate)p.gate=2600;else p.bridge=p.slow?3600:2400;note(a,gate?'挡板已制动，注意剩余维持时间。':'短桥已降下，注意剩余维持时间。');return {redraw:true}}
   if(mode==='practice-send'){if(p.stage!==1&&!p.helper&&p.gate<1200||p.stage!==0&&p.bridge<1200){note(a,'还没有足够的稳定通行时间。先准备机关，也可以让已经锁住的机关复位后再试。');return {redraw:true}}p.phase='moving';p.travel=0;return {redraw:true}}
  }
  if(kind==='survey'){
   if(mode==='survey-contact'){if(!a.contact){a.contact=true;note(a,'闻岑：留在安全侧，不要钻门框。我已经叫检修从外面接她。先确认她不在门的行程里，再协助开门。')}return {redraw:true}}
   if(mode==='survey-look'){if(!Object.hasOwn(objects,target))throw Error('请选择可见物件');if(!a.seen.includes(target))a.seen.push(target);note(a,objects[target]);return {redraw:true}}
   if(mode==='survey-next'){if(!a.contact||a.seen.length<3)throw Error('先联络教员，并检查三处可见物件');return {next:'cCopy'}}
  }
  if(kind==='listen'||kind==='rescue'){
   if(mode==='listen-rest'){if(kind!=='listen'||s.mp>=4||a.rested||a.listened)throw Error('当前不需要恢复');a.rested=true;s.mp=4;note(a,'你留在安全小室稳住呼吸，恢复到足够施放一次听心的4精神力，不增加上限。');return {redraw:true}}
   if(mode==='listen-cast'){
    const key=kind==='listen'?(a.asked?'asked':'fear'):(a.rescue.phase==='door'?(a.rescue.ready?'door-ready':'door-wait'):a.rescue.phase);
    if(!a.contact||!a.seen.includes('grille'))throw Error('先确认近处的目标');
    if(a.hints.includes('mind-'+key)){note(a,'你回想刚才听见的那句话，没有重新施法。');return {redraw:true}}
    spend(s,'H-2');a.hints.push('mind-'+key);a.listened=true;a.mind=key==='fear'?'别再掉下来。':key==='asked'||key==='balance'?'够得到。但我一换手，它会不会又沉？':key==='door-wait'?'先等我站稳。现在还不能走。':key==='door-ready'?'站稳了。这次我自己走，你把门留着就好。':'别再掉下来。她想的不是整条逃生路线，只是眼前晃动的横杆。';note(a,'听见的是林见微此刻的念头，不是客观预言。');return {cast:'H-2',redraw:true}
   }
   if(kind==='listen'&&mode==='listen-ask'){if(!a.listened)throw Error('先尝试这次新显现的听心');a.asked=true;note(a,'周客：上面有东西在松动？林见微：不是头顶，是我抓着的横杆。我不敢换手。你终于核实了那句恐惧指向什么。');return {redraw:true}}
   if(kind==='listen'&&mode==='listen-next'){if(!a.listened||!a.asked)throw Error('先听心，再和她核实具体情况');return {next:'cRescue'}}
  }
  if(kind==='rescue'){
   const r=a.rescue;
   if(mode==='rescue-slow'){if(r.door>0||r.preparing)throw Error('先等当前动作结束再切换速度');r.slow=!r.slow;return {redraw:true}}
   if(mode==='rescue-brace'){if(r.phase!=='brace'||!['empty','blocked'].includes(target))throw Error('当前不能安装撑杆');if(target==='blocked'){note(a,'撑杆碰到变形件，无法装入。空出的槽在另一边，没有造成损伤。');return {redraw:true}}r.phase='balance';note(a,'撑杆锁紧，支架不再晃动。林见微：慢一点调横杆，我脚还在下面。');return {redraw:true}}
   if(mode==='rescue-adjust'){if(r.phase!=='balance'||!['left','right'].includes(target))throw Error('先固定支架，再调横杆');r.balance=Math.max(0,Math.min(100,r.balance+(target==='left'?-5:5)));return {live:true}}
   if(mode==='rescue-confirm'){if(r.phase!=='balance')throw Error('当前不用确认横杆');if(Math.abs(r.balance-r.target)>5){note(a,'林见微：还有点斜。你看刻度，往稳定区再调一点。');return {redraw:true}}r.phase='door';note(a,'林见微：对，就这样。先让我换好手，你再开门。');return {redraw:true}}
   if(mode==='rescue-latch'){if(r.phase!=='door'||r.door>0)throw Error('等门复位后再装卡扣');r.latch=true;note(a,'手动卡扣装入索轨。侧门维持时间由3.6秒延长至6秒。');return {redraw:true}}
   if(mode==='rescue-ready'){if(r.phase!=='door'||r.ready||r.preparing)throw Error('她已经在准备或站稳了');r.preparing=true;r.prep=0;note(a,'你请她先换好手。等待她自己回应，不要替她决定准备好了。');return {redraw:true}}
   if(mode==='rescue-open'){if(r.phase!=='door')throw Error('先固定支架、调平横杆');if(r.door>0)throw Error('门已经开启，不需要连点');r.door=r.latch?6000:3600;note(a,r.ready?'你拉住应急索。门开了，她开始自己走出来。':'门已开启，但她还没站稳。开得太早会浪费维持时间。');return {redraw:true}}
   if(mode==='rescue-next'){if(r.phase!=='done')throw Error('先协作完成通行');return {next:'cMedical'}}
  }
  if(kind==='private'){
   if(mode==='private-face'){if(!['JOKER',...s.known].includes(target))throw Error('这个牌面尚未显现');a.face=target;note(a,target==='JOKER'?'仍然是同一张大王，不是三张本命神牌。':'牌面转成'+NightCards.suits[NightCards.card(target).s].symbol+NightCards.card(target).rank+'。这是私人翻看，不施术、不扣精神力。');return {cast:target,redraw:true}}
   if(mode==='private-end')return {next:'cEnd'}
  }
  throw Error('这个操作不适用于当前场景，没有扣费')
 }
 function validate(s){const a=s.flags.campus;if(a===undefined){if(NightStory.nodes[s.node].campus||s.visited.includes('cMorning'))throw Error('第二篇进度缺失');return}
  const int=(x,l,h)=>Number.isInteger(x)&&x>=l&&x<=h,num=(x,h)=>Number.isFinite(x)&&x>=0&&x<=h,unique=(x,values,max)=>Array.isArray(x)&&x.length<=max&&new Set(x).size===x.length&&x.every(n=>values.includes(n));
  if(!a||typeof a!=='object'||!Array.isArray(a.notes)||a.notes.length>24||a.notes.some(n=>typeof n!=='string')||!unique(a.packed,['id','schedule','book'],3)||!unique(a.seen,Object.keys(objects),3)||!Array.isArray(a.hints)||a.hints.length>30||a.hints.some(n=>typeof n!=='string')||!['lesson','contact','listened','asked','rested'].every(k=>typeof a[k]==='boolean')||!int(a.lessonTries,0,100000)||typeof a.mind!=='string'||!['JOKER',...s.known].includes(a.face))throw Error('第二篇记录损坏');
  const p=a.practice,r=a.rescue;
  if(!p||!int(p.stage,0,3)||!['ready','working','moving','failed','passed'].includes(p.phase)||!num(p.elapsed,120000)||!num(p.gate,2600)||!num(p.bridge,3600)||!num(p.travel,1200)||!int(p.mistakes,0,100000)||!['running','helper','slow'].every(k=>typeof p[k]==='boolean')||p.running!==['working','moving'].includes(p.phase)||(p.stage===3)!==(p.phase==='passed'))throw Error('协作机关记录损坏');
  if(!r||!['brace','balance','door','done'].includes(r.phase)||!int(r.balance,0,100)||r.target!==65||!num(r.prep,1600)||!num(r.door,6000)||!num(r.progress,100)||!int(r.retries,0,100000)||!['preparing','ready','latch','slow'].every(k=>typeof r[k]==='boolean')||r.ready&&r.preparing||r.phase!=='door'&&(r.preparing||r.door>0)||r.phase==='done'&&r.progress!==100)throw Error('救援机构记录损坏');
  if(a.asked&&!a.listened||a.listened&&!s.known.includes('H-2')||s.visited.includes('cCopy')&&(!a.contact||a.seen.length!==3)||s.visited.includes('cAfter')&&p.stage!==3||s.visited.includes('cRescue')&&(!a.listened||!a.asked)||s.visited.includes('cMedical')&&r.phase!=='done')throw Error('第二篇剧情与现场进度不符')
 }
 return {init,view,act,validate};
})();
