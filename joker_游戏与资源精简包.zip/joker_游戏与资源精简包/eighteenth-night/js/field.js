/* 前45章的可玩现场：普通操作只能观察和执行，能力改变信息、位置或规则。 */
const NightField=(()=>{
 const clone=x=>JSON.parse(JSON.stringify(x));
 function init(s){const n=NightStory.nodes[s.node];if(!n.field)throw Error('当前不是现场');if(s.flags.field&&s.flags.field.kind===n.kind)return s.flags.field;const k=n.kind;s.flags.field={kind:k,phase:'ready',notes:[],turn:0,choices:[],score:0,knownRules:[],members:[],items:[],used:false,card:null,success:false,player:{x:10,y:80},enemy:{x:70,y:40},distance:30};return s.flags.field}
 function note(s,t){s.flags.field.notes.push(t);s.flags.field.notes=s.flags.field.notes.slice(-8)}
 function finish(s,next){s.flags.field.phase='done';s.flags.field.success=true;return {next}}
 function view(s){const f=s.flags.field||{};return clone({kind:f.kind,phase:f.phase,notes:f.notes,turn:f.turn,score:f.score,choices:f.choices,knownRules:f.knownRules,members:f.members,items:f.items,used:f.used,card:f.card,success:f.success,player:f.player,enemy:f.enemy,distance:f.distance,mp:s.mp})}
 function need(s,id,cost){if(s.mp<cost)throw Error('精神力不足');s.mp-=cost;s.flags.field.used=true;s.flags.field.card=id}
 function act(s,mode,target){const f=s.flags.field;if(!f)throw Error('现场尚未初始化');
  if(mode==='pulse')return {};
  if(mode==='field-restart'){f.phase='ready';f.turn=0;f.choices=[];f.used=false;f.notes=[];return {redraw:true}}
  if(f.kind==='street'){
   if(mode==='street-start'){f.phase='running';note(s,'观众抽出梅花7。你手里的Joker没有按预定出现。');return {redraw:true}}
   if(mode==='street-misdirect'){if(f.phase!=='running')throw Error('先开始表演');f.turn++;note(s,'你把失败包装成另一层魔术：城市灯光替观众完成了梅花7。');return finish(s,'streetAfter')}
   if(mode==='street-expose'){if(f.phase!=='running')throw Error('先开始表演');f.turn++;note(s,'你直接承认失败，警员仍然记住了这场异常。');return finish(s,'streetAfter')}
  }
  if(f.kind==='blood'&&mode==='blood-submit'){f.phase='running';f.score=43;f.items=['魔素43','铜级'];note(s,'检测阵显示：43。这个数字高得不像平民。');return finish(s,'bloodAfter')}
  if(f.kind==='roulette'){
   if(mode==='roulette-answer'){if(f.phase==='ready')f.phase='running';f.turn++;if(target==='paradox'){f.score=1;note(s,'“我的回答是错误的。”考场无法判定这句话的真值。');return finish(s,'rouletteAfter')}note(s,'普通答案被概率和规则吞掉了。你还没找到题目的漏洞。');return {redraw:true}}
   if(mode==='roulette-card'){need(s,'C-K',8);note(s,'梅花K只改一次概率。你把最后一发的必然性改成了零。');return finish(s,'rouletteAfter')}
  }
  if(f.kind==='metro'){
   if(mode==='metro-start'){f.phase='running';f.player={x:35,y:50};f.enemy={x:50,y:25};note(s,'触手怪扑向两人中距离更近的一方。');return {redraw:true}}
   if(mode==='metro-read'){if(f.phase!=='running')throw Error('先观察现场');need(s,'H-7',7);f.knownRules.push('攻击距离更近者');note(s,'红心7读到：它没有仇恨，只有一条机械的距离规则。');return {redraw:true,cast:'H-7'}}
   if(mode==='metro-equal'){if(f.phase!=='running')throw Error('现场尚未开始');f.turn++;if(f.knownRules.includes('攻击距离更近者')){note(s,'你和苏尘汐保持等距，怪物在两人之间迟疑。');return finish(s,'metroAfter')}note(s,'你没有读懂怪物，走位被它利用了。');return {redraw:true}}
   if(mode==='metro-rods'){if(f.phase!=='running')throw Error('现场尚未开始');if(!f.knownRules.includes('攻击距离更近者'))throw Error('先找出怪物的行动规则');f.items.push('铁杆');note(s,'两根铁杆钉住了触手。');return finish(s,'metroAfter')}
  }
  if(f.kind==='titles'){
   if(mode==='titles-start'){f.phase='running';note(s,'你只看见身份、分数和零散的击杀，三条规则还藏着。');return {redraw:true}}
   if(mode==='titles-observe'){if(f.phase!=='running')throw Error('先进入考场');f.knownRules.push('分数随击杀转移','身份存在克制链');note(s,'刀疤脸击杀后分数转移；苏尘汐的身份又验证了阶级链。');return {redraw:true}}
   if(mode==='titles-disguise'){if(f.phase!=='running')throw Error('先观察');need(s,'D-8',8);f.knownRules.push('三王齐聚即终局');note(s,'方块8让你成为一个能被相信的错误身份。');return {redraw:true,cast:'D-8'}}
   if(mode==='titles-lure'){if(f.phase!=='running'||!f.knownRules.includes('三王齐聚即终局'))throw Error('还没有足够的规则');f.score=1150;note(s,'你把两名君王引到塔楼，叶凌天也被迫成为第三个君王。');return finish(s,'titlesAfter')}
  }
  if(f.kind==='talent'){
   if(mode==='talent-start'){f.phase='running';note(s,'校园网公开了三位君王的阵营人数。叶凌天的公告让所有人不敢接你的传单。');return {redraw:true}}
   if(mode==='talent-poster'){if(f.phase!=='running')throw Error('先开始招募');f.turn++;note(s,'张杨设计的传单很漂亮，但权势比版式先抵达了人群。');return {redraw:true}}
   if(mode==='talent-yang'){if(f.phase!=='running')throw Error('先开始招募');if(!f.members.includes('张杨'))f.members.push('张杨');note(s,'张杨选择留下，却用黑桃国的名义保护家里的小店。');return {redraw:true}}
   if(mode==='talent-xin'){if(f.phase!=='running')throw Error('先开始招募');if(!f.members.includes('唐欣'))f.members.push('唐欣');note(s,'唐欣拒绝在恐惧里低头，成为红心国第一个真正的成员。');return {redraw:true}}
   if(mode==='talent-finish'){if(f.phase!=='running'||!f.members.includes('张杨')||!f.members.includes('唐欣'))throw Error('先留下真正愿意承担代价的人');return finish(s,'talentAfter')}
  }
  if(f.kind==='battle'){
   if(mode==='battle-start'){f.phase='running';f.player={x:12,y:80};f.enemy={x:70,y:35};f.distance=40;f.items=['地图','面包','打火机','汽油桶','防火药水'];note(s,'三王之战开始。你在海岛边缘，身上只有一张随机显现的牌。');return {redraw:true}}
   if(mode==='battle-observe'){if(f.phase!=='running')throw Error('先进入考场');f.knownRules=['杀人得分但死亡清零','阶级压制存在','只能有一个君王'];note(s,'腕表和君王卡的半句信息终于拼齐。');return {redraw:true}}
   if(mode==='battle-chest'){if(f.phase!=='running')throw Error('先开始');f.items.push('梅花权杖');f.knownRules.push('同级可以凭实力战斗');note(s,'仓库的储物柜触发机关，君王试炼把规则完整地交到你手里。');return {redraw:true}}
   if(mode==='battle-rescue'){if(f.phase!=='running'||!f.items.includes('梅花权杖'))throw Error('先完成君王试炼');f.members=['唐欣','张杨'];note(s,'活死人、方块5和炸弹组成了一个人梯与诱饵。三个人暂时都活着。');return {redraw:true}}
   if(mode==='battle-fire'){if(f.phase!=='running'||!f.items.includes('防火药水')||!f.items.includes('汽油桶'))throw Error('还没有找到环境破局的条件');f.used=true;note(s,'唐欣和张杨倒下后，周客喝下防火药水，把森林变成一场大魔术。');return {redraw:true}}
   if(mode==='battle-thunder'){if(f.phase!=='running')throw Error('现场尚未开始');need(s,'S-K',20);f.score=15000;note(s,'湖水导电。黑桃K只用一次，天雷落下，剩余人数归零。');return finish(s,'battleAfter')}
  }
  throw Error('现场动作无效');
 }
 function validate(s){if(!s.flags||!s.flags.field)return;const f=s.flags.field;if(!['street','blood','roulette','metro','titles','talent','battle'].includes(f.kind))throw Error('现场类型无效');if(!Array.isArray(f.notes)||!Array.isArray(f.items)||!Array.isArray(f.members))throw Error('现场记录无效');if(!Number.isFinite(s.mp)||s.mp<0||s.mp>100)throw Error('精神力记录无效')}
 return {init,view,act,validate};
})();