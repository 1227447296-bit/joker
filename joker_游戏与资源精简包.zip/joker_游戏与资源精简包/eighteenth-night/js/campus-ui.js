/* 第二篇场景呈现；只有规则模块能改变游戏状态。 */
const NightCampusUI=(()=>{
 function screen(s,h){const f=NightCampus.view(s),a=h.action,esc=h.escape,p=f.practice,r=f.rescue;let title='',goal='',hint='',body='';
  const btn=(mode,text,target='',enabled=true)=>a(mode,text,target,enabled?'':'disabled');
  const cast=()=>`<div class="campus-skills">${btn('campus-guide','♣2 指路 · 4精神力')}${s.known.includes('H-2')?btn('listen-cast','♥2 听心 · 4精神力 / 已听内容免费'):''}</div>`;
  const thought=()=>f.mind?`<aside class="mind-fragment"><small>林见微 · 此刻的表层念头 / 私人感知</small><p>${esc(f.mind)}</p><span>这不是客观预言，也不是完整记忆。</span></aside>`:'';
  const people=`<div class="campus-people"><span>周客 <small>公开：♣2</small></span><span>许照 <small>♠3 刃造</small></span><span>林见微 <small>♥2 听心</small></span></div>`;
  if(f.kind==='pack'){
   title='宿舍 · 第一堂课之前';goal='带齐三件东西，再和许照出门';hint='点桌上的物品装进包里。看东西不消耗活动次数，也不消耗精神力。';
   body=`<div class="dorm-desk"><div class="desk-window"></div><div class="desk-cup">☕<small>木楔已经垫好</small></div><div class="desk-items">${[['id','学生证','周客 · 梅花2'],['schedule','课表','东教学楼'],['book','笔记本','第一页还空着']].map(([id,name,desc])=>`<button data-action="field" data-mode="pack-item" data-target="${id}" ${f.packed.includes(id)?'disabled':''}><span>${f.packed.includes(id)?'✓ 已装入':'拿起'}</span><b>${name}</b><small>${desc}</small></button>`).join('')}</div></div><div class="campus-speech"><b>许照</b>「你认路吗？我只有教室号。」</div>${s.flags.academy?.resonance?'<p class="game-fine">教务留言：旧庭回应记录已留存，课后可补充当时感受。无需现在办理。</p>':''}<div class="game-controls">${btn('pack-leave','带好东西，去上课 →','',f.packed.length===3)}</div>`
  }
  if(f.kind==='lesson'){
   title='课堂 · 你要解决什么';goal='为“找到实验馆”选一个具体目标';hint='教员刚展示过信封内容，位置没有交换。可以依靠普通观察，不必为了证明有能力而施法。';
   body=`<div class="lesson-envelopes"><div><span>①</span><b>课室位置图</b></div><div><span>②</span><b>食堂菜单</b></div><div><span>③</span><b>空白登记纸</b></div></div><div class="lesson-options">${btn('lesson-goal','哪个信封能帮我找到实验馆？','map',!f.lesson)}${btn('lesson-goal','哪个选择能让我这学期都顺利？','future',!f.lesson)}${btn('lesson-goal','告诉我三个信封里所有的字。','read',!f.lesson)}</div>${f.lesson?`<div class="campus-speech"><b>闻岑</b>「能看清的事，不必为了证明有牌再做一遍。」</div><div class="game-controls">${btn('lesson-next','继续听同学的演示 →')}</div>`:''}`
  }
  if(f.kind==='practice'){
   title='协作台 · '+(p.stage===3?'练习完成':'第'+(p.stage+1)+'/3段');goal=p.stage===3?'三段通过，归还器材':p.stage===0?'对齐挡板，留足1.2秒送过假人':p.stage===1?'降下对齐的短桥，再放行':'让挡板和短桥同时稳定，再放行';hint='黄色框是通道区。移动标记进入框里时固定机关，准备条足够长才能通行。第三段可以请许照一直拉住制动杆。';
   const working=p.running&&p.phase==='working';
   body=people+`<div class="coop-board" data-stage="${p.stage}" data-phase="${p.phase}"><div class="coop-track"><div class="coop-gate"><i id="coop-wheel"></i><span>旋转挡板</span></div><div class="coop-gap"><i id="coop-bridge"></i><span>短桥</span></div><div class="coop-finish">终点</div><div id="coop-cart" class="coop-cart"><img src="assets/cards/card_empty.png" alt="运送台上的练习器材标记，不是神牌"><span>优秀学员</span></div><div class="coop-net">安全网 · 失误只重试当前段</div></div><div class="mechanism-meters">${p.stage!==1&&p.stage<3?'<div><b>挡板位置</b><div class="position-meter"><span class="target-zone"></span><i id="gate-marker"></i></div><small id="gate-lock"></small></div>':''}${p.stage>0&&p.stage<3?'<div><b>短桥位置</b><div class="position-meter"><span class="target-zone"></span><i id="bridge-marker"></i></div><small id="bridge-lock"></small></div>':''}</div><p id="coop-status" class="game-instruction"></p></div><div class="game-controls">${!p.running&&p.stage<3?btn('practice-start',p.phase==='failed'?'从本段重试':'准备好了，开始本段'):''}${p.stage!==1&&p.stage<3?btn('practice-gate','固定挡板','',working&&!p.helper):''}${p.stage>0&&p.stage<3?btn('practice-bridge','降下短桥','',working):''}${p.stage===2?btn('practice-helper',p.helper?'让许照松开制动':'请许照维持挡板','',working):''}${p.stage<3?btn('practice-send','放行运送台 →','',working):btn('practice-next','练习结束，归还器材 →')}${!p.running&&p.stage<3?btn('practice-slow',p.slow?'切回标准速度':'使用慢速练习'):''}</div>${p.stage<3?cast():''}<p class="game-fine">不要求全优。观察与操作免费；梅花只给提示，不代替按键。尚未开始或重试时可切换慢速。</p>`
  }
  if(f.kind==='survey'){
   title='总控小室 · 隔栅后的声音';goal=!f.contact?'先联络教员，说明你们的位置':'检查支架、应急索和格栅 · '+f.seen.length+'/3';hint='你在安全侧，林见微在相邻侧廊；教员组织疏散，检修人员从外侧接近。不要钻进变形门框。没有读字倒计时。';
   body=`<div class="emergency-map"><div class="safe-room"><b>你 · 总控小室</b><span>安全侧 / 手动控制</span></div><div class="map-grille">检修格栅<br>/////</div><div class="trapped-room"><b>林见微 · 侧廊</b><span>水声与帘布遮挡视线</span></div><small>正门：教员组织疏散　｜　外侧：检修人员接近中</small></div><div class="game-controls">${btn('survey-contact',f.contact?'✓ 已联络教员':'接通紧急联络','',!f.contact)}</div><div class="survey-objects">${[['brace','晃动支架','固定槽就在近侧'],['rope','应急索','沿索观察连接'],['grille','检修格栅','呼名确认位置']].map(([id,name,desc])=>btn('survey-look',`<b>${name}</b><small>${desc}${f.seen.includes(id)?' · 已检查':''}</small>`,id)).join('')}</div>${cast()}<div class="game-controls">${btn('survey-next','试着听清她没有说完的话 →','',f.contact&&f.seen.length===3)}</div>`
  }
  if(f.kind==='listen'){
   title='隔帘寻声 · 红桃2';goal=!f.listened?'对近处的林见微，尝试第一次听心':!f.asked?'问她，那句恐惧具体指什么':'已核实：她抓着横杆，不敢换手';hint='使用的是刚显现的红桃2，不是梅花。听见一句念头之后，还要用观察和沟通核实，不能把它当作完整路线。';
   body=`<div class="listening-stage"><div class="listener-card"><img src="${NightCards.art('H-2')}" alt="首次复制的红桃2"></div><div class="behind-grille"><b>林见微 · 近处</b><span>「先别动……那个还在——」</span><i></i></div></div>${thought()}<div class="game-controls">${btn('listen-cast',f.listened?'♥2 再听 / 回想已听见的话':'♥2 听心 · 4精神力')}${s.mp<4&&!f.listened?btn('listen-rest','留在安全侧，稳住呼吸'):''}${btn('listen-ask','呼名询问：你在害怕什么？','',f.listened&&!f.asked)}${btn('listen-next','情况核实，开始协作救援 →','',f.listened&&f.asked)}</div><p class="game-fine">同一句心声重看免费。她仍然能说话，也会自己判断，不是等待操纵的木偶。</p>`
  }
  if(f.kind==='rescue'){
   title='打开回来的路';goal={brace:'先装撑杆，让支架不再晃动',balance:'调平横杆，再请她确认',door:'等她站稳，再开门配合通过',done:'她已经脱困，交给检修人员接手'}[r.phase];hint='普通操作即可完成。支架、横杆与门的状态都看得见；心声只补充人的状态。失误由安全挡块承住，不会让同学死亡。';
   body=`<div class="rescue-scene ${r.phase}" data-phase="${r.phase}"><div class="rescue-support"><i></i><span>${r.phase==='brace'?'支架晃动':'撑杆已锁紧'}</span></div><div class="rescue-beam"><i id="beam-angle"></i><span>横杆</span></div><div class="rescue-door"><i id="rescue-door-panel"></i><span>侧门</span></div><div id="rescue-person" class="rescue-person"><b>林见微</b><span>●</span></div><div class="rescue-control-room">周客 · 安全控制侧</div></div>`;
   if(r.phase==='brace')body+=`<div class="socket-options">${btn('rescue-brace','占用槽 · 被变形件挡住','blocked')}${btn('rescue-brace','空支撑槽 · 可以接近','empty')}</div>`;
   if(r.phase==='balance')body+=`<div class="balance-control"><b>机械刻度 · 黄色区为稳定范围</b><div class="balance-meter"><span style="left:${r.target-5}%;width:10%"></span><i id="balance-marker"></i></div><div class="game-controls">${btn('rescue-adjust','← 向左调5格','left')}${btn('rescue-adjust','向右调5格 →','right')}${btn('rescue-confirm','请她确认横杆位置')}</div></div>`;
   if(r.phase==='door')body+=`<div class="rescue-readouts"><p id="rescue-readiness"></p><p id="rescue-door-time"></p><div class="crossing-track"><i id="rescue-progress"></i></div></div><div class="game-controls">${btn('rescue-ready','请她先换好手，准备过门','',!r.ready&&!r.preparing)}${btn('rescue-open','拉应急索，开门','',r.door===0)}${btn('rescue-latch',r.latch?'✓ 手动卡扣已装好':'先装手动卡扣 · 延长开门','',!r.latch&&r.door===0)}</div>`;
   if(r.phase==='done')body+=`<div class="campus-speech"><b>闻岑</b>「可以了，剩下的我们来。你们先去检查。」</div><div class="game-controls">${btn('rescue-next','去医务室 →')}</div>`;
   else body+=cast()+thought()+`<div class="game-controls">${btn('rescue-slow',r.slow?'切回标准速度':'放慢机关速度','',!r.preparing&&r.door===0)}</div>`
  }
  if(f.kind==='private'){
   title='宿舍 · 一张牌的不同面孔';goal='私下翻看今天留下的两种牌面';hint='学生证仍登记梅花2。这里没有旁观者，翻看不施术、不扣精神力，也不代表同时持有三张本命神牌。';
   body=`<div class="private-card"><img src="${NightCards.art(f.face)}" alt="当前私人牌面 ${esc(f.face)}"></div><div class="game-controls">${btn('private-face','大王','JOKER')}${btn('private-face','♣2 指路','C-2')}${btn('private-face','♥2 听心','H-2')}</div><div class="campus-speech"><b>周客的笔记</b>「见过施术、理解限制、想听清她时，大王变了。这是不是条件，还不知道。」</div><div class="game-controls">${btn('private-end','合上笔记本 · 第二篇结束')}</div>`
  }
  return `<section class="academy-screen campus-screen" data-campus="${f.kind}"><div class="academy-heading"><div><div class="eyebrow">BORROWED VOICE / 第二篇</div><h2>${title}</h2></div><span id="field-mp">精神力 ${s.mp}/${s.maxMp}</span></div><section class="academy-objective"><small>当前目标</small><h3>${goal}</h3><p>${hint}</p><button data-action="title">保存并回到标题</button></section>${body}<aside class="academy-notes"><h3>刚刚发生</h3><div id="field-notes">${h.notesHTML(f)}</div></aside></section>`
 }
 function live(s){const f=NightCampus.view(s),p=f.practice,r=f.rescue,$=x=>document.querySelector(x),text=(id,t)=>{if($(id))$(id).textContent=t},style=(id,k,v)=>{if($(id))$(id).style[k]=v};
  if(f.kind==='practice'){
   style('#gate-marker','left',f.positions.gate+'%');style('#bridge-marker','left',f.positions.bridge+'%');style('#coop-wheel','transform','rotate('+f.positions.gate*1.8+'deg)');style('#coop-bridge','transform','rotate('+(f.positions.bridge-50)*.45+'deg)');style('#coop-cart','left',(8+p.travel/1200*65)+'%');
   text('#gate-lock',p.helper?'许照持续维持制动':p.gate>0?'固定剩余 '+(p.gate/1000).toFixed(1)+'秒':'尚未固定 / 中间黄色区可制动');text('#bridge-lock',p.bridge>0?'桥面剩余 '+(p.bridge/1000).toFixed(1)+'秒':'尚未降桥 / 中间黄色区可固定');
   text('#coop-status',p.phase==='moving'?'运送中，请保持机关稳定……':p.phase==='failed'?'安全网接住了假人。可以重试这一段。':p.phase==='passed'?'三段完成，不需要刷全优。':p.running?'观察运动标记，通行需要1.2秒。':'尚未开始，先看目标再启动。')
  }
  if(f.kind==='rescue'){
   style('#balance-marker','left',r.balance+'%');style('#beam-angle','transform','rotate('+((r.balance-r.target)*.4)+'deg)');style('#rescue-door-panel','height',r.door>0?'12%':'100%');style('#rescue-person','left',(48+r.progress*.36)+'%');style('#rescue-progress','width',r.progress+'%');
   text('#rescue-readiness',r.ready?'✓ 她已站稳：现在开门，我自己走。':r.preparing?'她正在换手与确认落脚…… '+Math.round(r.prep/1600*100)+'%':'她还没准备好，先沟通，不要替她决定。');text('#rescue-door-time',r.door>0?'开门剩余 '+(r.door/1000).toFixed(1)+'秒 · 通行 '+Math.floor(r.progress)+'%':'门已复位 · '+(r.latch?'卡扣延时6秒':'普通维持3.6秒，可先装卡扣延长'));
   const ready=$('[data-mode="rescue-ready"]'),open=$('[data-mode="rescue-open"]'),latch=$('[data-mode="rescue-latch"]');if(ready)ready.disabled=r.ready||r.preparing;if(open)open.disabled=r.door>0;if(latch)latch.disabled=r.latch||r.door>0;
  }
 }
 return {screen,live};
})();
