/* 夺带练习纯规则。所有位置、动作、情报寿命均由可暂停逻辑时钟推进。 */
const NightDuel=(()=>{
 const phases=['watch','approach','windup','lunge','recover','guard'];
 const clamp=n=>Math.max(6,Math.min(94,n));
 const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
 function fresh(round,mp,slow=false){return {round,status:'ready',phase:'watch',elapsed:0,cycle:0,player:{x:25,y:60},opponent:{x:72,y:40},origin:{x:72,y:40},lock:{x:25,y:60},heading:{x:1,y:0},move:0,dash:0,grab:0,startMp:mp,slow,guide:null,thought:null};}
 function init(s){if(!s.flags.duel)s.flags.duel={revision:2,notes:[],results:[],face:'JOKER',bout:fresh(1,s.mp)};return s.flags.duel;}
 function note(a,text){a.notes.push(text);if(a.notes.length>24)a.notes.shift();}
 function view(s){const a=init(s),b=a.bout;return {...a,clock:NightStory.nodes[s.node].kind==='duel'&&b.status==='running',distance:distance(b.player,b.opponent),tell:b.phase==='windup'&&b.elapsed>=300,guideFresh:!!a.bout.guide&&a.bout.guide.key===key(b),thoughtFresh:!!a.bout.thought&&a.bout.thought.key===key(b)};}
 const key=b=>b.cycle+':'+b.phase;
 function change(b,phase){b.phase=phase;b.elapsed=0;if(phase==='windup'){b.lock={...b.player};b.origin={...b.opponent};}}
 function finish(a,status,text){a.bout.status=status;note(a,text);return {redraw:true};}
 function spend(s,id){if(!s.known.includes(id)||s.mp<4)throw Error('精神力不足或牌面尚未显现；普通走位也能完成练习');s.mp-=4;if(!s.used.includes(id))s.used.push(id);init(s).face=id;}
 function pulse(s,a,dt){if(!Number.isFinite(dt)||dt<=0||dt>100)throw Error('无效的小游戏时钟');const b=a.bout;if(b.status!=='running'||NightStory.nodes[s.node].kind!=='duel')return {};
  const step=dt*(b.slow?.65:1);b.elapsed+=step;for(const k of ['move','dash','grab'])b[k]=Math.max(0,b[k]-step);
  if(b.phase==='watch'&&b.elapsed>=650)change(b,'approach');
  else if(b.phase==='approach'){const d=distance(b.player,b.opponent);if(d>30){const amount=Math.min(d-30,step*.018);b.opponent.x+=((b.player.x-b.opponent.x)/d)*amount;b.opponent.y+=((b.player.y-b.opponent.y)/d)*amount;}if(d<=31||b.elapsed>=1800)change(b,b.cycle%2?'guard':'windup');}
  else if(b.phase==='guard'&&b.elapsed>=950)change(b,'windup');
  else if(b.phase==='windup'&&b.elapsed>=850)change(b,'lunge');
  else if(b.phase==='lunge'){const t=Math.min(1,b.elapsed/300);b.opponent.x=b.origin.x+(b.lock.x-b.origin.x)*t;b.opponent.y=b.origin.y+(b.lock.y-b.origin.y)*t;if(t===1){if(distance(b.player,b.opponent)<=13)return finish(a,'lost','许照摘下了你的布带。刚才他扑向的是你停过的位置，看到他压低肩膀后就该离开那里。');change(b,'recover');note(a,'许照扑空，正在收势。现在靠近摘带有机会，但仍要走到他身边。');}}
  else if(b.phase==='recover'&&b.elapsed>=1500){b.cycle++;change(b,'watch');}
  return {live:true};
 }
 function act(s,mode,target){const a=init(s),b=a.bout,kind=NightStory.nodes[s.node].kind;
  if(mode==='pulse')return pulse(s,a,target);
  if(kind==='private'){
   if(mode==='duel-face'){if(!['JOKER',...s.known].includes(target))throw Error('未知牌面');a.face=target;return {cast:target,redraw:true};}
   if(mode==='duel-end')return {next:'dEnd'};
   throw Error('这里只翻看已知牌面');
  }
  if(mode==='duel-start'){if(!['ready','lost'].includes(b.status))throw Error('这一局不能重新开始');if(b.status==='lost')s.mp=b.startMp;a.bout=fresh(b.round,b.startMp,b.slow);a.bout.status='running';note(a,'目标：接近许照，按「摘带」。他压低肩膀时离开原位；扑空收势后再靠近。');return {redraw:true};}
  if(mode==='duel-slow'){if(b.status==='running')throw Error('开局前或本局结束后切换速度');b.slow=!b.slow;return {redraw:true};}
  if(mode==='duel-next'){if(!['won','lost'].includes(b.status))throw Error('先完成这次切磋');a.results.push(b.status);if(b.round===1){a.bout=fresh(2,s.mp,b.slow);return {next:'dBetween'};}return {next:'dAfter'};}
  if(b.status!=='running')throw Error('先开始切磋');
  if(mode==='duel-move'){if(!target||![target.x,target.y].every(n=>Number.isInteger(n)&&Math.abs(n)<=1)||Math.abs(target.x)+Math.abs(target.y)!==1)throw Error('请选择一个移动方向');if(b.move>0)return {};b.heading={...target};b.player.x=clamp(b.player.x+target.x*7);b.player.y=clamp(b.player.y+target.y*7);b.move=90;return {live:true};}
  if(mode==='duel-dash'){if(b.dash>0)return {};b.player.x=clamp(b.player.x+b.heading.x*20);b.player.y=clamp(b.player.y+b.heading.y*20);b.dash=1300;return {live:true};}
  if(mode==='duel-grab'){if(b.grab>0)return {};b.grab=450;const d=distance(b.player,b.opponent);if(d>13){note(a,'够不到。要先走近，摘带范围是身边的短圈。');return {live:true};}if(b.phase==='guard')return finish(a,'lost','你靠近伸手时，许照反手摘走了你的布带。他刚才停住，是在等你先伸手。');if(b.phase==='recover'||(b.phase==='watch'&&d<=8))return finish(a,'won','你摘到了许照肩上的布带。这一局你赢了，牌没有替你伸手。');note(a,'许照侧身护住布带。别只追着按，等他扑空收势再接近。');return {live:true};}
  if(mode==='duel-guide'||mode==='duel-listen'){
   const heart=mode==='duel-listen',slot=heart?'thought':'guide',id=heart?'H-2':'C-2';if(b[slot]?.key===key(b))throw Error('这一动作的信息仍在，不必重复施术');spend(s,id);
   const text=heart?(b.phase==='guard'?'来吧，等你先伸手。':b.phase==='windup'?'就抓他刚才站的地方。':b.phase==='lunge'?'伸出去的手收不回来了。':b.phase==='recover'?'扑过头了，先把重心收回来。':'别贴太近，先看他怎么动。'):(b.phase==='recover'?'眼前目标：摘下布带。倾向靠近，但还要亲手伸手。':b.phase==='windup'||b.phase==='lunge'?'眼前目标：保住布带。倾向离开刚才的位置，不要迎上去。':b.phase==='guard'?'眼前目标：保住布带。倾向保持距离，暂不伸手。':'眼前目标：寻找机会。倾向留出退路，不要一直追着他。');
   b[slot]={key:key(b),text};note(a,(heart?'私人心声：':'梅花的倾向：')+text);return {cast:id,redraw:true};
  }
  throw Error('当前没有这个练习操作');
 }
 function validate(s){const a=s.flags.duel,inRoute=!!NightStory.nodes[s.node].duel||/^d[A-Z]/.test(s.node);if(!a){if(inRoute)throw Error('新版第二篇现场缺失');return;}
  const finite=(n,max)=>Number.isFinite(n)&&n>=0&&n<=max,point=p=>p&&finite(p.x,100)&&finite(p.y,100),b=a.bout;
  if(a.revision!==2||!Array.isArray(a.notes)||a.notes.length>24||a.notes.some(t=>typeof t!=='string')||!Array.isArray(a.results)||a.results.length>2||a.results.some(t=>!['won','lost'].includes(t))||!['JOKER',...s.known].includes(a.face)||!b||![1,2].includes(b.round)||!['ready','running','won','lost'].includes(b.status)||!phases.includes(b.phase)||!finite(b.elapsed,1900)||!Number.isSafeInteger(b.cycle)||b.cycle<0||!point(b.player)||!point(b.opponent)||!point(b.origin)||!point(b.lock)||!b.heading||![-1,0,1].includes(b.heading.x)||![-1,0,1].includes(b.heading.y)||Math.abs(b.heading.x)+Math.abs(b.heading.y)!==1||!finite(b.move,90)||!finite(b.dash,1300)||!finite(b.grab,450)||!finite(b.startMp,60)||typeof b.slow!=='boolean')throw Error('夺带现场记录损坏');
  for(const slot of ['guide','thought'])if(b[slot]!==null&&(!b[slot]||typeof b[slot].text!=='string'||b[slot].text.length>200||typeof b[slot].key!=='string'||!/^\d+:(watch|approach|windup|lunge|recover|guard)$/.test(b[slot].key)))throw Error('练习情报记录损坏');
  if(b.thought&&!s.known.includes('H-2'))throw Error('心声牌面未显现');
  if(!s.visited.includes('dMorning')||s.flags.campus||s.visited.includes('cMorning'))throw Error('第二篇修订路线冲突');
  if(b.round===1&&a.results.length!==0||b.round===2&&a.results.length<1)throw Error('切磋结果进度损坏');
  if(s.node==='dFirst'&&b.round!==1||['dBetween','dCopy','dSecond','dAfter','dPrivate','dEnd'].includes(s.node)&&b.round!==2)throw Error('切磋场次不符');
  if(['dAfter','dPrivate','dEnd'].includes(s.node)&&a.results.length!==2)throw Error('切磋记录缺失');
  if(s.visited.includes('dSecond')&&!s.visited.includes('dCopy'))throw Error('首次变牌经历缺失');
 }
 return {init,view,act,validate};
})();
