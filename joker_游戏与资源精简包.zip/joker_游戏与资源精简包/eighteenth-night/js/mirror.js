/* 方块9镜身只有外形，没有独立心智。真身身份只在现场建立时决定。 */
const NightMirror=(()=>{
 const clamp=n=>Math.max(8,Math.min(92,n)),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
 const walls=[{x:42,y:17,w:17,h:25},{x:42,y:58,w:17,h:25}],bell={x:85,y:25};
 const blocked=p=>walls.some(w=>p.x>=w.x-2&&p.x<=w.x+w.w+2&&p.y>=w.y-3&&p.y<=w.y+w.h+3);
 const bodies=t=>[{x:68+Math.min(t,12000)*.0012,y:48},{x:68+Math.min(t,12000)*.0012,y:52}].map((p,i)=>t<=12000?p:{x:p.x,y:i===0?48-Math.min(t-12000,16000)*.002:52+Math.min(t-12000,16000)*.002});
 const phase=t=>t<12000?'moving':'door';
 function fresh(mp,real,slow=false){return {status:'ready',phase:'moving',elapsed:0,player:{x:18,y:72},bodies:bodies(0),real,selected:0,startMp:mp,move:0,dash:0,slow,heading:{x:1,y:0},guide:null,thought:null,attempt:null,reported:false}}
 function init(s){if(!s.flags.corridor)s.flags.corridor={revision:2,notes:[],face:'JOKER',scene:fresh(s.mp,Math.random()<.5?0:1),outcome:null};return s.flags.corridor}
 function note(a,t){a.notes.push(t);if(a.notes.length>24)a.notes.shift()}
 const key=c=>c.phase+':'+Math.floor(c.elapsed/900);
 function view(s){const a=init(s),c=a.scene,{real,...visible}=c;return {revision:2,notes:a.notes,face:a.face,outcome:a.outcome,scene:JSON.parse(JSON.stringify(visible)),clock:NightStory.nodes[s.node].kind==='corridor'&&c.status==='running',distance:dist(c.player,c.bodies[c.selected]),guideFresh:!!c.guide&&c.guide.key===key(c)&&c.guide.body===c.selected,thoughtFresh:!!c.thought&&c.thought.key===key(c)&&c.thought.body===c.selected&&dist(c.player,c.bodies[c.selected])<=38}}
 function move(c,dir,amount){for(let i=0;i<amount;i++){const p={x:clamp(c.player.x+dir.x),y:clamp(c.player.y+dir.y)};if(blocked(p))break;c.player=p}}
 function step(c){const target=c.bodies[c.selected],p=c.player;let aim=target;if(p.x<62&&(p.y<46||p.y>54))aim={x:Math.min(p.x,36),y:50};else if(p.x<62)aim={x:66,y:50};const dx=aim.x-p.x,dy=aim.y-p.y,dir=Math.abs(dx)>Math.abs(dy)?{x:Math.sign(dx),y:0}:{x:0,y:Math.sign(dy)};const copy={player:{...p}};move(copy,dir,6);return copy.player}
 function spend(s,a,id){if(!s.known.includes(id)||s.mp<4)throw Error('精神力不足；可重试本段恢复现场起始精神力，或到铃旁求援');s.mp-=4;if(!s.used.includes(id))s.used.push(id);a.face=id}
 function finish(a,result,text){a.scene.status=result;a.outcome=result;note(a,text);return {redraw:true}}
 function restart(s,a){const c=a.scene;s.mp=c.startMp;a.scene=fresh(c.startMp,c.real,c.slow);a.scene.status='running';a.outcome=null;note(a,'从本段起点重试，恢复本次起始精神力；两个外形的身份没有重抽。');return {redraw:true}}
 function act(s,mode,target){const a=init(s),c=a.scene,kind=NightStory.nodes[s.node].kind;
  if(mode==='pulse'){if(!Number.isFinite(target)||target<=0||target>100)throw Error('无效的小游戏时钟');if(c.status!=='running')return {};const dt=target*(c.slow?.65:1);c.elapsed=Math.min(28000,c.elapsed+dt);c.move=Math.max(0,c.move-dt);c.dash=Math.max(0,c.dash-dt);c.phase=phase(c.elapsed);c.bodies=bodies(c.elapsed);if(c.elapsed===28000)return finish(a,'missed','两个身影离开了侧廊。你没有追出校外，也没有拿回学生证。');return {live:true}}
  if(kind==='private'){if(mode==='corridor-face'){if(!['JOKER',...s.known].includes(target))throw Error('未知牌面');a.face=target;return {cast:target,redraw:true}}if(mode==='corridor-end')return {next:'fEnd'};throw Error('这里只翻看已知牌面')}
  if(mode==='corridor-next'){if(!['recovered','reported','missed'].includes(c.status))throw Error('先记录现场结果');return {next:'fReport'}}
  if(mode==='corridor-start'){if(!['ready','missed'].includes(c.status))throw Error('现场已经开始');if(c.status==='missed')return restart(s,a);c.status='running';note(a,'窗前的轮廓一晃，灰帽子分成两个相同的身影。外形无法辨认，先选对象，靠近后听心。');return {redraw:true}}
  if(mode==='corridor-retry'){if(!['running','missed'].includes(c.status))throw Error('当前不用重试');return restart(s,a)}
  if(mode==='corridor-slow'){if(c.status==='running')throw Error('现场进行中不能切换速度');c.slow=!c.slow;return {redraw:true}}
  if(c.status!=='running')throw Error('先开始追索');
  if(mode==='corridor-target'){if(!['0','1',0,1].includes(target))throw Error('请选择眼前身影');c.selected=+target;return {live:true}}
  if(mode==='corridor-move'){if(!target||![target.x,target.y].every(n=>Number.isInteger(n)&&Math.abs(n)<=1)||Math.abs(target.x)+Math.abs(target.y)!==1)throw Error('请选择一个移动方向');if(c.move>0)return {};c.heading={...target};move(c,target,6);c.move=90;return {live:true}}
  if(mode==='corridor-dash'){if(c.dash>0)return {};move(c,c.heading,15);c.dash=1300;return {live:true}}
  if(mode==='corridor-listen'||mode==='corridor-guide'){const heart=mode==='corridor-listen',slot=heart?'thought':'guide',id=heart?'H-2':'C-2';if(heart&&dist(c.player,c.bodies[c.selected])>38)throw Error('距离太远，听心只能感知近处目标');if(c[slot]?.key===key(c)&&c[slot].body===c.selected)throw Error('这段信息仍有效，不必重复施术');spend(s,a,id);if(heart){const mind=c.selected===c.real;c.thought={key:key(c),body:c.selected,kind:mind?'mind':'silent',text:mind?(c.phase==='moving'?'“他认不出哪个是我……别让他靠过来。”':'“出口就在前面，先把证收好。”'):'没有独立心智的回应。只有模仿动作的外形。'};note(a,'红桃感知：'+c.thought.text)}else{const point=step(c);c.guide={key:key(c),body:c.selected,point,text:'接近选定对象：先走到地上亮起的位置。不是完整路线，也不辨认真身。'};note(a,'梅花在地上显出一个近处落脚点。你还没有移动。')}return {cast:id,redraw:true}}
  if(mode==='corridor-take'){if(dist(c.player,c.bodies[c.selected])>14)throw Error('还够不到，先接近选定身影');c.attempt=c.selected;return c.selected===c.real?finish(a,'recovered','你拦住有独立心智的灰帽子，从对方手中取回学生证。另一个外形随即散去。'):finish(a,'missed','你抓住的证件套随外形一同散去。真身趁这一瞬离开；你没有取回学生证。')}
  if(mode==='corridor-ring'){if(dist(c.player,bell)>13)throw Error('先走到右上方的值勤铃旁');c.reported=true;return finish(a,'reported','你按下值勤铃，报告两个相同身影。值勤人员开始查访，学生证尚未取回。')}
  throw Error('当前没有这个现场操作')
 }
 function validate(s){const a=s.flags.corridor,c=a?.scene,fail=()=>{throw Error('双身追索现场记录损坏')},finite=(n,max)=>Number.isFinite(n)&&n>=0&&n<=max,point=p=>p&&Object.keys(p).length===2&&[p.x,p.y].every(n=>Number.isFinite(n)&&n>=8&&n<=92),same=(x,y)=>JSON.stringify(x)===JSON.stringify(y);
  if(!a||a.revision!==2||!c||!s.visited.includes('fMorning')||s.flags.campus||s.flags.duel||s.visited.some(id=>/^[cd][A-Z]/.test(id))||!Array.isArray(a.notes)||a.notes.length>24||a.notes.some(t=>typeof t!=='string'||t.length>300)||!['JOKER',...s.known].includes(a.face))fail();
  if(!['ready','running','recovered','reported','missed'].includes(c.status)||!finite(c.elapsed,28000)||c.phase!==phase(c.elapsed)||!point(c.player)||blocked(c.player)||![0,1].includes(c.real)||![0,1].includes(c.selected)||!same(c.bodies,bodies(c.elapsed))||!finite(c.startMp,60)||!finite(c.move,90)||!finite(c.dash,1300)||typeof c.slow!=='boolean'||typeof c.reported!=='boolean'||![null,0,1].includes(c.attempt)||!c.heading||![-1,0,1].includes(c.heading.x)||![-1,0,1].includes(c.heading.y)||Math.abs(c.heading.x)+Math.abs(c.heading.y)!==1)fail();
  for(const slot of ['guide','thought']){const x=c[slot];if(x===null)continue;if(!x||![0,1].includes(x.body)||typeof x.text!=='string'||x.text.length>180||typeof x.key!=='string'||!/^(moving|door):\d+$/.test(x.key))fail();const [p,n]=x.key.split(':'),time=+n*900;if(time>c.elapsed||(p==='moving'?time>=12000:time+900<=12000))fail();const id=slot==='guide'?'C-2':'H-2';if(!s.known.includes(id)||!s.used.includes(id))fail();if(slot==='thought'){if(x.kind!==(x.body===c.real?'mind':'silent'))fail()}else if(!point(x.point)||blocked(x.point))fail()}
  const done=['recovered','reported','missed'].includes(c.status);if(a.outcome!==(done?c.status:null)||c.reported!==(c.status==='reported'))fail();if(c.status==='ready'&&(c.elapsed!==0||c.attempt!==null||c.guide||c.thought||!same(c.player,{x:18,y:72})||c.move!==0||c.dash!==0))fail();if(c.status==='running'&&(c.elapsed>=28000||c.attempt!==null))fail();if(c.status==='recovered'&&(c.attempt!==c.real||dist(c.player,c.bodies[c.real])>14))fail();if(c.status==='reported'&&(c.attempt!==null||dist(c.player,bell)>13))fail();if(c.status==='missed'&&!(c.elapsed===28000&&c.attempt===null||c.attempt!==null&&c.attempt!==c.real&&dist(c.player,c.bodies[c.attempt])<=14))fail();if(['ready','running'].includes(c.status)&&c.reported)fail();
  if(s.node==='fCorridor'&&!s.visited.includes('fCopy'))fail();if(['fReport','fNight','fEnd'].includes(s.node)&&!done)fail();if(!s.visited.includes('fCorridor')&&c.status!=='ready')fail();if(c.status!=='ready'&&!s.known.includes('H-2'))fail();
 }
 return {init,view,act,validate};
})();
