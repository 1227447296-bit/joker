/* v3：小说前45章的单一主线状态机。旧v2存档不静默迁移。 */
const NightEngine=(()=>{
 const S=NightStory,clone=x=>JSON.parse(JSON.stringify(x));
 const node=s=>S.nodes[s.node];
 function enter(s,id){const n=S.nodes[id];if(!n)throw Error('未知场景');s.node=id;s.line=0;s.finished=!!n.end;if(!s.visited.includes(id))s.visited.push(id);if(n.field)NightField.init(s)}
 function newGame(){const s={version:3,protagonist:'周客',node:S.start,line:0,mp:43,maxMp:60,quality:'铜',known:['JOKER'],used:[],flags:{},visited:[],read:[],history:[],finished:false};enter(s,S.start);return s}
 function record(s){const n=node(s),line=n.lines[s.line];if(!line)return;const key=s.node+':'+s.line;if(!s.read.includes(key)){s.read.push(key);s.history.push({node:s.node,speaker:line[0],text:line[1]})}}
 function advance(s){if(s.finished||node(s).field)return;const n=node(s);if(s.line<n.lines.length){record(s);s.line++}if(s.line>=n.lines.length&&n.next)enter(s,n.next)}
 function save(s){return JSON.stringify(s)}
 function load(raw){let s;try{s=JSON.parse(raw)}catch(e){throw Error('存档格式无效')};if(!s||s.version!==3)throw Error('这是旧版剧情存档；新主线改为小说前45章，请从头开始，旧记录不会删除');if(s.protagonist!=='周客'||!S.nodes[s.node]||!Number.isInteger(s.line)||s.line<0||s.line>(S.nodes[s.node].lines||[]).length)throw Error('剧情位置无效');if(!Number.isFinite(s.mp)||s.mp<0||s.mp>s.maxMp||s.maxMp!==60||s.quality!=='铜')throw Error('资源记录无效');for(const k of ['known','used','visited','read','history'])if(!Array.isArray(s[k]))throw Error('存档记录无效');if(s.known.some(id=>typeof id!=='string')||new Set(s.known).size!==s.known.length||s.used.some(id=>!s.known.includes(id)))throw Error('牌面记录无效');if(s.visited.some(id=>!S.nodes[id])||s.history.some(x=>!x||typeof x.node!=='string'||!S.nodes[x.node]||typeof x.speaker!=='string'||typeof x.text!=='string'))throw Error('对白记录无效');if(s.finished!==!!node(s).end)throw Error('结束状态无效');NightField.validate(s);return clone(s)}
 function fieldAction(s,mode,target){if(!node(s).field)throw Error('当前不是可操作场景');const backup=save(s);try{const result=NightField.act(s,mode,target)||{};if(result.cast&&!s.known.includes(result.cast))s.known.push(result.cast);if(result.next)enter(s,result.next);return result}catch(e){const prior=JSON.parse(backup);Object.keys(s).forEach(k=>delete s[k]);Object.assign(s,prior);throw e}}
 return {newGame,node,record,advance,save,load,fieldAction};
})();