/* 唯一正式第二篇的侧廊追索：取证、示警与错过都能继续。 */
const NightCorridor=(()=>{
 const clamp=n=>Math.max(8,Math.min(92,n));
 const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
 const walls=[{x:42,y:17,w:17,h:25},{x:42,y:58,w:17,h:25}],bell={x:85,y:25};
 const blocked=p=>walls.some(w=>p.x>=w.x-2&&p.x<=w.x+w.w+2&&p.y>=w.y-3&&p.y<=w.y+w.h+3);
 function move(c,dir,amount){for(let i=0;i<amount;i++){const p={x:clamp(c.player.x+dir.x),y:clamp(c.player.y+dir.y)};if(blocked(p))break;c.player=p}}
 function fresh(mp){return {revision:3,status:'ready',phase:'moving',elapsed:0,player:{x:18,y:72},runner:{x:68,y:50},startMp:mp,move:0,dash:0,slow:false,heading:{x:1,y:0},guide:null,thought:null,heard:false,reported:false,route:null}}
 function init(s,revision=2){if(!s.flags.corridor&&revision===2)return NightMirror.init(s);if(!s.flags.corridor)s.flags.corridor={revision:3,notes:[],face:'JOKER',scene:fresh(s.mp),outcome:null};return s.flags.corridor}
 function note(a,t){a.notes.push(t);if(a.notes.length>24)a.notes.shift()}
 function key(a){return a.scene.phase+':'+Math.floor(a.scene.elapsed/700)}
 function view(s){const a=init(s);if(a.revision===2)return NightMirror.view(s);const c=a.scene;return {...a,...c,clock:NightStory.nodes[s.node].kind==='corridor'&&c.status==='running',distance:dist(c.player,c.runner),guideFresh:!!c.guide&&c.guide.key===key(a),thoughtFresh:!!c.thought&&c.thought.key===key(a)&&dist(c.player,c.runner)<=38}}
 function spend(s,id){if(!s.known.includes(id)||s.mp<4)throw Error('精神力不足或牌面尚未显现');s.mp-=4;if(!s.used.includes(id))s.used.push(id);init(s).face=id}
 function pulse(s,a,dt){if(!Number.isFinite(dt)||dt<=0||dt>100)throw Error('无效的小游戏时钟');const c=a.scene;if(c.status!=='running')return {};const step=dt*(c.slow?.65:1);c.elapsed+=step;c.move=Math.max(0,c.move-step);c.dash=Math.max(0,c.dash-step);if(c.runner.x<82&&c.phase==='moving'){c.runner.x=Math.min(82,c.runner.x+step*.003)}else{c.phase='door';c.runner.y=Math.min(80,c.runner.y+step*.0025)}if(c.runner.y>=80){c.status='missed';a.outcome='missed';note(a,'灰帽子出了侧廊。你没有追到校外，值勤室仍能登记学生证失窃。');return {redraw:true}}return {live:true}}
 function finish(a,outcome,text){const c=a.scene;c.status=outcome;a.outcome=outcome;note(a,text);return {redraw:true}}
 function act(s,mode,target){const a=init(s);if(a.revision===2)return NightMirror.act(s,mode,target);const c=a.scene,kind=NightStory.nodes[s.node].kind;if(mode==='pulse')return pulse(s,a,target);if(kind==='private'){if(mode==='corridor-face'){if(!['JOKER',...s.known].includes(target))throw Error('未知牌面');a.face=target;return {cast:target,redraw:true}}if(mode==='corridor-end')return {next:'fEnd'};throw Error('这里只翻看已知牌面')}
  if(mode==='corridor-start'){if(!['ready','missed'].includes(c.status))throw Error('现场已经处理');if(c.status==='missed'){const slow=c.slow;s.mp=c.startMp;a.scene=fresh(c.startMp);a.scene.slow=slow;a.outcome=null}a.scene.status='running';note(a,'目标：取回学生证，或先到值勤铃示警。不要追出校外。');return {redraw:true}}
  if(mode==='corridor-slow'){if(c.status==='running')throw Error('现场进行中不能切换速度');c.slow=!c.slow;return {redraw:true}}
  if(mode==='corridor-move'){if(!target||![target.x,target.y].every(n=>Number.isInteger(n)&&Math.abs(n)<=1)||Math.abs(target.x)+Math.abs(target.y)!==1)throw Error('请选择一个移动方向');if(c.status!=='running')throw Error('先开始追索');if(c.move>0)return {};c.heading={...target};move(c,target,6);c.move=90;return {live:true}}
  if(mode==='corridor-dash'){if(c.status!=='running')throw Error('先开始追索');if(c.dash>0)return {};move(c,c.heading,15);c.dash=1300;return {live:true}}
  if(mode==='corridor-listen'||mode==='corridor-guide'){if(c.status!=='running')throw Error('先开始追索');const heart=mode==='corridor-listen',id=heart?'H-2':'C-2',slot=heart?'thought':'guide';if(heart&&dist(c.player,c.runner)>38)throw Error('距离太远，听心只能感知近处目标');if(c[slot]?.key===key(a))throw Error('这一段的信息仍然有效，不必重复施术');spend(s,id);const text=heart?(c.phase==='moving'?'别往值勤室那边看。':c.runner.y<68?'把证收好，别掉出来。':'先出去再说。'):(dist(c.player,bell)<25?'先到旁边的值勤铃求助。':c.player.x<60?'先走到隔断中间的通道，不要顶着墙跑。':'眼前较稳妥的是向值勤铃靠近，不追出校外。');c[slot]={key:key(a),text};if(heart)c.heard=true;note(a,(heart?'私人心声：':'梅花的倾向：')+text);return {cast:id,redraw:true}}
  if(mode==='corridor-ring'){if(c.status!=='running')throw Error('先开始追索');if(dist(c.player,bell)>13)throw Error('先走到右上方的值勤铃旁');c.reported=true;return finish(a,'reported','你按下值勤铃。闻岑和门岗从另一端赶来，灰帽子停在中央隔断外。')}
  if(mode==='corridor-take'){if(c.status!=='running')throw Error('先开始追索');if(dist(c.player,c.runner)>14)throw Error('还够不到学生证，先靠近一点');return finish(a,'recovered','你近前喊出自己的名字。灰帽子把学生证丢在隔断旁，转身退开；你捡起证，留在廊内等值勤人员赶来。')}
  if(mode==='corridor-next'){if(!['recovered','reported','missed'].includes(c.status))throw Error('先完成追索');return {next:'fReport'}}
  throw Error('当前没有这个现场操作')
 }
 function validate(s){if(s.flags.corridor?.revision===2){NightMirror.validate(s);return}const a=s.flags.corridor,inRoute=!!NightStory.nodes[s.node].corridor||/^f[A-Z]/.test(s.node);if(!a){if(inRoute||s.visited.some(id=>/^f[A-Z]/.test(id)))throw Error('正式第二篇现场缺失');return}const c=a.scene,finite=(n,max)=>Number.isFinite(n)&&n>=0&&n<=max,point=p=>p&&[p.x,p.y].every(n=>Number.isFinite(n)&&n>=8&&n<=92);
  if(a.revision!==3||!s.visited.includes('fMorning')||s.flags.campus||s.flags.duel||s.visited.some(id=>/^[cd][A-Z]/.test(id))||!Array.isArray(a.notes)||a.notes.length>24||a.notes.some(t=>typeof t!=='string')||!['JOKER',...s.known].includes(a.face)||!c||c.revision!==3||!['ready','running','recovered','reported','missed'].includes(c.status)||!['moving','door'].includes(c.phase)||!point(c.player)||blocked(c.player)||!point(c.runner)||blocked(c.runner)||!finite(c.elapsed,20000)||!finite(c.startMp,60)||!finite(c.move,90)||!finite(c.dash,1300)||typeof c.slow!=='boolean'||typeof c.heard!=='boolean'||typeof c.reported!=='boolean'||c.route!==null||!c.heading||![-1,0,1].includes(c.heading.x)||![-1,0,1].includes(c.heading.y)||Math.abs(c.heading.x)+Math.abs(c.heading.y)!==1)throw Error('侧廊现场记录损坏');
  for(const slot of ['guide','thought'])if(c[slot]!==null&&(!c[slot]||typeof c[slot].text!=='string'||c[slot].text.length>180||typeof c[slot].key!=='string'||!/^(moving|door):\d+$/.test(c[slot].key)))throw Error('侧廊感知记录损坏');
  const done=['recovered','reported','missed'].includes(c.status);if(a.outcome!==(done?c.status:null)||c.reported!==(c.status==='reported')||c.heard!==!!c.thought)throw Error('追索结果记录不符');
  if(c.thought&&!s.known.includes('H-2'))throw Error('心声牌面未显现');if(s.node==='fCorridor'&&!s.visited.includes('fCopy'))throw Error('变牌经历缺失');if(['fReport','fNight','fEnd'].includes(s.node)&&!done)throw Error('追索结果缺失');if(!s.visited.includes('fCorridor')&&c.status!=='ready')throw Error('现场尚未开始');
 }
 return {init,view,act,validate};
})();
