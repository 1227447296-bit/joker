param([string]$Chrome='C:\Program Files\Google\Chrome\Application\chrome.exe')
$ErrorActionPreference='Stop'
$node=Join-Path $env:USERPROFILE 'nodejs-v24\node.exe'
& $node (Join-Path $PSScriptRoot 'tests\rules.cjs')
if ($LASTEXITCODE -ne 0) { throw 'Rules failed' }
$profile=Join-Path $env:TEMP ('night-test-'+[guid]::NewGuid().ToString('N'))
$out=Join-Path $PSScriptRoot 'tests\browser-output.html'
$err=Join-Path $PSScriptRoot 'tests\browser-stderr.log'
$url=([System.Uri](Join-Path $PSScriptRoot 'tests\browser.html')).AbsoluteUri
$args=@('--headless=new','--disable-gpu','--no-first-run','--allow-file-access-from-files','--disable-background-timer-throttling','--virtual-time-budget=180000','--dump-dom',('--user-data-dir="'+$profile+'"'),$url)
try {
 $proc=Start-Process -FilePath $Chrome -ArgumentList $args -RedirectStandardOutput $out -RedirectStandardError $err -Wait -PassThru
 if ($proc.ExitCode -ne 0) { throw ('Chrome exited '+$proc.ExitCode) }
 $text=[System.IO.File]::ReadAllText($out)
 $m=[regex]::Match($text,'<pre id="result">([\s\S]*?)</pre>')
 if (-not $m.Success) { throw 'No browser report' }
 $json=[System.Net.WebUtility]::HtmlDecode($m.Groups[1].Value)
 $json
 $report=$json|ConvertFrom-Json
 if ($report.status -ne 'ALL_PASS') { throw 'Browser tests failed' }
} finally {
 if (Test-Path $profile) { try { Remove-Item -LiteralPath $profile -Recurse -Force -Confirm:$false -ErrorAction Stop } catch { Write-Warning 'Temporary browser profile still in use' } }
}
