// 兼容旧图鉴的数据接口；不再维护另一份手写效果。
// 必须先加载 rules.js。当前局实际规则快照保存在 engine 的 state.rules 中。
const CARDS_DB = RULES.cards.map(c=>({
  ...c,type:RULES.ops[c.base.op],trigger:RULES.events[c.base.event],tags:[RULES.suits[c.s]],
  tiers:[0,1,2,3,4].map(t=>({n:RULES.tierNames[t],eff:RULES.describe(c,t),cost:RULES.cost(c,t)}))
}));
