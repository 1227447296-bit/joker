/* 可执行规则的唯一来源。游戏、图鉴、编辑器与导出的 Markdown 全部读取这里。
 * 不解析自然语言，不执行玩家输入的 JavaScript。修改后刷新页面即可。
 * op: chips/mult/xmult/mind/will/plastic/law/gold/disorder/repeat/draw/rescue/upgrade
 * event: score/discard/start/end/change/resource；metric 是计数器，见 LABELS。
 */
const RULES = (() => {
  const scales = [1,1.5,2,3,4.5];
  const suits = {H:'心灵',S:'战斗',D:'变化',C:'规则'};
  const symbols = {H:'♥',S:'♠',D:'♦',C:'♣'};
  const tierNames = ['铜','银','金','铂金（半神）','神级'];
  const labels = {one:'固定',hearts:'计分红桃数',spades:'计分黑桃数',diamonds:'计分方块数',clubs:'计分梅花数',heldH:'留手红桃数',mind:'心念',will:'战意',plastic:'剩余可塑',spent:'本劫可塑消耗',laws:'生效律令数',hands:'本劫出手数',left:'剩余出牌',discards:'剩余弃牌',faces:'计分人头牌数',pairs:'计分同点组数',changed:'改造过的计分牌数',enhanced:'带铭刻计分牌数',kickers:'陪打牌数',discardH:'弃掉的红桃数',discardN:'弃掉的牌数',gain:'资源实际增量'};
  const ops = {chips:'灵能',mult:'加算倍率',xmult:'乘算倍率',mind:'心念',will:'战意',plastic:'可塑',law:'律能',gold:'魂币',disorder:'失序值',repeat:'追加计分次数',draw:'抽牌',rescue:'补救出牌',upgrade:'当前牌型升级'};
  const events = {score:'计分时',discard:'弃牌后',start:'劫局开始',end:'劫局结束',change:'变相后',resource:'资源增长后'};
  const conditions = {always:'无条件',calm:'失序值≤30',heartHand:'留手红桃≥3',allH:'计分牌全红桃',mind5:'心念≥5',will3:'战意≥3',will5:'战意≥5',small:'打出≤3张',finisher:'此前进度≥50%',first:'本劫首手',last:'最后一次出牌',changed:'有改造计分牌',rainbow:'计分牌≥3花色',flush:'同花类牌型',boss:'天灾劫局',rich:'持币≥25',law3:'律令≥3',mindGain:'心念增长',plasticGain:'可塑增长',willGain:'战意增长',lawGain:'律能增长'};
  const effect = (op,n,metric='one',event='score',when='always') => ({op,n,metric,event,when});
  const cards = [];
  function add(id,name,base,bonus,god,options={}) {
    const [s,r]=id.split('-');
    cards.push({id,s,r,name,rare:r==='A'?'传说':['J','Q','K'].includes(r)?'稀有':+r>=7?'罕见':'普通',base,bonus,god,clone:!['gold','rescue','plastic','law','draw','upgrade'].includes(base.op),...options});
  }
  const e=effect;
  add('H-A','读心者',e('xmult',.5,'one','score','heartHand'),e('mind',1,'one','score','heartHand'),e('repeat',1,'hearts','score','mind5'));
  add('H-2','预言师',e('draw',1,'one','start'),e('chips',10,'heldH'),e('mind',1,'heldH'));
  add('H-3','共情',e('mult',2,'heldH'),e('mind',1,'one','score','first'),e('chips',20,'heldH'));
  add('H-4','宁神',e('disorder',-3,'one','end'),e('mind',1,'one','start'),e('disorder',-2,'heldH'));
  add('H-5','灵光',e('chips',15,'hearts'),e('chips',10,'one','score','allH'),e('repeat',1,'hearts','score','mind5'));
  add('H-6','回响',e('chips',10,'heldH'),e('chips',2,'mind'),e('mult',1,'heldH'));
  add('H-7','镜湖',e('mind',1,'discardH','discard'),e('chips',5,'mind'),e('disorder',-1,'discardH','discard'));
  add('H-8','安魂',e('chips',40,'one','score','boss'),e('disorder',-3,'one','end'),e('mult',1,'mind'),{trait:'unsealH'});
  add('H-9','洞察',e('mult',8,'one','score','allH'),e('mind',1,'one','score','allH'),e('chips',10,'mind'));
  add('H-10','心海',e('mult',2,'mind'),e('mind',1,'one','start'),e('chips',5,'mind'));
  add('H-J','救赎',e('rescue',1,'one','end'),e('mind',2,'one','start'),e('mult',12,'one','score','last'),{clone:false});
  add('H-Q','心链',e('gold',3,'one','end','mind5'),e('mind',1,'one','start'),e('disorder',-5,'one','end'),{clone:false});
  add('H-K','不动心',e('chips',60,'one','score','calm'),e('disorder',-2,'one','end'),e('mult',1,'mind'));
  add('S-A','弑神之刃',e('xmult',1,'one','score','will5'),e('mult',1,'will'),e('repeat',1,'spades','score','will5'));
  add('S-2','锋刃',e('mult',3,'spades'),e('chips',5,'spades'),e('chips',10,'will'));
  add('S-3','连斩',e('mult',3,'will'),e('will',1,'one','start'),e('chips',15,'will'));
  add('S-4','孤狼',e('mult',8,'one','score','small'),e('chips',20,'one','score','small'),e('xmult',.4,'one','score','small'));
  add('S-5','战意燃烧',e('chips',20,'will'),e('will',1,'one','start'),e('mult',2,'will'));
  add('S-6','斩杀',e('xmult',.3,'one','score','finisher'),e('mult',4,'one','score','finisher'),e('chips',150,'one','score','finisher'));
  add('S-7','疾风',e('mult',2,'left'),e('chips',5,'discards'),e('xmult',.25,'one','score','first'));
  add('S-8','怒涛',e('will',1,'one','start'),e('chips',10,'will'),e('mult',2,'will'),{trait:'keepWill'});
  add('S-9','蓄势',e('xmult',.1,'discards'),e('chips',10,'discards'),e('mult',2,'discards'));
  add('S-10','战鼓',e('mult',2,'hands'),e('chips',10,'hands'),e('xmult',.15,'one','score','will3'));
  add('S-J','破军',e('chips',35,'one','score','boss'),e('mult',4,'one','score','boss'),e('repeat',1,'spades','score','boss'),{trait:'unsealS'});
  add('S-Q','战利品',e('gold',2,'one','end'),e('gold',1,'one','end','will3'),e('gold',2,'one','end','boss'),{clone:false});
  add('S-K','霸王',e('chips',30,'faces'),e('mult',1,'faces'),e('chips',15,'will'));
  add('D-A','万象',e('xmult',.5,'one','score','changed'),e('chips',15,'changed'),e('repeat',1,'changed'));
  add('D-2','幻影术',e('plastic',1,'one','start'),e('chips',15,'changed'),e('draw',1,'one','start'),{trait:'phantom'});
  add('D-3','炼成阵',e('plastic',1,'one','start'),e('chips',10,'spent'),e('mult',2,'spent'));
  add('D-4','复制',e('chips',20,'pairs'),e('plastic',1,'one','start'),e('repeat',1,'changed'),{trait:'copy',clone:false});
  add('D-5','点金术',e('gold',2,'plastic','end'),e('plastic',1,'one','start'),e('gold',1,'spent','end'),{clone:false});
  add('D-6','转化',e('chips',15,'spent'),e('mult',1,'spent'),e('chips',10,'changed'));
  add('D-7','变色龙',e('mult',3,'diamonds'),e('chips',5,'changed'),e('mult',2,'changed'));
  add('D-8','镜像',e('chips',20,'changed'),e('plastic',1,'one','start'),e('mult',3,'pairs'),{trait:'mirror'});
  add('D-9','熔铸',e('chips',15,'diamonds'),e('chips',10,'enhanced'),e('repeat',1,'enhanced'));
  add('D-10','虹彩棱镜',e('xmult',.5,'one','score','rainbow'),e('plastic',1,'one','score','rainbow'),e('mult',10,'one','score','rainbow'));
  add('D-J','嬗变',e('plastic',1,'one','start'),e('mult',2,'changed'),e('chips',30,'changed'),{trait:'transmute'});
  add('D-Q','炼金之心',e('chips',25,'enhanced'),e('plastic',1,'one','start'),e('mult',3,'enhanced'));
  add('D-K','量子纠缠',e('mult',4,'pairs'),e('chips',15,'pairs'),e('repeat',1,'changed'));
  add('C-A','立法者',e('law',1,'one','start'),e('chips',10,'laws'),e('mult',3,'laws'),{trait:'lawCap',clone:false});
  add('C-2','聚财',e('gold',2,'one','end'),e('gold',1,'one','end','rich'),e('gold',2,'one','end'),{clone:false});
  add('C-3','宽限',e('law',1,'one','start'),e('chips',15,'laws'),e('mult',2,'laws'),{trait:'discards',clone:false});
  add('C-4','同源律',e('chips',15,'one','score','flush'),e('mult',4,'one','score','flush'),e('repeat',1,'clubs'),{trait:'fourFlush'});
  add('C-5','商人',e('gold',1,'one','end'),e('gold',1,'one','end'),e('gold',1,'laws','end'),{trait:'discount',clone:false});
  add('C-6','秩序',e('mult',4,'laws'),e('law',1,'one','start'),e('chips',20,'laws'));
  add('C-7','天平',e('xmult',.3),e('chips',20,'one','score','first'),e('mult',5,'laws'),{trait:'scale'});
  add('C-8','抗灾',e('chips',30,'one','score','boss'),e('law',1,'one','start'),e('mult',8,'one','score','boss'),{trait:'ward'});
  add('C-9','循环',e('chips',10,'hands'),e('chips',20,'one','score','last'),e('mult',3,'hands'));
  add('C-10','税收',e('gold',1,'hands','end'),e('gold',1,'one','end'),e('gold',1,'laws','end'),{clone:false});
  add('C-J','规则改写',e('mult',3,'one','score','flush'),e('law',1,'one','start'),e('upgrade',1,'one','end'),{clone:false});
  add('C-Q','虚席',e('chips',15,'kickers'),e('mult',1,'kickers'),e('repeat',1,'kickers'));
  add('C-K','契约之王',e('gold',1,'laws','end'),e('gold',1,'one','end'),e('gold',2,'one','end','boss'),{clone:false});
  const relics = [
    {id:'empathy',name:'共情导线',desc:'每获得2点心念，额外获得1战意。',listen:'mind',step:2,to:'will'},
    {id:'forge',name:'战铸炉',desc:'每获得2点战意，额外获得1可塑。',listen:'will',step:2,to:'plastic'},
    {id:'contract',name:'变法契约',desc:'每获得2点可塑，额外获得1律能。',listen:'plastic',step:2,to:'law'},
    {id:'return',name:'归心环',desc:'每获得2点律能，额外获得1心念。',listen:'law',step:2,to:'mind'},
    {id:'echo',name:'回声面具',desc:'每手首个满溢资源，为本手增加1次随机凡牌计分。'},
    {id:'interest',name:'聚宝金库',desc:'利息上限+5。'},
    {id:'sleeve',name:'千手之袖',desc:'手牌上限+1。'},
    {id:'seat',name:'空白神座',desc:'神牌位+1。'},
    {id:'still',name:'静心烛',desc:'每劫局失序自然消退额外4。'},
    {id:'hunt',name:'天灾猎印',desc:'击败天灾额外获得1神格碎片。'},
    {id:'red',name:'赤印圣物',desc:'每手第一张计分牌重触发一次。'},
    {id:'scholar',name:'星律手稿',desc:'使用星辰时对应牌型额外+1级。'}
  ];
  const bosses = [
    {id:'heart',name:'噬心者',desc:'红桃凡牌封印，不提供点数、资源、铭刻或同源触发。'},
    {id:'spade',name:'断刃者',desc:'黑桃凡牌封印；保留牌型判定。'},
    {id:'diamond',name:'凝滞者',desc:'方块凡牌封印；改造仍然允许。'},
    {id:'silent',name:'沉默钟',desc:'每手沉默一个轮转神牌位，镜像随原卡失效。'},
    {id:'drain',name:'断流',desc:'牌型基础倍率减半（保留小数），神牌仍可增幅。'},
    {id:'judge',name:'审判庭',desc:'每种牌型只有首次出牌得分；重复仍消耗次数。'},
    {id:'mirror',name:'镜之魔',desc:'Joker无法复刻；每次变相额外增加2失序。'},
    {id:'end',name:'终焉天平',desc:'每手得分最多计入目标的35%；至少需要3手。'}
  ];
  function amount(f,t) { return f.op==='xmult'?+(f.n*scales[t]).toFixed(3):Math.sign(f.n)*Math.ceil(Math.abs(f.n)*(['repeat','draw','rescue','plastic','law','upgrade'].includes(f.op)?[1,1,2,2,3][t]:scales[t])); }
  function text(f,t) {
    const a=amount(f,t),unit=f.op==='xmult'?`×${+(1+a).toFixed(3)}`:`${a>=0?'+':''}${a}`;
    const detail=f.op==='xmult'?(f.metric==='one'?`倍率 ${unit}`:`倍率 ×(1 + ${a} × ${labels[f.metric]})`):(f.metric==='one'?`${ops[f.op]} ${unit}`:`${labels[f.metric]} × ${unit} ${ops[f.op]}`);
    return `${events[f.event]}，${conditions[f.when]}：${detail}${f.op==='rescue'?'（每劫限一次，进度≥50%时）':''}`;
  }
  function cost(c,t) {return t<3?'无':c.s==='H'?`每劫结算失去${t===3?2:4}魂币`:c.s==='S'?`每次弃牌额外增加${t===3?3:6}失序`:c.s==='D'?`每次变相额外增加${t===3?1:2}失序`:`天灾目标额外提高${t===3?5:10}%`;}
  const traits={unsealH:'计分红桃不受封印',keepWill:'无黑桃或弃牌时也保留战意',unsealS:'计分黑桃不受封印',phantom:'每次点数变相额外抽1张',copy:'解锁复制变相：每劫一次永久复制凡牌',mirror:'每次花色变相获得1心念',transmute:'每次变相获得1律能',lawCap:'律令槽+1',discards:'每劫弃牌+1',fourFlush:'四张同花色即可成同花',discount:'商店商品价格-1（最低1）',scale:'无附加特性',ward:'抵抗封印、沉默、断流和审判；无法抵抗镜之魔与终焉'};
  function describe(c,t) {return [text(c.base,t),c.trait&&traits[c.trait]?'特性：'+traits[c.trait]:'',t>=1?'二段：'+text(c.bonus,0):'',t>=2?'同源：计分牌同花色或同点数，核心计分效果额外一次（非计分效果不翻倍）':'',t>=3?'神性场：每手基础灵能+25（多张不叠加）；本卡核心加算效果+25%':'',t>=4?'神权：'+text(c.god,0):'',t>=3?'代价：'+cost(c,t):''].filter(Boolean).join('；');}
  // 启动验证；导入编辑配置也复用同一验证器。
  function validate(list) {
    if(!Array.isArray(list)||list.length!==52)throw Error('必须提供完整52张神牌');
    const ids=new Set(cards.map(c=>c.id)),seen=new Set();
    for(const c of list){if(!ids.has(c.id)||seen.has(c.id))throw Error('非法或重复编号');seen.add(c.id);const original=cards.find(x=>x.id===c.id);if(c.s!==original.s||c.r!==original.r||c.trait!==original.trait||c.rare!==original.rare)throw Error('编号、花色、点数、稀有度和特性不可改动');if(!c.name||typeof c.name!=='string'||c.name.length>30||typeof c.clone!=='boolean')throw Error('卡名或复刻字段不合法');
      for(const f of [c.base,c.bonus,c.god]){if(!f||!Object.hasOwn(ops,f.op)||!Object.hasOwn(labels,f.metric)||!Object.hasOwn(events,f.event)||!Object.hasOwn(conditions,f.when)||!Number.isFinite(f.n)||Math.abs(f.n)>1000||(f.op==='xmult'&&(f.n<0||f.n>10)))throw Error(c.id+' 效果字段不合法');if(['chips','mult','xmult','repeat'].includes(f.op)&&f.event!=='score')throw Error('计分效果只能监听计分事件');}}

    return true;
  }
  function markdown(list=cards){validate(list);return '# 小丑王牌 · v0.3 可执行神牌全集\n\n> 自动生成：rules.js 是唯一规则源；请勿单独修改本表。游戏内规则工坊可导出当前配置的完整快照。\n> 五阶：铜 → 银 → 金 → 铂金（半神） → 神级。神级神座仅1个，每张神级使所有劫局目标+10%。\n\n## 阅读规则\n\n- 数值品质系数：1 / 1.5 / 2 / 3 / 4.5。抽牌、资源供给中的可塑与律能、重触发、救赎、牌型升级采用1 / 1 / 2 / 2 / 3。二段与神权固定使用其铜阶数值。\n- 乘算为 ×(1 + 表中增量 × 计数)，不是把倍率本体直接乘计数；例如蓄势铜阶剩余3弃牌，倍率为×1.3。\n- 整数效果先向上取整；复刻按强度计算后向下取整。铂金核心加算效果额外+25%。\n- 特性从铜阶生效；金阶同源只追加核心计分效果一次。每手神牌追加计分上限12次，只重算凡牌点数、铭刻和资源，不递归重跑神牌。\n- 复刻只监听计分事件，复制核心/二段/神权，不复制特性、同源、代价或神性场；质量最多为小丑自身+1阶。\n- 铂金代价在神级被同花色神级代价替换；多张高阶代价叠加。基础灵能+25的神性场每手仅一次。\n- 计分资源：红桃+1心念，黑桃+1战意，方块+1可塑，梅花+1律能。律令数仅指已颁布规则，不是律能余额。\n- 单次操作每条资源导线最多响应一次；队列预算64，不带入下一手。封印牌保留牌型判定，不提供点数/资源/铭刻/同源。\n\n'+Object.entries(suits).map(([suit,name])=>'## '+symbols[suit]+' '+name+'\n\n'+list.filter(c=>c.s===suit).map(c=>'### '+c.r+' '+c.name+'\n\n'+(c.clone?'可复刻（仅计分事件）':'不可复刻')+'\n\n'+[0,1,2,3,4].map(t=>'- **'+tierNames[t]+'**：'+describe(c,t)).join('\n')+'\n').join('\n')).join('\n');}
  return {cards,scales,suits,symbols,tierNames,labels,ops,events,conditions,relics,bosses,amount,text,cost,describe,validate,markdown};
})();
