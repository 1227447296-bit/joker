const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const root=__dirname,box=vm.createContext({console});
vm.runInContext(fs.readFileSync(path.join(root,'loom-cards.js'),'utf8')+'\n'+fs.readFileSync(path.join(root,'loom-engine.js'),'utf8')+'\nthis.E=LoomEngine;this.cards=LOOM_CARDS;',box);
const {E,cards}=box;let passed=0,failed=0;
function test(name,fn){try{fn();passed++}catch(e){failed++;console.error('FAIL '+name+': '+e.message)}}
function rig(ids){const s=E.newRun('rules',0);s.scene={...s.scene,goal:999,doom:30};s.hand=ids.map(id=>s.deck.find(c=>c.id===id).uid);s.draw=s.deck.filter(c=>!s.hand.includes(c.uid)).map(c=>c.uid);s.used=[];s.selected=s.hand.slice();s.threads.forEach(t=>t.done=false);return s}
function standalone(d){const s={resolve:2,force:2,change:2,law:2,progress:4,doom:3,refreshes:2,maxRounds:6,scene:{doom:3}};const p=[{uid:101,s:'H',changed:true},{uid:102,s:d.s},{uid:103,s:'S'},{uid:104,s:'D'},{uid:105,s:'C'}];const x={s,p,i:1,prev:p[0],next:p[2],shields:0,wild:new Set(),alias:new Map(),echo:0,after:[],doneBefore:2,completed:2,startDoom:1,resource:k=>({H:'resolve',S:'force',D:'change',C:'law'})[k],note:()=>{},gain:(k,n)=>{s[k]=Math.max(0,['resolve','force','change','law'].includes(k)?Math.min(6,s[k]+n):s[k]+n)}};d.run(x);for(const fn of x.after)fn();return x}
const checks={
'H-A':x=>x.s.resolve===4&&x.wild.has(101),'H-2':x=>x.shields===2,'H-3':x=>x.s.doom===1&&x.s.resolve===4,'H-4':x=>x.s.doom===1,
'H-5':x=>x.s.progress===6&&x.s.resolve===4,'H-6':x=>x.s.force===4,'H-7':x=>x.wrap&&x.s.resolve===3,'H-8':x=>x.echo===1&&x.s.resolve===3,
'H-9':x=>x.s.resolve===4,'H-10':x=>x.after.length===1,'H-J':x=>x.s.resolve===0&&x.s.force===4&&x.s.progress===6,'H-Q':x=>x.s.resolve===6&&x.s.doom===1,'H-K':x=>x.calm,
'S-A':x=>x.s.force===0&&x.s.progress===8,'S-2':x=>x.s.progress===5,'S-3':x=>x.s.progress===5,'S-4':x=>x.shields===1&&x.s.force===3,
'S-5':x=>x.s.progress===9&&x.s.doom===3,'S-6':x=>x.s.progress===7,'S-7':x=>x.s.force===5,'S-8':x=>x.breach,'S-9':x=>x.s.progress===6,
'S-10':x=>x.s.progress===7&&x.s.doom===4,'S-J':x=>x.s.force===0&&x.s.progress===8&&x.s.doom===2,'S-Q':x=>x.s.force===6&&x.s.doom===4,'S-K':x=>x.s.progress===9,
'D-A':x=>x.wild.has(101),'D-2':x=>x.p[2].s==='D'&&x.p[3].s==='S','D-3':x=>x.s.change===3&&x.s.resolve===3&&x.s.doom===4,
'D-4':x=>x.s.change===1&&x.wild.has(102)&&x.wild.has(104),'D-5':x=>x.s.resolve===0&&x.s.change===4,'D-6':x=>x.s.progress===6,
'D-7':x=>x.wild.has(102)&&x.s.change===3,'D-8':x=>x.s.resolve===3&&x.s.law===4,'D-9':x=>x.s.change===0&&x.s.progress===8,
'D-10':x=>x.s.progress===8&&x.s.doom===1,'D-J':x=>x.s.force===0&&x.s.law===4,'D-Q':x=>x.s.resolve===1&&x.s.law===1&&x.s.change===5,'D-K':x=>x.alias.get(101)==='C'&&x.alias.get(105)==='H',
'C-A':x=>x.reverse&&x.s.law===3,'C-2':x=>x.s.refreshes===4,'C-3':x=>x.s.maxRounds===6,'C-4':x=>x.sameSafe,'C-5':x=>x.s.progress===3&&x.s.change===5,
'C-6':x=>x.s.doom===1,'C-7':x=>x.s.law===4,'C-8':x=>x.s.law===0&&x.s.doom===2,'C-9':x=>x.s.law===4&&x.s.carry==='law',
'C-10':x=>x.s.law===0&&x.s.progress===6,'C-J':x=>x.reverseAll,'C-Q':x=>!x.virtual,'C-K':x=>x.s.doom===0
};
test('52 unique identities, names, descriptions and implementations',()=>{assert.equal(cards.length,52);for(const k of ['id','name','text'])assert.equal(new Set(cards.map(c=>c[k])).size,52);assert.equal(Object.keys(checks).length,52)});
for(const d of cards){test(d.id+' independent effect expectation',()=>assert.ok(checks[d.id](standalone(d))));test(d.id+' real engine resolves and saves',()=>{const extra=['H-4','S-7','D-7','C-4'].filter(id=>id!==d.id),s=rig([d.id,...extra]);E.play(s);assert.ok(s.log.some(l=>l.text.includes('「'+d.name+'」')));assert.equal(E.save(E.load(E.save(s))),E.save(s))})}
test('蓄势在斩首前消耗能量，逆序不等价',()=>{const a=rig(['S-7','S-A']),b=rig(['S-A','S-7']);E.play(a);E.play(b);assert.ok(a.progress>b.progress);assert.equal(a.force,0);assert.equal(b.force,3)});
test('改色保留异能与身份，衔接花色改变',()=>{const s=rig(['H-2','S-2']),id=s.hand[0];E.transform(s,id,'D');assert.equal(E.definition(E.card(s,id)).id,'H-2');E.play(s);assert.ok(s.log.some(l=>l.text.includes('护念')))});
test('护盾抵消随后摩擦，普通同花仍摩擦',()=>{const a=rig(['H-2','H-4']),b=rig(['H-5','H-4']);a.doom=b.doom=3;E.play(a);E.play(b);assert.equal(a.doom,1);assert.equal(b.doom,2)});
test('立法者反向完成第一条，改写可反向完成全部',()=>{const s=rig(['S-7','H-4','C-A']);E.play(s);assert.equal(s.threads[0].done,true);const b=rig(['D-3','S-7','H-4','C-J']);E.play(b);assert.equal(b.threads[0].done,true);assert.equal(b.threads[1].done,true)});
test('延期上限2段且无完成时才延',()=>{for(const rounds of [6,7,8]){const s=rig(['C-3','C-4']);s.maxRounds=rounds;E.play(s);assert.equal(s.maxRounds,Math.min(8,rounds+1))}});
test('宽限不因完成线延期',()=>{const s=rig(['H-4','S-7','C-3']);E.play(s);assert.equal(s.maxRounds,6)});
test('虚席2张时插入虚拟梅花但不加入牌组',()=>{const s=rig(['D-3','C-Q']);E.play(s);assert.ok(s.threads[2].done);assert.equal(s.deck.length,52)});
test('不动心从执行时起生效、不回溯',()=>{const s=rig(['H-5','H-K','H-4']);s.doom=3;E.play(s);assert.equal(s.resolve,3);assert.equal(s.doom,1)});
test('置换改变后续实际顺序，不重复消耗牌',()=>{const s=rig(['D-2','S-7','S-A']);E.play(s);assert.equal(s.last.cards[1].id,'S-A');assert.equal(new Set([...s.draw,...s.hand,...s.used]).size,52)});
test('循环确实下一段再供给、不重复每段供应',()=>{const s=rig(['C-9','H-4']);E.play(s);const old=s.resolve;s.hand=[s.deck.find(c=>c.id==='S-7').uid,s.deck.find(c=>c.id==='S-2').uid];s.draw=s.deck.filter(c=>!s.hand.includes(c.uid)&&!s.used.includes(c.uid)).map(c=>c.uid);s.selected=s.hand.slice();E.play(s);assert.equal(s.resolve,old+1);assert.equal(s.carry,null)});
test('同段达标但失序超限仍失败',()=>{const s=rig(['S-5','S-10']);s.scene.goal=1;s.scene.doom=1;E.play(s);assert.equal(s.phase,'lost')});
test('预演副本不改变真实状态',()=>{const s=rig(['H-2','S-7','S-A']),raw=E.save(s);E.play(E.load(raw));assert.equal(E.save(s),raw)});
test('改牌非手牌原子拒绝',()=>{const s=rig(['H-2','S-2']),raw=E.save(s);assert.throws(()=>E.transform(s,s.draw[0],'C'));assert.equal(E.save(s),raw)});
test('旧版织局存档不伪装为52能力局',()=>{const s=E.newRun('legacy');s.version=1;assert.throws(()=>E.load(E.save(s)))});
console.log(JSON.stringify({status:failed?'FAILED':'ALL_PASS',passed,failed,total:passed+failed}));process.exitCode=failed?1:0;
