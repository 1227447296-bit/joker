/* 神律织局：不是凑牌型，而是把牌排成一条能解决局面的行动链。 */
const LoomEngine=(()=>{
  const SUITS=['H','S','D','C'];
  const SYMBOLS={H:'♥',S:'♠',D:'♦',C:'♣'};
  const NAMES={H:'心灵',S:'战斗',D:'变化',C:'规则'};
  const RANKS=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
  const VALUE=Object.fromEntries(RANKS.map((r,i)=>[r,i+2]));
  const SUIT_ORDER={H:0,S:1,D:2,C:3};
  const SCENES=[
    {id:'bell',name:'失控的钟楼',flavor:'钟声把城市的记忆切成了六段。别让第六声落下。',goal:12,doom:8,threads:[['H','S','心灵先读，战斗才不会误伤'],['S','D','打破封锁后立刻改写路线'],['D','C','改变现实，再把新规则钉住']]},
    {id:'archive',name:'倒悬档案馆',flavor:'书页正在互相改写。你要保住三条真实记录。',goal:14,doom:9,threads:[['C','H','先立规矩，才能看见真相'],['H','D','理解一件事，再改变它'],['D','S','改变之后马上执行']]},
    {id:'garden',name:'无名花园',flavor:'花园只接受自相矛盾的答案。每一步都要为下一步留门。',goal:16,doom:10,threads:[['D','C','变化必须留下规则'],['C','S','规则给行动开路'],['S','H','行动之后收回心神']]}
  ];
  function fail(m){throw Error(m)}
  function rank(r){return VALUE[r]}
  function card(s,uid){return s.deck.find(c=>c.uid===uid)}
  function shuffle(a,rng){for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
  function makeRng(seed){let x=0;for(const ch of String(seed))x=(x*31+ch.charCodeAt(0))>>>0;return ()=>{x=(x*1664525+1013904223)>>>0;return x/4294967296}}
  function makeDeck(rng){const deck=[];let uid=1;for(const s of SUITS)for(const r of RANKS){const d=LOOM_CARDS.find(x=>x.s===s&&x.r===r);deck.push({uid:uid++,id:d.id,s,r,changed:false})}return shuffle(deck,rng)}
  function newRun(seed='织局',sceneIndex=0,tutorial=false){
    const rng=makeRng(seed),deck=makeDeck(rng),scene=SCENES[sceneIndex%SCENES.length];
    const s={version:2,seed:String(seed),rngSeed:sceneIndex,sceneIndex:sceneIndex%SCENES.length,tutorial,scene,round:1,maxRounds:6,deck,draw:deck.map(c=>c.uid),hand:[],used:[],selected:[],progress:0,doom:0,resolve:0,force:0,change:2,law:0,refreshes:2,clues:0,threads:scene.threads.map((x,i)=>({id:i,suits:x.slice(0,2),text:x[2],done:false})),log:[],last:null,phase:'play',reward:null};
    if(tutorial){const order=['H-2','S-7','D-2','C-4','H-4','S-2','D-6'];s.hand=order.map(id=>deck.find(c=>c.id===id).uid);s.draw=deck.filter(c=>!s.hand.includes(c.uid)).map(c=>c.uid);}
    else draw(s,7);say(s,'—— '+scene.name+' ——');say(s,scene.flavor);return s;
  }
  function say(s,text,type='info'){s.log.push({text,type,round:s.round});if(s.log.length>100)s.log.shift()}
  function draw(s,n){while(n-->0){if(!s.draw.length){s.draw=shuffle(s.used.splice(0),makeRng(s.seed+'-'+s.round))}if(s.draw.length)s.hand.push(s.draw.shift())}}
  function energyFor(suit){return {H:'resolve',S:'force',D:'change',C:'law'}[suit]}
  function edge(a,b){return a+'>'+b}
  function definition(c){return LOOM_CARDS.find(d=>d.id===(c.id||c.s+'-'+c.r))}
  function context(s,p){
    const x={s,p,i:0,after:[],shields:0,calm:false,sameSafe:false,wild:new Set(),alias:new Map(),echo:0,good:[],doneBefore:s.threads.filter(t=>t.done).length,completed:0,startDoom:s.doom,source:''};
    x.resource=energyFor;x.note=text=>say(s,x.source+'：'+text,'ability');
    x.gain=(k,n)=>{const old=s[k];s[k]=Math.max(0,['resolve','force','change','law'].includes(k)?Math.min(6,old+n):old+n);const actual=s[k]-old;if(actual)x.note(({progress:'推进',doom:'失序',resolve:'心念',force:'战意',change:'改牌',law:'律能',refreshes:'换牌次数'}[k])+' '+(actual>0?'+':'')+actual)};
    return x;
  }
  function edgeEffect(s,a,b,x,record=true){
    const e=edge(a.s,b.s),good=['H>S','S>D','D>C','C>H'].includes(e);
    if(good){if(record)x.good.push([a,b]);if(e==='H>S'){x.gain('progress',1);x.gain('force',1)}if(e==='S>D'){x.gain('doom',-1);x.gain('change',1)}if(e==='D>C'){x.gain('progress',1);x.gain('law',1)}if(e==='C>H'){x.gain('doom',-2);x.gain('resolve',1)}
    }else if(x.sameSafe&&a.s===b.s)x.gain('law',1);
    else if(x.calm)x.gain('resolve',1);
    else if(x.shields){x.shields--;x.note('护盾抵消一次摩擦')}
    else x.gain('doom',1);
  }
  function playCard(s,c,index,x){
    const d=definition(c);x.i=index;x.prev=x.p[index-1];x.next=x.p[index+1];x.source=SYMBOLS[c.s]+c.r+'「'+d.name+'」';
    say(s,x.source+' · '+d.text,'ability');const start=x.after.length;d.run(x);for(let i=start;i<x.after.length;i++)x.after[i]={fn:x.after[i],source:x.source};
  }
  function satisfy(s,played,x){
    const first=s.threads.find(t=>!t.done);
    function matches(c,suit){return c.s===suit||x.wild.has(c.uid)||x.alias.get(c.uid)===suit}
    function ordered(p,a,b){return p.some((c,i)=>matches(c,a)&&p.some((d,j)=>j>i&&matches(d,b)))}
    for(const t of s.threads){if(t.done)continue;const [a,b]=t.suits;let p=played;if(x.virtual)p=[played[0],{uid:-1,s:'C'},played[1]];
      let hit=ordered(p,a,b);if(!hit&&(x.reverseAll||(x.reverse&&t===first)))hit=ordered(p,b,a);
      if(!hit&&x.wrap)hit=ordered([p[p.length-1],...p.slice(0,-1)],a,b);
      if(!hit&&x.breach&&t===first)hit=p.some(c=>matches(c,a)||matches(c,b));
      if(hit){t.done=true;s.progress+=3;x.completed++;say(s,`完成要求：${t.text} · 推进 +3`,'success')}
    }
  }
  function select(s,uids){if(s.phase!=='play')fail('当前不能选牌');if(!Array.isArray(uids)||uids.length<2||uids.length>5||new Set(uids).size!==uids.length||uids.some(id=>!s.hand.includes(id)))fail('请选择2至5张手牌');s.selected=uids.slice()}
  function transform(s,uid,to){if(s.phase!=='play')fail('当前不能改变牌');if(s.change<1)fail('没有改牌次数');const c=card(s,uid);if(!s.hand.includes(uid)||!c||!SUITS.includes(to))fail('请选择手牌和有效目标花色');if(c.s===to)fail('这张牌已经是该花色');c.s=to;c.changed=true;s.change--;say(s,`改变：这张牌现在是 ${SYMBOLS[to]}${c.r} · 改牌 -1`,'change')}
  function reorder(s,uid,delta){const i=s.selected.indexOf(uid),j=i+delta;if(i<0||j<0||j>=s.selected.length)return;[s.selected[i],s.selected[j]]=[s.selected[j],s.selected[i]]}
  function play(s){
    if(s.phase!=='play')fail('当前不能出牌');select(s,s.selected);const played=s.selected.map(id=>card(s,id)),x=context(s,played);
    s.last={cards:played.map(c=>({...c})),before:{progress:s.progress,doom:s.doom},chains:[]};
    if(s.carry){x.source='上段循环';x.gain(s.carry,1);s.carry=null}
    for(let i=0;i<played.length;i++){playCard(s,played[i],i,x);if(i){x.source=SYMBOLS[played[i-1].s]+' → '+SYMBOLS[played[i].s];edgeEffect(s,played[i-1],played[i],x)}}
    if(x.echo&&x.good.length){x.source='回声';const [a,b]=x.good[x.good.length-1];for(let i=0;i<x.echo;i++)edgeEffect(s,a,b,x,false)}
    satisfy(s,played,x);for(const task of x.after){x.source=task.source;task.fn()}
    s.last.cards=played.map(c=>({...c}));s.last.after={progress:s.progress,doom:s.doom,completed:x.completed};
    s.used.push(...s.selected);s.hand=s.hand.filter(id=>!s.selected.includes(id));s.selected=[];s.round++;
    if(s.doom>=s.scene.doom||s.round>s.maxRounds&&s.progress<s.scene.goal){s.phase='lost';say(s,'失序超过承受范围或行动段数耗尽，织局断裂。','danger')}
    else if(s.progress>=s.scene.goal){s.phase='won';s.reward=null;say(s,'局面被你织回了可控的形状。胜利！','success')}
    else{draw(s,7-s.hand.length);say(s,`第 ${s.round} 段局面：还需 ${Math.max(0,s.scene.goal-s.progress)} 推进`)}return s.last;
  }
  function refresh(s){if(s.phase!=='play')fail('当前不能换牌');if(s.refreshes<1)fail('本局换牌次数已用完');s.refreshes--;s.used.push(...s.hand);s.hand=[];draw(s,7);s.selected=[];say(s,'换牌：局面的要求没有改变，但你失去了一次重新编排的机会。','change')}
  function restart(s){return newRun(s.seed,s.sceneIndex,!!s.tutorial)}
  function save(s){return JSON.stringify(s)}
  function load(raw){
    const s=JSON.parse(raw);if(!s||s.version!==2||!['play','won','lost'].includes(s.phase))fail('这份织局存档使用旧的四类通用能力，请重新开局');
    if(!Array.isArray(s.deck)||s.deck.length!==52||s.deck.some(c=>!definition(c)||!SUITS.includes(c.s)||!RANKS.includes(c.r))||new Set(s.deck.map(c=>c.uid)).size!==52)fail('织局牌组无效');
    const zones=[s.hand,s.draw,s.used];if(zones.some(z=>!Array.isArray(z)))fail('织局牌区无效');const ids=zones.flat();if(ids.length!==52||new Set(ids).size!==52||ids.some(id=>!card(s,id)))fail('织局牌区重复或丢失');
    if(!Array.isArray(s.selected)||s.selected.length>5||new Set(s.selected).size!==s.selected.length||s.selected.some(id=>!s.hand.includes(id)))fail('织局选择无效');
    for(const k of ['round','maxRounds','progress','doom','resolve','force','change','law','refreshes'])if(!Number.isInteger(s[k])||s[k]<0)fail('织局数值无效');
    if(['resolve','force','change','law'].some(k=>s[k]>6)||s.maxRounds>8||s.maxRounds<6||!Array.isArray(s.threads)||s.threads.length!==3||s.threads.some(t=>!Array.isArray(t.suits)||t.suits.length!==2||t.suits.some(k=>!SUITS.includes(k))||typeof t.done!=='boolean')||!s.scene||!Number.isFinite(s.scene.goal)||!Number.isFinite(s.scene.doom)||!Array.isArray(s.log)||s.log.some(e=>typeof e.text!=='string')||(s.carry&&!['resolve','force','change','law'].includes(s.carry)))fail('织局状态无效');
    return s;
  }
  return {SUITS,SYMBOLS,NAMES,RANKS,SCENES,newRun,card,definition,select,transform,reorder,play,refresh,restart,save,load,rank}
})();
