/* 无 DOM 的确定性游戏引擎；规则来自 rules.js，状态可序列化。 */
const JokerEngine = (() => {
  const VERSION=3, SUITS=['H','S','D','C'], RANKS=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
  const HANDS={high:['高牌',5,1,10,1],pair:['对子',10,2,15,1],two:['两对',20,2,20,1],three:['三条',30,3,20,2],straight:['顺子',30,4,30,2],flush:['同花',35,4,15,2],full:['葫芦',40,4,25,2],four:['四条',60,7,30,3],sf:['同花顺',100,8,40,3],five:['五条',120,12,40,3],fh:['同花葫芦',140,14,40,4],ff:['同花五条',160,16,50,4]};
  const LAW={flush:{name:'同源法',desc:'四张同花色即可成同花',cost:2},straight:{name:'捷径法',desc:'四张连续点数即可成顺子',cost:2},kicker:{name:'旁证法',desc:'陪打牌也计分',cost:2},interest:{name:'复利法',desc:'本劫奖励额外+3魂币',cost:2},guard:{name:'护心法',desc:'每手结算后失序-3',cost:2},harvest:{name:'丰收法',desc:'每次弃牌后获得1可塑',cost:2}};
  const INSCRIPTIONS={plain:'无铭刻',chips:'灵纹（+30灵能）',mult:'咒纹（+4倍率）',echo:'回响（重计一次）',gold:'金印（计分+1魂币）'};
  const CONSUMABLES={star:{name:'星辰',price:4,desc:'最近一次打出的牌型+1级（未出手时升级对子）'},heart:{name:'心灵命轨',price:3,desc:'选中1张凡牌永久变为红桃'},spade:{name:'战斗命轨',price:3,desc:'选中1张凡牌永久变为黑桃'},diamond:{name:'变化命轨',price:3,desc:'选中1张凡牌永久变为方块'},club:{name:'规则命轨',price:3,desc:'选中1张凡牌永久变为梅花'},etch:{name:'灵纹刻刀',price:5,desc:'选中1张凡牌永久刻入灵纹'},echo:{name:'回响刻刀',price:7,desc:'选中1张凡牌永久刻入回响'},purge:{name:'净化',price:3,desc:'失序降低20'},erase:{name:'焚牌',price:4,desc:'永久移除选中1张凡牌（牌组至少20张）'}};
  function fail(msg){throw Error(msg);}
  function rng(s){let t=s.rng+=0x6D2B79F5;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;}
  function hash(str){let h=2166136261;for(const c of String(str)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
  function shuffle(s,a){for(let i=a.length-1;i>0;i--){const j=Math.floor(rng(s)*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
  function log(s,text){s.log.push(text);if(s.log.length>240)s.log.splice(0,s.log.length-240);}
  function card(s,uid){return s.deck.find(c=>c.uid===uid);}
  function def(s,id){return s.rules.find(c=>c.id===id);}
  function has(s,id){return s.relics.includes(id);}
  function trait(s,t){return s.gods.some(g=>def(s,g.id).trait===t);}
  function slots(s){return 5+(has(s,'seat')?1:0);}
  function cap(s,k){return {mind:10,will:5,plastic:8,law:8}[k];}
  function lawCap(s){return 3+(trait(s,'lawCap')?1:0);}
  function handCap(s){return 8+(has(s,'sleeve')?1:0);}
  function target(s){const base=[120,400,1200,3500,9000,22000,50000,110000][s.act-1];const curse=s.gods.reduce((n,g)=>n+(def(s,g.id).s==='C'&&g.tier>=3?(g.tier===4?.1:.05):0),0);const divine=s.gods.filter(g=>g.tier===4).length;return Math.ceil(base*(s.buildId?3:1)*[1,1.5,2][s.blind]*(1+curse+divine*.1));}
  function boss(s){return s.blind===2?RULES.bosses[s.act-1]:null;}
  function draw(s,n){while(n-->0&&s.draw.length){s.hand.push(s.draw.pop());}}
  function fill(s){draw(s,Math.max(0,handCap(s)-s.hand.length));}
  function operation(s){s.flow={used:[],counts:{},echo:false,budget:64};s.queue=[];}
  function condition(s,key,c){const sc=c.scoring||[],held=c.held||[];return ({always:true,calm:s.disorder<=30,heartHand:held.filter(x=>x.s==='H').length>=3,allH:sc.length>0&&sc.every(x=>x.s==='H'),mind5:s.res.mind>=5,will3:s.res.will>=3,will5:s.res.will>=5,small:(c.played||[]).length>0&&c.played.length<=3,finisher:s.score>=target(s)*.5,first:s.blindState.hands===1,last:s.plays===1,changed:sc.some(x=>x.changed),rainbow:new Set(sc.map(x=>x.s)).size>=3,flush:['flush','sf','fh','ff'].includes(c.type),boss:!!boss(s),rich:s.gold>=25,law3:s.laws.length>=3,mindGain:c.resource==='mind',plasticGain:c.resource==='plastic',willGain:c.resource==='will',lawGain:c.resource==='law'})[key]===true;}
  function metric(s,key,c){const sc=c.scoring||[],held=c.held||[],groups={};sc.forEach(x=>groups[x.r]=(groups[x.r]||0)+1);return {one:1,hearts:sc.filter(x=>x.s==='H').length,spades:sc.filter(x=>x.s==='S').length,diamonds:sc.filter(x=>x.s==='D').length,clubs:sc.filter(x=>x.s==='C').length,heldH:held.filter(x=>x.s==='H').length,mind:s.res.mind,will:s.res.will,plastic:s.res.plastic,spent:s.blindState.spent,laws:s.laws.length,hands:s.blindState.hands,left:s.plays,discards:s.discards,faces:sc.filter(x=>['J','Q','K'].includes(x.r)).length,pairs:Object.values(groups).filter(n=>n>=2).length,changed:sc.filter(x=>x.changed).length,enhanced:sc.filter(x=>x.ink!=='plain').length,kickers:(c.kickers||[]).length,discardH:(c.discarded||[]).filter(x=>x.s==='H').length,discardN:(c.discarded||[]).length,gain:c.gain||0}[key]||0;}
  function gain(s,k,n,source){
    if(!Number.isFinite(n)||n===0)return;
    const old=s.res[k];s.res[k]=Math.max(0,Math.min(cap(s,k),old+n));const actual=s.res[k]-old;
    if(actual)log(s,`${source} → ${resourceName(k)} ${actual>0?'+':''}${actual}`);
    if(n>0&&old+n>cap(s,k)&&has(s,'echo')&&s.flow&&!s.flow.echo&&s.activeScore){s.flow.echo=true;s.activeScore.repeats++;log(s,'回声面具：资源满溢 → 追加1次计分');}
    if(actual>0&&s.flow)s.queue.push({resource:k,gain:actual});
  }
  function resourceName(k){return {mind:'心念',will:'战意',plastic:'可塑',law:'律能'}[k];}
  function drain(s){
    while(s.queue.length&&s.flow.budget-->0){const c=s.queue.shift();
      for(const r of RULES.relics.filter(r=>r.listen===c.resource&&has(s,r.id))){
        s.flow.counts[r.id]=(s.flow.counts[r.id]||0)+c.gain;
        const n=Math.floor(s.flow.counts[r.id]/r.step);
        if(n>0&&!s.flow.used.includes(r.id)){s.flow.used.push(r.id);gain(s,r.to,n,r.name);}
      }
      fire(s,'resource',c);
    }
    if(s.queue.length){log(s,'连锁安全上限：未处理事件已丢弃，不带入下一手');s.queue=[];}
  }
  function apply(s,f,t,c,source,strength=1,platinum=false){
    if(c.failure&&f.op!=='rescue')return;
    if(!condition(s,f.when,c))return;
    let n=RULES.amount(f,t)*metric(s,f.metric,c)*strength;
    if(platinum&&['chips','mult'].includes(f.op))n*=1.25;
    if(f.op!=='xmult')n=Math.sign(n)*Math.floor(Math.abs(n));
    if(!n)return;
    const a=s.activeScore;
    if(['chips','mult','xmult','repeat'].includes(f.op)){
      if(!a)return;
      if(f.op==='chips')a.chips+=n;
      if(f.op==='mult')a.mult+=n;
      if(f.op==='xmult')a.mult*=1+n;
      if(f.op==='repeat')a.repeats=Math.min(12,a.repeats+Math.max(0,n));
      log(s,`${source} → ${RULES.ops[f.op]} ${f.op==='xmult'?'×'+(1+n).toFixed(2):(n>0?'+':'')+n}`);
    }else if(['mind','will','plastic','law'].includes(f.op)){gain(s,f.op,n,source);}
    else if(f.op==='gold'){s.gold=Math.max(0,s.gold+n);log(s,source+' → 魂币 '+n);}
    else if(f.op==='disorder'){s.disorder=Math.max(0,Math.min(100,s.disorder+n));log(s,source+' → 失序 '+n);}
    else if(f.op==='draw'){draw(s,Math.min(3,n));log(s,source+' → 额外抽牌 '+Math.min(3,n));}
    else if(f.op==='upgrade'){const h=s.lastType||'pair';s.levels[h]+=Math.min(3,n);log(s,source+' → '+HANDS[h][0]+'等级提升');}
    else if(f.op==='rescue'){if(s.plays===0&&s.score<target(s)&&s.score>=target(s)*.5&&!s.blindState.rescued){s.blindState.rescued=true;s.plays=Math.max(1,Math.min(3,n));log(s,source+' → 救赎：补回'+s.plays+'次出牌');}}
  }
  function silent(s,index){return boss(s)?.id==='silent'&&!trait(s,'ward')&&index===(s.blindState.hands-1)%Math.max(1,s.gods.length);}
  function fire(s,event,c){
    s.gods.forEach((g,index)=>{
      if(event==='score'&&silent(s,index)){log(s,def(s,g.id).name+'：本手被沉默');return;}
      const d=def(s,g.id),source=d.name;
      const run=(strength,mirror)=>{
        const t=mirror?Math.min(g.tier,s.jokerTier+1):g.tier;
        if(d.base.event===event){apply(s,d.base,t,c,source+(mirror?'·复刻':''),strength,t>=3);
          if(!mirror&&t>=2&&event==='score'&&['chips','mult','xmult'].includes(d.base.op)&&(c.scoring||[]).some(x=>x.s===d.s||x.r===d.r))apply(s,d.base,t,c,source+'·同源',1,t>=3);
        }
        if(t>=1&&d.bonus.event===event)apply(s,d.bonus,0,c,source+'·二段'+(mirror?'·复刻':''),strength);
        if(t>=4&&d.god.event===event)apply(s,d.god,0,c,source+'·神权'+(mirror?'·复刻':''),strength);
      };
      run(1,false);drainNested(s);
      if(event==='score'&&s.mirror===g.id&&d.clone&&boss(s)?.id!=='mirror'&&s.disorder<90){run([.6,.7,.8,.9,1][s.jokerTier],true);drainNested(s);}
    });
  }
  // resource 事件的嵌套处理交回同一个有预算队列，避免递归调用。
  function drainNested(s){if(!s.draining){s.draining=true;drain(s);s.draining=false;}}
  function newRun(seed='旅人',starter='H-5',custom=RULES.cards){
    RULES.validate(custom);const s={version:VERSION,rules:JSON.parse(JSON.stringify(custom)),seed:String(seed),rng:hash(seed),phase:'blind',act:1,blind:0,gold:8,shards:2,score:0,plays:4,discards:3,deck:[],nextUid:1,draw:[],hand:[],discard:[],gods:[],res:{mind:0,will:0,plastic:2,law:0},laws:[],relics:[],bag:[],levels:Object.fromEntries(Object.keys(HANDS).map(k=>[k,1])),lastType:null,disorder:0,jokerTier:0,mirror:null,mirrorChanges:0,shop:[],refresh:0,log:[],history:[],stats:{hands:0,score:0,best:0,blinds:0},route:null};
    for(const suit of SUITS)for(const r of RANKS)s.deck.push({uid:s.nextUid++,s:suit,r,ink:'plain',changed:false});
    if(!def(s,starter))fail('未知初始神牌');s.gods.push({id:starter,tier:0});s.relics.push('empathy');startBlind(s);return s;
  }
  const STARTERS={'H-5':{companion:'H-9',resource:'mind',amount:3},'S-2':{companion:'S-5',resource:'will',amount:2},'D-6':{companion:'D-7',resource:'plastic',amount:3},'C-9':{companion:'C-6',resource:'law',amount:2}};
  function startAdventure(seed='旅人',starter='D-6',custom=RULES.cards){
    if(!Object.hasOwn(STARTERS,starter))fail('未知起始组合');
    const s=newRun(seed,starter,custom);s.buildId=starter;s.gods.push({id:STARTERS[starter].companion,tier:0});
    const kit=STARTERS[starter];s.res[kit.resource]=kit.amount;
    // 仅开局保底四张路线花色，让玩家立即能改出同花；后续关卡正常洗牌。
    const pool=[...s.hand,...s.draw.slice().reverse()],matching=pool.filter(id=>card(s,id).s===starter[0]).slice(0,4),others=pool.filter(id=>card(s,id).s!==starter[0]).slice(0,4);
    s.hand=[...matching,...others];s.draw=pool.filter(id=>!s.hand.includes(id)).reverse();
    s.log=[];log(s,`—— 第1幕 凡劫 · 目标${target(s)} ——`);
    log(s,'起始组合：'+s.gods.map(g=>def(s,g.id).name).join(' + ')+'；首手保底四张路线花色');return s;
  }
  function prepare(s,kind,uid){
    requirePhase(s,'blind');const t=s.tactics;
    if(kind==='echo'){
      checkSelection(s,[uid]);if(t.echoUid!==null)fail('这一手已经指定了再计分的牌');if(s.res.mind<3)fail('需要3点红桃能量');
      s.res.mind-=3;t.echoUid=uid;log(s,'红桃策略：指定'+RULES.symbols[card(s,uid).s]+card(s,uid).r+'，本手参与计分时再计分一次');
    }else if(kind==='rally'){
      if(t.rally)fail('这一手已经准备了爆发');if(s.res.will<2)fail('需要2点黑桃能量');
      s.res.will-=2;t.rally=true;log(s,'黑桃策略：下一手倍数+5');
    }else fail('未知每手策略');
  }
  function startBlind(s){
    s.phase='blind';s.score=0;s.plays=4;s.discards=3+(trait(s,'discards')?1:0);s.res={mind:0,will:0,plastic:2,law:0};s.laws=[];s.mirror=null;s.mirrorChanges=0;s.disorder=Math.max(0,s.disorder-12-(has(s,'still')?4:0));
    s.tactics={echoUid:null,rally:false};if(s.buildId){const kit=STARTERS[s.buildId];s.res[kit.resource]=kit.amount;}
    s.blindState={hands:0,spent:0,rescued:false,types:[],copied:false};s.draw=shuffle(s,s.deck.map(c=>c.uid));s.hand=[];s.discard=[];s.shop=[];s.refresh=0;operation(s);fill(s);log(s,`—— 第${s.act}幕 ${['凡劫','祸劫','天灾'][s.blind]} · 目标${target(s)} ——`);fire(s,'start',{});drainNested(s);
  }
  function evaluate(cards,options={}){
    if(!cards.length)return null;
    const groups={};for(const c of cards)(groups[c.r]||(groups[c.r]=[])).push(c);
    const sorted=Object.values(groups).sort((a,b)=>b.length-a.length||RANKS.indexOf(b[0].r)-RANKS.indexOf(a[0].r));
    let flush=null,straight=null;
    for(const suit of SUITS){const xs=cards.filter(c=>c.s===suit);if(xs.length>=(options.fourFlush?4:5))flush=xs;}
    function findStraight(xs){const ranks=[...new Set(xs.map(c=>RANKS.indexOf(c.r)+2))].sort((a,b)=>b-a);if(ranks.includes(14))ranks.push(1);const need=options.fourStraight?4:5;for(let i=0;i<=ranks.length-need;i++){const run=ranks.slice(i,i+need);if(run[0]-run[need-1]===need-1)return run.map(n=>xs.find(c=>(RANKS.indexOf(c.r)+2)===(n===1?14:n)));}return null;}
    straight=findStraight(cards);const sf=flush&&findStraight(flush);let type='high',scoring=[sorted.slice().sort((a,b)=>RANKS.indexOf(b[0].r)-RANKS.indexOf(a[0].r))[0][0]];
    if(sorted[0].length===5){type=flush?'ff':'five';scoring=cards;}
    else if(flush&&sorted[0].length===3&&sorted[1]?.length===2){type='fh';scoring=cards;}
    else if(sf){type='sf';scoring=sf;}
    else if(sorted[0].length===4){type='four';scoring=sorted[0];}
    else if(sorted[0].length===3&&sorted[1]?.length===2){type='full';scoring=cards;}
    else if(flush){type='flush';scoring=flush;}
    else if(straight){type='straight';scoring=straight;}
    else if(sorted[0].length===3){type='three';scoring=sorted[0];}
    else if(sorted[0].length===2&&sorted[1]?.length===2){type='two';scoring=sorted[0].concat(sorted[1]);}
    else if(sorted[0].length===2){type='pair';scoring=sorted[0];}
    const kickers=cards.filter(c=>!scoring.includes(c));return {type,scoring,kickers,played:cards};
  }
  function preview(s,uids){const cards=checkSelection(s,uids,false);return evaluate(cards,{fourFlush:s.laws.includes('flush')||trait(s,'fourFlush'),fourStraight:s.laws.includes('straight')});}
  function checkSelection(s,uids,required=true){if(!Array.isArray(uids)||uids.length>5||new Set(uids).size!==uids.length||(required&&!uids.length)||uids.some(id=>!s.hand.includes(id)))fail('请选择手中1至5张不同凡牌');return uids.map(id=>card(s,id));}
  function requirePhase(s,phase){if(s.phase!==phase)fail('当前阶段不能执行此操作');}
  function sealed(s,c){const b=boss(s)?.id;if(trait(s,'ward'))return false;return (b==='heart'&&c.s==='H'&&!trait(s,'unsealH'))||(b==='spade'&&c.s==='S'&&!trait(s,'unsealS'))||(b==='diamond'&&c.s==='D');}
  function points(c){return c.r==='A'?11:['J','Q','K'].includes(c.r)?10:+c.r;}
  function scoreCard(s,c,source){
    if(sealed(s,c)){log(s,source+'：封印，无点数与资源');return;}
    const a=s.activeScore;a.chips+=points(c)+(c.ink==='chips'?30:0);if(c.ink==='mult')a.mult+=4;if(c.ink==='gold')s.gold++;gain(s,{H:'mind',S:'will',D:'plastic',C:'law'}[c.s],1,source);drainNested(s);
  }
  function play(s,uids){
    requirePhase(s,'blind');if(s.plays<=0)fail('出牌次数不足');const selected=checkSelection(s,uids);const ev=preview(s,uids);const held=s.hand.filter(id=>!uids.includes(id)).map(id=>card(s,id));operation(s);s.blindState.hands++;s.lastType=ev.type;
    const h=HANDS[ev.type],level=s.levels[ev.type]-1;s.activeScore={chips:h[1]+level*h[3],mult:h[2]+level*h[4],repeats:0};
    log(s,`第${s.blindState.hands}手 ${h[0]} Lv.${level+1}：${s.activeScore.chips} × ${s.activeScore.mult}`);
    if(boss(s)?.id==='drain'&&!trait(s,'ward'))s.activeScore.mult/=2;
    const sc=(s.laws.includes('kicker')?selected:ev.scoring).filter(c=>!sealed(s,c));const context={...ev,scoring:sc,held};
    if(!sc.some(c=>c.s==='S')&&!trait(s,'keepWill'))s.res.will=0;
    for(const c of s.laws.includes('kicker')?selected:ev.scoring)scoreCard(s,c,RULES.symbols[c.s]+c.r);
    if(s.tactics.rally){s.activeScore.mult+=5;log(s,'黑桃爆发 → 倍数 +5');}
    if(s.tactics.echoUid!==null){const marked=sc.find(c=>c.uid===s.tactics.echoUid);if(marked)scoreCard(s,marked,'红桃回声');else log(s,'红桃回声：指定牌未参与计分，本手标记消耗');}
    for(const c of sc.filter(c=>c.ink==='echo')){scoreCard(s,c,'回响铭刻');}
    if(has(s,'red')&&sc.length)scoreCard(s,sc[0],'赤印圣物');
    if(s.gods.some(g=>g.tier>=3)){s.activeScore.chips+=25;log(s,'神性场：本手基础灵能+25（不叠加）');}
    fire(s,'score',context);drainNested(s);
    const repeats=Math.min(12,s.activeScore.repeats);for(let i=0;i<repeats&&sc.length;i++)scoreCard(s,sc[i%sc.length],'神牌重触发 '+(i+1));
    let {chips,mult}=s.activeScore;mult=Math.max(0,mult);if(s.disorder>=60){mult*=.8;log(s,'失序≥60：终值倍率×0.8');}
    let total=Math.floor(Math.min(1e15,Math.max(0,chips*mult)));
    if(boss(s)?.id==='judge'&&s.blindState.types.includes(ev.type)&&!trait(s,'ward')){total=0;log(s,'审判庭：重复牌型，本手0分');}
    if(boss(s)?.id==='end'){const limit=Math.floor(target(s)*.35);if(total>limit){total=limit;log(s,'终焉天平：单手得分被限制');}}
    s.blindState.types.push(ev.type);s.score+=total;s.plays--;s.stats.hands++;s.stats.score+=total;s.stats.best=Math.max(s.stats.best,total);s.lastScore={chips,mult,total,type:ev.type,repeats};s.activeScore=null;s.tactics={echoUid:null,rally:false};
    s.hand=s.hand.filter(id=>!uids.includes(id));s.discard.push(...uids);fill(s);if(s.laws.includes('guard'))s.disorder=Math.max(0,s.disorder-3);log(s,`结算 ${Math.floor(chips)} × ${mult.toFixed(2)} = ${total}；进度 ${s.score}/${target(s)}`);
    if(s.score>=target(s))winBlind(s);else if(s.plays===0){fire(s,'end',{...context,failure:true});drainNested(s);if(s.plays===0){s.phase='lost';log(s,'劫局失败。可以导出存档或以同种子重新挑战。');}}
    return s.lastScore;
  }
  function winBlind(s){
    // 先锁定阶段，奖励与结算事件仅触发一次。
    s.phase='route';s.stats.blinds++;fire(s,'end',{});drainNested(s);
    const interest=Math.min(Math.floor(s.gold/5),has(s,'interest')?10:5),reward=[3,4,5][s.blind]+s.plays+interest+(s.laws.includes('interest')?3:0);s.gold+=reward;s.shards+=1+(s.blind===2?1:0)+(s.blind===2&&has(s,'hunt')?1:0);
    for(const g of s.gods)if(g.tier>=3&&def(s,g.id).s==='H')s.gold=Math.max(0,s.gold-(g.tier===4?4:2));
    log(s,`通关：基础/余次/利息共+${reward}魂币，神格碎片已入账`);s.history.push({act:s.act,blind:s.blind,score:s.score,plays:s.plays});
    if(s.act===8&&s.blind===2){s.phase='won';log(s,'八幕终焉已破。');return;}
    s.route=null;
  }
  function discard(s,uids){requirePhase(s,'blind');if(s.discards<=0)fail('弃牌次数不足');const cs=checkSelection(s,uids);operation(s);s.discards--;s.hand=s.hand.filter(id=>!uids.includes(id));s.discard.push(...uids);if(!trait(s,'keepWill'))s.res.will=0;
    for(const g of s.gods)if(g.tier>=3&&def(s,g.id).s==='S')s.disorder=Math.min(100,s.disorder+(g.tier===4?6:3));
    if(uids.includes(s.tactics.echoUid)){s.tactics.echoUid=null;log(s,'指定牌已弃掉：红桃回声取消，不返还能量');}
    log(s,'弃牌 '+cs.map(c=>RULES.symbols[c.s]+c.r).join(' '));fire(s,'discard',{discarded:cs});if(s.laws.includes('harvest'))gain(s,'plastic',1,'丰收法');drainNested(s);fill(s);backlash(s);
  }
  function backlash(s){if(s.disorder>=100){const lost=Math.ceil(s.gold/2);s.gold-=lost;s.disorder=40;s.mirror=null;log(s,`失序反噬：失去${lost}魂币，复刻解除，失序回落至40`);}}
  function setMirror(s,id){requirePhase(s,'blind');if(boss(s)?.id==='mirror')fail('镜之魔禁止复刻');if(id===null){s.mirror=null;return;}const g=s.gods.find(x=>x.id===id);if(!g||!def(s,id).clone)fail('这张神牌不可复刻');if(s.mirror===id)return;
    if(s.mirrorChanges>=2)fail('每劫最多锁定/切换两次');s.disorder=Math.min(100,s.disorder+[5,8,12,20,30][Math.min(g.tier,s.jokerTier+1)]+(s.mirrorChanges?10:0));s.mirror=id;s.mirrorChanges++;log(s,'Joker锁定 '+def(s,id).name);backlash(s);
  }
  function transform(s,uid,mode,value){requirePhase(s,'blind');checkSelection(s,[uid]);if(s.res.plastic<1)fail('可塑不足');const c=card(s,uid);if(mode==='suit'&&!SUITS.includes(value)||mode==='rank'&&!RANKS.includes(value)||!['suit','rank','etch','copy'].includes(mode))fail('未知变相');
    if(mode==='suit'&&c.s===value||mode==='rank'&&c.r===value)fail('这张牌已经是该属性');if(mode==='copy'&&(!trait(s,'copy')||s.blindState.copied))fail('复制需持有「复制」，每劫限一次');if(mode==='etch'&&c.ink!=='plain')fail('已有铭刻');
    operation(s);s.res.plastic--;s.blindState.spent++;if(mode==='suit')c.s=value;if(mode==='rank')c.r=value;if(mode==='etch')c.ink='chips';c.changed=true;
    if(mode==='copy'){s.blindState.copied=true;s.deck.push({...c,uid:s.nextUid++});log(s,'复制：永久副本进入牌组，下劫可抽到');}
    if(trait(s,'phantom')&&mode==='rank')draw(s,1);
    if(trait(s,'mirror')&&mode==='suit')gain(s,'mind',1,'镜像映照');
    if(trait(s,'transmute'))gain(s,'law',1,'嬗变');
    for(const g of s.gods)if(g.tier>=3&&def(s,g.id).s==='D')s.disorder+=g.tier===4?2:1;
    if(boss(s)?.id==='mirror')s.disorder+=2;s.disorder=Math.min(100,s.disorder);log(s,'变相：'+RULES.symbols[c.s]+c.r+'（永久修改）');fire(s,'change',{changedCard:c});drainNested(s);backlash(s);
  }
  function enact(s,id){requirePhase(s,'blind');const l=LAW[id];if(!l||s.laws.includes(id))fail('律令不存在或已生效');if(s.laws.length>=lawCap(s))fail('律令槽已满');if(s.res.law<l.cost)fail('律能不足');s.res.law-=l.cost;s.laws.push(id);log(s,'颁布 '+l.name+'：'+l.desc);}
  function route(s,id){requirePhase(s,'route');if(!['market','forge','rift'].includes(id))fail('未知道路');s.route=id;
    if(id==='market'){s.gold+=3;log(s,'商路：获得3魂币');}
    if(id==='forge'){s.shards+=2;s.gold=Math.max(0,s.gold-2);log(s,'神炉：获得2碎片，交出至多2魂币');}
    if(id==='rift'){s.disorder=Math.min(100,s.disorder+12);const pool=RULES.relics.filter(r=>!has(s,r.id));if(pool.length){const r=pool[Math.floor(rng(s)*pool.length)];s.relics.push(r.id);log(s,'裂隙：获得 '+r.name+'，失序+12');}else{s.shards+=2;log(s,'裂隙圣物已齐，转化为2碎片');}backlash(s);}
    s.phase='shop';stock(s);
  }
  function price(s,n){return Math.max(1,n-(trait(s,'discount')?1:0));}
  function stock(s){const pool=shuffle(s,s.rules.filter(c=>!s.gods.some(g=>g.id===c.id)).slice());s.shop=pool.slice(0,3).map(c=>({kind:'god',id:c.id,price:price(s,{'普通':4,'罕见':6,'稀有':8,'传说':12}[c.rare]),sold:false}));
    const rp=RULES.relics.filter(r=>!has(s,r.id));if(rp.length){const r=rp[Math.floor(rng(s)*rp.length)];s.shop.push({kind:'relic',id:r.id,price:price(s,9),sold:false});}
    const consum=Object.keys(CONSUMABLES);for(let i=0;i<2;i++){const id=consum[Math.floor(rng(s)*consum.length)];s.shop.push({kind:'item',id,price:price(s,CONSUMABLES[id].price),sold:false});}
    s.shop.push({kind:'shard',id:'shard',price:price(s,5),sold:false});
  }
  function buy(s,index){requirePhase(s,'shop');const x=s.shop[index];if(!x||x.sold)fail('商品已售罄');if(s.gold<x.price)fail('魂币不足');if(x.kind==='god'&&s.gods.length>=slots(s))fail('神牌位已满');if(x.kind==='item'&&s.bag.length>=3)fail('消耗品栏已满');if(x.kind==='relic'&&has(s,x.id))fail('已持有该圣物');
    s.gold-=x.price;x.sold=true;if(x.kind==='god')s.gods.push({id:x.id,tier:0});if(x.kind==='relic')s.relics.push(x.id);if(x.kind==='item')s.bag.push(x.id);if(x.kind==='shard')s.shards++;log(s,'购买 '+x.id+'，-'+x.price+'魂币');}
  function refresh(s){requirePhase(s,'shop');const n=3+s.refresh*2;if(s.gold<n)fail('刷新需要'+n+'魂币');s.gold-=n;s.refresh++;stock(s);}
  function upgradeCost(g){return {gold:[5,8,12,18][g.tier],shards:[1,2,3,5][g.tier]};}
  function upgrade(s,id){requirePhase(s,'shop');const g=s.gods.find(x=>x.id===id);if(!g||g.tier>=4)fail('不可继续升阶');if(g.tier===3&&s.gods.some(x=>x.tier===4))fail('只有一个神级神座');const c=upgradeCost(g);if(s.gold<c.gold||s.shards<c.shards)fail('升阶需要'+c.gold+'魂币和'+c.shards+'碎片');s.gold-=c.gold;s.shards-=c.shards;g.tier++;log(s,def(s,id).name+'升为'+RULES.tierNames[g.tier]);}
  function upgradeJoker(s){requirePhase(s,'shop');const cost=5+s.jokerTier*4;if(s.jokerTier>=4)fail('小丑已满阶');if(s.gold<cost||s.shards<2)fail('小丑升阶需要'+cost+'魂币和2碎片');s.gold-=cost;s.shards-=2;s.jokerTier++;}
  function sell(s,id){requirePhase(s,'shop');const i=s.gods.findIndex(g=>g.id===id);if(i<0)fail('未知神牌');s.gold+=2+s.gods[i].tier*2;s.gods.splice(i,1);if(s.mirror===id)s.mirror=null;log(s,'出售 '+def(s,id).name);}
  function reorder(s,id,delta){if(!['blind','shop'].includes(s.phase))fail('当前不能换位');const i=s.gods.findIndex(g=>g.id===id),j=i+delta;if(i<0||j<0||j>=s.gods.length)return;[s.gods[i],s.gods[j]]=[s.gods[j],s.gods[i]];}
  function use(s,index,uid){if(!['blind','shop'].includes(s.phase))fail('当前不能使用消耗品');const id=s.bag[index];if(!CONSUMABLES[id])fail('未知消耗品');let c=null;if(!['star','purge'].includes(id)){if(s.phase!=='blind')fail('进入劫局后选择凡牌使用');checkSelection(s,[uid]);c=card(s,uid);if(id==='erase'&&s.deck.length<=20)fail('牌组不能少于20张');}
    if(id==='star'){const h=s.lastType||'pair';s.levels[h]+=has(s,'scholar')?2:1;}
    else if(id==='purge')s.disorder=Math.max(0,s.disorder-20);
    else if(['heart','spade','diamond','club'].includes(id)){c.s={heart:'H',spade:'S',diamond:'D',club:'C'}[id];c.changed=true;}
    else if(id==='erase'){if(s.tactics.echoUid===uid)s.tactics.echoUid=null;s.deck=s.deck.filter(x=>x.uid!==uid);s.hand=s.hand.filter(x=>x!==uid);fill(s);}
    else {c.ink=id==='echo'?'echo':'chips';c.changed=true;}
    s.bag.splice(index,1);log(s,'使用 '+CONSUMABLES[id].name);
  }
  function next(s){requirePhase(s,'shop');s.blind++;if(s.blind>2){s.blind=0;s.act++;}startBlind(s);}
  function save(s){const copy=JSON.parse(JSON.stringify(s));delete copy.flow;delete copy.queue;delete copy.activeScore;delete copy.draining;return JSON.stringify(copy);}
  function load(text){
    const s=JSON.parse(text);if(!s||s.version!==VERSION||!['blind','route','shop','lost','won'].includes(s.phase))fail('存档版本或阶段不兼容');RULES.validate(s.rules);
    if(!Number.isInteger(s.act)||s.act<1||s.act>8||![0,1,2].includes(s.blind)||!Array.isArray(s.deck)||s.deck.length<20||s.deck.length>500||!Array.isArray(s.gods)||s.gods.length>6)fail('存档结构不合法');
    const ids=new Set();for(const c of s.deck){if(!Number.isInteger(c.uid)||ids.has(c.uid)||!SUITS.includes(c.s)||!RANKS.includes(c.r)||!Object.hasOwn(INSCRIPTIONS,c.ink))fail('存档凡牌不合法');ids.add(c.uid);}
    if(!Array.isArray(s.hand)||!Array.isArray(s.draw)||!Array.isArray(s.discard)||new Set([...s.hand,...s.draw,...s.discard]).size!==s.hand.length+s.draw.length+s.discard.length||[...s.hand,...s.draw,...s.discard].some(id=>!ids.has(id)))fail('存档牌区不合法');
    if(new Set(s.gods.map(g=>g.id)).size!==s.gods.length||s.gods.some(g=>!def(s,g.id)||!Number.isInteger(g.tier)||g.tier<0||g.tier>4)||s.gods.filter(g=>g.tier===4).length>1)fail('存档神牌不合法');
    for(const k of ['gold','shards','score','plays','discards','disorder','rng','jokerTier','mirrorChanges','nextUid','refresh'])if(!Number.isFinite(s[k])||s[k]<0)fail('存档数值不合法');
    if(s.jokerTier>4||s.disorder>100||s.mirrorChanges>2||s.plays>10||s.discards>10||s.nextUid<=Math.max(...ids))fail('存档数值超限');
    for(const k of ['mind','will','plastic','law'])if(!Number.isFinite(s.res?.[k])||s.res[k]<0||s.res[k]>cap(s,k))fail('存档资源不合法');
    if(!Array.isArray(s.laws)||s.laws.some(x=>!LAW[x])||new Set(s.laws).size!==s.laws.length||!Array.isArray(s.relics)||s.relics.some(x=>!RULES.relics.some(r=>r.id===x))||new Set(s.relics).size!==s.relics.length||!Array.isArray(s.bag)||s.bag.length>3||s.bag.some(x=>!CONSUMABLES[x]))fail('存档道具不合法');
    for(const k of Object.keys(HANDS))if(!Number.isInteger(s.levels?.[k])||s.levels[k]<1||s.levels[k]>10000)fail('存档牌型等级不合法');
    if(!s.blindState||!Number.isInteger(s.blindState.hands)||!Number.isFinite(s.blindState.spent)||!Array.isArray(s.blindState.types)||!Array.isArray(s.log)||s.log.some(x=>typeof x!=='string')||!Array.isArray(s.shop)||s.shop.length>8)fail('存档进度不合法');
    for(const x of s.shop)if(!x||!['god','item','relic','shard'].includes(x.kind)||!Number.isFinite(x.price)||x.price<1||x.price>1000||(x.kind==='god'&&!def(s,x.id))||(x.kind==='item'&&!CONSUMABLES[x.id])||(x.kind==='relic'&&!RULES.relics.some(r=>r.id===x.id)))fail('存档商店不合法');
    if(!s.stats||['hands','score','best','blinds'].some(k=>!Number.isFinite(s.stats[k])||s.stats[k]<0)||!Array.isArray(s.history)||s.history.length>24||typeof s.seed!=='string'||s.seed.length>200||!Number.isInteger(s.refresh)||!Number.isInteger(s.jokerTier)||!Number.isInteger(s.mirrorChanges))fail('存档统计不合法');
    if(s.mirror!==null&&(!s.gods.some(g=>g.id===s.mirror)||!def(s,s.mirror).clone))fail('存档复刻目标不合法');
    if(s.gods.length>slots(s)||s.laws.length>lawCap(s)||s.blindState.hands<0||s.blindState.spent<0||s.blindState.types.some(k=>!Object.hasOwn(HANDS,k)))fail('存档容量或牌型记录不合法');
    if(s.lastType!==null&&!Object.hasOwn(HANDS,s.lastType))fail('存档最近牌型不合法');
    if(s.lastScore&&(['chips','mult','total','repeats'].some(k=>!Number.isFinite(s.lastScore[k]))||!Object.hasOwn(HANDS,s.lastScore.type)))fail('存档结算数值不合法');
    if(s.buildId!==undefined&&!Object.hasOwn(STARTERS,s.buildId))fail('存档起始组合不合法');
    if(s.tactics===undefined)s.tactics={echoUid:null,rally:false};
    if(!s.tactics||typeof s.tactics.rally!=='boolean'||(s.tactics.echoUid!==null&&(!Number.isInteger(s.tactics.echoUid)||!s.hand.includes(s.tactics.echoUid))))fail('存档每手策略不合法');
    operation(s);s.activeScore=null;s.draining=false;return s;
  }
  return {VERSION,HANDS,LAW,INSCRIPTIONS,CONSUMABLES,STARTERS,newRun,startAdventure,prepare,evaluate,play,discard,preview,transform,enact,setMirror,route,buy,refresh,upgrade,upgradeJoker,sell,reorder,use,next,save,load,target,boss,slots,handCap,lawCap,upgradeCost,card,def,cap};
})();
