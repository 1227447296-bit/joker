/* 确定性、无DOM战斗引擎。动画只播放事件，不负责修改战斗结果。 */
const WanpaiEngine=(()=>{
 const D=WanpaiData,VERSION=1,MAX_FLOORS=16;
 const clone=x=>JSON.parse(JSON.stringify(x));
 function fail(m){throw Error(m)}
 function hash(text){let h=2166136261;for(const c of String(text)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
 function random(s){s.rng=(Math.imul(s.rng,1664525)+1013904223)>>>0;return s.rng/4294967296}
 function choose(s,list){return list[Math.floor(random(s)*list.length)]}
 function log(s,text){s.log.push(text);if(s.log.length>160)s.log.shift()}
 function emit(s,type,detail={}){s.events.push({type,...detail})}
 function phase(s,p){if(s.phase!==p)fail('当前不能执行这个操作')}
 function alive(s){return s.enemies.filter(e=>e.hp>0)}
 function intent(e){const action=e.override||e.pattern[e.step%e.pattern.length];return {type:action[0],n:action[1]+(action[0]==='attack'?e.strength:0)}}
 function profile(){return {version:1,unlocked:D.initialUnlocks.slice(),runs:0,wins:0,best:0,ink:0,claims:[]}}
 function validateProfile(p){if(!p||p.version!==1||!Array.isArray(p.unlocked)||p.unlocked.some(id=>!D.form(id))||new Set(p.unlocked).size!==p.unlocked.length||['runs','wins','best','ink'].some(k=>!Number.isInteger(p[k])||p[k]<0)||!Array.isArray(p.claims))fail('牌谱记录损坏');return p}
 function newRun(seed='万牌',p=profile()){
  validateProfile(p);const s={version:VERSION,id:String(seed)+'-'+hash(seed),seed:String(seed),rng:hash(seed),phase:'battle',floor:1,region:0,gold:12,hp:72,maxHp:72,risk:0,energy:3,turn:1,block:0,forms:D.starter.map(id=>({id,level:0})),slots:6,relics:[],enemies:[],shape:'JOKER',lastSkill:null,cooldowns:{},turnUses:{},suitHistory:[],turnSuits:[],bridges:[],usedRelics:[],strength:0,focus:0,rage:0,echo:0,reflect:0,weak:0,ward:0,barrier:false,law:false,wild:false,sameLaw:false,sameUsed:false,reverted:false,contract:false,kills:0,turnKills:0,transforms:0,bonusEnergy:0,bonusGold:0,extraReward:0,tax:0,offers:[],rewardChosen:false,shop:[],log:[],events:[],history:[],metaUnlocks:p.unlocked.slice(),newUnlocks:[],settled:false,stats:{damage:0,transforms:0,battles:0,bridges:0},route:'safe'};
  battle(s);return s;
 }
 function enemy(s,type,index){const t=D.enemyTypes[type],region=Math.floor((s.floor-1)/4),scale=1+region*.18+(s.floor%4===3?.08:0);return {uid:'e'+index,type,name:t.name,art:t.art,hp:Math.ceil(t.hp*scale),maxHp:Math.ceil(t.hp*scale),block:0,strength:region,weak:0,vulnerable:0,link:0,tax:0,stun:0,pattern:clone(t.pattern),step:0,override:null,boss:!!t.boss,elite:!!t.elite}}
 function battle(s){
  s.phase='battle';s.region=Math.floor((s.floor-1)/4);let types;
  if(s.floor%4===0)types=[['bell','queen','king','joker'][s.region]];
  else if(s.route==='danger'&&s.floor>1)types=[s.region>1?'collector':'knight'];
  else types=s.floor===1?['sentinel']:s.floor%4===3?['hound','scribe']:['sentinel','moth'];
  s.enemies=types.map((t,i)=>enemy(s,t,i));s.turn=1;s.energy=3+(s.relics.includes('hourglass')?1:0);s.block=0;s.shape='JOKER';s.cooldowns={};s.turnUses={};s.turnSuits=[];s.suitHistory=[];s.bridges=[];s.usedRelics=[];s.strength=s.relics.includes('crown')?1:0;s.focus=0;s.rage=0;s.echo=0;s.reflect=0;s.weak=0;s.ward=0;s.barrier=false;s.law=false;s.wild=false;s.sameLaw=false;s.sameUsed=false;s.reverted=false;s.contract=false;s.turnKills=0;s.transforms=0;s.bonusEnergy=0;s.bonusGold=0;s.lastSkill=null;s.events=[];
  log(s,`第${s.floor}层 · ${types.map(t=>D.enemyTypes[t].name).join(' / ')}。敌人的下一步已公开。`);
 }
 function damagePlayer(s,n,{attack=false}={}){
  n=Math.max(0,Math.floor(n));if(attack&&s.law)n=Math.min(5,n);const blocked=Math.min(s.block,n);s.block-=blocked;n-=blocked;if(s.barrier)n=Math.min(1,n);s.hp=Math.max(0,s.hp-n);emit(s,'playerHit',{n,blocked});return n;
 }
 function heal(s,n){const old=s.hp;s.hp=Math.min(s.maxHp,s.hp+Math.max(0,Math.floor(n)));emit(s,'heal',{n:s.hp-old})}
 function block(s,n){s.block+=Math.max(0,Math.floor(n));emit(s,'block',{n})}
 function gainGold(s,n){n=Math.min(n,Math.max(0,12-s.bonusGold));s.gold+=n;s.bonusGold+=n}
 function damage(s,e,n,chain=false){
  if(!e||e.hp<=0)return;let amount=Math.max(0,Math.floor(n));if(e.vulnerable)amount=Math.floor(amount*1.25);const raw=amount,shield=Math.min(e.block,amount);e.block-=shield;amount-=shield;const old=e.hp;e.hp=Math.max(0,e.hp-amount);const actual=old-e.hp;s.stats.damage+=actual;emit(s,'hit',{uid:e.uid,n:actual,blocked:shield});
  if(e.hp===0&&old>0){s.kills++;s.turnKills++;emit(s,'defeat',{uid:e.uid});log(s,e.name+'被击破');if(s.contract)s.energy=Math.min(8,s.energy+1)}
  if(!chain&&e.link&&actual>0)for(const other of alive(s).filter(o=>o!==e&&o.link))damage(s,other,Math.floor(actual*.5),true);
  return raw;
 }
 const copying=new Set(['copy','echo','reset']);
 function skill(s,f,target,level=0,replay=false,boost=0){
  const dealsDamage=f.effects.some(([op])=>['damage','allDamage','hits','mindburst','shieldStrike','execute','godslayer','convert','mirror','burnBlock','rainbow','balance','emptyPower'].includes(op)),spentFocus=dealsDamage?s.focus:0;
  let bonus=s.strength+(f.s==='S'?s.rage:0)+spentFocus+boost;if(dealsDamage)s.focus=0;
  const first=s.enemies.find(e=>e.uid===target&&e.hp>0)||alive(s)[0],power=n=>Math.max(0,n+level*2),hit=(e,n)=>damage(s,e,Math.max(0,Math.floor((power(n)+bonus)*(s.weak?.75:1))));
  for(const [op,base,count] of f.effects){if(replay&&copying.has(op))continue;const n=base;
   switch(op){
    case 'damage':hit(first,n);break;
    case 'allDamage':for(const e of alive(s))hit(e,n);break;
    case 'hits':for(let i=0;i<count&&first?.hp>0;i++)hit(first,n);break;
    case 'block':block(s,power(n));break;
    case 'heal':heal(s,power(n));break;
    case 'risk':s.risk=Math.max(0,Math.min(100,s.risk+n));break;
    case 'focus':s.focus+=n+level;break;
    case 'strength':s.strength+=n+level;break;
    case 'rage':s.rage+=n+level;break;
    case 'energy':s.energy=Math.min(8,s.energy+n);break;
    case 'gold':gainGold(s,n);break;
    case 'selfDamage':s.hp=Math.max(1,s.hp-n);emit(s,'playerHit',{n});break;
    case 'link':if(first)first.link=Math.max(first.link,n);break;
    case 'linkAll':for(const e of alive(s))e.link=Math.max(e.link,n);break;
    case 'weak':if(first)first.weak=Math.max(first.weak,n);break;
    case 'weakAll':for(const e of alive(s))e.weak=Math.max(e.weak,n);break;
    case 'vulnerable':if(first)first.vulnerable=Math.max(first.vulnerable,n);break;
    case 'echo':s.echo=1;break;
    case 'reflect':s.reflect+=power(n);break;
    case 'mindburst':damage(s,first,Math.max(6,spentFocus*n)+level*2);break;
    case 'barrier':s.barrier=true;break;
    case 'stunAll':for(const e of alive(s))e.stun++;break;
    case 'shieldStrike':hit(first,s.block+n);break;
    case 'execute':hit(first,n*(first&&first.hp/first.maxHp<.4?2:1));break;
    case 'shatter':if(first)first.block=0;break;
    case 'bounty':if(first?.hp===0){s.gold+=6;log(s,'战利品：击杀额外获得6金币')}break;
    case 'godslayer':hit(first,n+(first?.boss?20:0));break;
    case 'shift':if(first)first.override=['block',6];break;
    case 'copy':if(!replay&&s.lastSkill){const last=D.form(s.lastSkill.id);if(last)skill(s,last,target,s.lastSkill.level,true,boost)}break;
    case 'convert':s.weak=0;hit(first,n+s.transforms*3);break;
    case 'wild':s.wild=true;break;
    case 'mirror':hit(first,first&&intent(first).type==='attack'?intent(first).n:6);break;
    case 'burnBlock':{const b=s.block;s.block=0;hit(first,b*n);break}
    case 'rainbow':for(const e of alive(s))hit(e,new Set(s.suitHistory).size*n);break;
    case 'cleanse':s.weak=0;s.risk=Math.max(0,s.risk-10);break;
    case 'entangle':if(first){first.link=Math.max(first.link,n);first.vulnerable=Math.max(first.vulnerable,2)}break;
    case 'reset':for(const g of s.forms)if(g.id!==f.id)s.cooldowns[g.id]=0;break;
    case 'delay':if(first)first.override=['charge',1];break;
    case 'sameLaw':s.sameLaw=true;break;
    case 'trade':if(s.gold>=3){s.gold-=3;heal(s,power(n));block(s,power(n))}else block(s,3);break;
    case 'balance':{const lost=s.maxHp-s.hp;if(s.block<lost)block(s,Math.max(0,Math.ceil(lost/2)-s.block));else hit(first,s.block);break}
    case 'ward':s.ward=Math.max(s.ward,n);break;
    case 'loop':s.bonusEnergy=Math.min(2,s.bonusEnergy+1);break;
    case 'tax':if(first)first.tax+=n;break;
    case 'rewrite':if(first)first.override=['selfWeak',2];break;
    case 'emptyPower':hit(first,Math.max(1,s.slots-s.forms.length)*n);break;
    case 'contract':s.contract=true;break;
    case 'law':s.law=true;break;
    default:fail('未实现技能：'+op);
   }
  }
 }
 function bridge(s,from,to){
  let key=from+'>'+to,boost=0;if(s.wild&&from!=='JOKER'){from={S:'H',D:'S',C:'D',H:'C'}[to];key=from+'>'+to;s.wild=false}
  if(D.bridges[key]){s.stats.bridges++;emit(s,'bridge',{key,text:D.bridges[key]});log(s,D.bridges[key]);if(key==='H>S'){boost+=4;if(s.relics.includes('redThread')&&!s.usedRelics.includes('redThread')){boost+=5;s.usedRelics.push('redThread')}}if(key==='S>D')block(s,4);if(key==='D>C'&&!s.bridges.includes(key)){s.energy=Math.min(8,s.energy+1);s.bridges.push(key)}if(key==='C>H')heal(s,2)}
  if(s.sameLaw&&from===to&&!s.sameUsed){s.energy=Math.min(8,s.energy+1);s.sameUsed=true;log(s,'同源律：同花色返还1能量')}
  return boost;
 }
 function canTransform(s,id){const f=D.form(id);if(s.phase!=='battle')return '不在战斗中';if(!f||!s.forms.some(g=>g.id===id))return '尚未携带这个形态';if(s.energy<f.cost)return '能量不足';if((s.cooldowns[id]||0)>0)return '形态正在冷却';if((s.turnUses[id]||0)>=2)return '每种形态每回合最多使用两次';return ''}
 function transform(s,id,target){
  const reason=canTransform(s,id);if(reason)fail(reason);if(target&&!alive(s).some(e=>e.uid===target))fail('目标已经被击破');s.events=[];const f=D.form(id),g=s.forms.find(g=>g.id===id),prev=s.shape==='JOKER'?'JOKER':D.form(s.shape).s,repeat=s.shape===id;
  s.energy-=f.cost;s.cooldowns[id]=f.cooldown;s.turnUses[id]=(s.turnUses[id]||0)+1;s.transforms++;s.stats.transforms++;s.turnSuits.push(f.s);if(!s.suitHistory.includes(f.s))s.suitHistory.push(f.s);
  const echo=s.echo&&id!=='H-6'&&id!=='D-4';if(echo)s.echo=0;
  let boost=bridge(s,prev,f.s)+(repeat?2:0);s.shape=id;s.risk=Math.min(100,s.risk+[2,4,7,12][f.tier]);emit(s,'transform',{from:prev,id,suit:f.s});log(s,`Joker → ${f.name}：${D.description(f)}`);
  if(s.relics.includes('prism')&&f.s==='D'&&!s.usedRelics.includes('prism')){s.energy++;s.usedRelics.push('prism')}
  if(s.relics.includes('seal')&&f.s==='C'&&!s.bridges.includes('seal')){block(s,3);s.bridges.push('seal')}
  skill(s,f,target,g.level,false,boost);if(echo&&alive(s).length){skill(s,f,target,g.level,true,boost);log(s,'回声：技能再次发动')}
  if(!f.effects.some(e=>e[0]==='copy'||e[0]==='echo'))s.lastSkill={id,level:g.level};
  if(s.risk>=100){damagePlayer(s,10);s.risk=40;s.shape='JOKER';log(s,'失序反噬：受到10伤害，回归Joker，失序回落40');emit(s,'backlash')}
  finish(s);return s.events;
 }
 function revert(s){phase(s,'battle');if(s.reverted)fail('每回合只能主动回归一次');if(s.shape==='JOKER')fail('当前已经是Joker');s.events=[];s.reverted=true;s.shape='JOKER';s.energy=Math.min(8,s.energy+1);s.risk=Math.max(0,s.risk-5);if(s.relics.includes('brass'))block(s,4);emit(s,'revert');log(s,'回归Joker：能量+1，失序-5；本回合仅一次')}
 function endTurn(s){
  phase(s,'battle');s.events=[];
  for(const e of s.enemies){if(e.hp<=0)continue;if(e.stun){e.stun--;e.override=null;e.step++;log(s,e.name+'被定身，跳过行动');continue}
   const a=intent(e);emit(s,'intent',{uid:e.uid,action:a.type,n:a.n});
   if(a.type==='attack'){const n=Math.floor(a.n*(e.weak?.75:1));damagePlayer(s,n,{attack:true});log(s,e.name+'攻击 '+n);if(e.tax){s.gold+=2;e.tax--}if(s.reflect>0){const reflected=Math.min(s.reflect,n);s.reflect-=reflected;damage(s,e,reflected)}}
   if(a.type==='block'){e.block+=a.n;log(s,e.name+'获得'+a.n+'护盾')}
   if(a.type==='charge'){e.strength+=a.n;log(s,e.name+'蓄力，攻击+'+a.n)}
   if(a.type==='risk'){s.risk=Math.min(100,s.risk+a.n);log(s,e.name+'侵蚀：失序+'+a.n)}
   if(a.type==='weak'){if(!s.ward)s.weak=Math.max(s.weak,a.n+1);log(s,e.name+(s.ward?'的虚弱被免疫':'施加虚弱'))}
   if(a.type==='selfWeak')e.weak=Math.max(e.weak,a.n+1);
   e.step++;e.override=null;if(e.weak)e.weak--;if(e.vulnerable)e.vulnerable--;if(e.link)e.link--;
   if(s.hp<=0)break;
  }
  if(s.contract&&s.turnKills===0)damagePlayer(s,3);
  if(s.risk>=100){damagePlayer(s,10);s.risk=40;s.shape='JOKER';emit(s,'backlash');log(s,'失序反噬：受到10伤害')}
  if(s.relics.includes('candle'))s.risk=Math.max(0,s.risk-3);
  finish(s);if(s.phase!=='battle')return s.events;
  s.turn++;s.energy=3+s.bonusEnergy;s.bonusEnergy=0;s.block=0;s.barrier=false;s.law=false;s.reflect=0;s.sameLaw=false;s.sameUsed=false;s.reverted=false;s.contract=false;s.turnKills=0;s.transforms=0;s.bridges=[];s.turnUses={};s.turnSuits=[];if(s.weak)s.weak--;if(s.ward)s.ward--;for(const id of Object.keys(s.cooldowns))s.cooldowns[id]=Math.max(0,s.cooldowns[id]-1);log(s,'第'+s.turn+'回合：能量恢复，旧护盾消失');return s.events;
 }
 function unlock(s){
  const maxTier=s.floor>=12?3:s.floor>=8?2:s.floor>=4?1:0;
  const pool=D.forms.filter(f=>f.tier<=maxTier&&!s.metaUnlocks.includes(f.id));
  const picks=s.floor%4===0?3:1;
  for(let i=0;i<picks&&pool.length;i++){const top=s.floor%4===0&&i===0?pool.filter(f=>f.tier===maxTier):[],f=choose(s,top.length?top:pool),index=pool.indexOf(f);pool.splice(index,1);s.metaUnlocks.push(f.id);s.newUnlocks.push(f.id);log(s,'牌谱解锁：'+f.name+'，今后可能出现在奖励中')}
 }
 function makeOffers(s){
  const tier=s.floor>=12?3:s.floor>=8?2:s.floor>=4?1:0,pool=D.forms.filter(f=>f.tier<=tier&&s.metaUnlocks.includes(f.id)),off=[];
  for(let i=0;i<3;i++){const candidates=pool.filter(f=>!off.includes(f.id));if(!candidates.length)break;const weights=candidates.map(f=>[70,22,7,1][f.tier]),total=weights.reduce((a,b)=>a+b,0);let r=random(s)*total,index=0;for(;index<weights.length-1;index++){r-=weights[index];if(r<0)break}off.push(candidates[index].id)}
  if(s.floor%4===0){const high=pool.filter(f=>f.tier===tier&&!off.includes(f.id));if(high.length)off[off.length-1]=choose(s,high).id}
  return off;
 }
 function finish(s){
  if(s.hp<=0){s.phase='lost';emit(s,'lost');log(s,'本次登塔结束，已解锁牌谱可以保留');return}
  if(alive(s).length)return;
  s.stats.battles++;s.history.push({floor:s.floor,hp:s.hp,turns:s.turn});s.risk=Math.max(0,s.risk-15);s.gold+=s.floor%4===0?20:s.route==='danger'?14:8;if(s.relics.includes('heart'))heal(s,5);unlock(s);s.rewardChosen=false;
  if(s.floor===MAX_FLOORS){s.phase='won';emit(s,'won');return}
  s.phase='reward';s.offers=makeOffers(s);emit(s,'victory');log(s,'战斗胜利：选择一个形态或升级，再决定下一段路线');
  if(s.floor%4===0){const pool=D.relics.filter(r=>!s.relics.includes(r.id));if(pool.length){const r=choose(s,pool);s.relics.push(r.id);log(s,'首领奖励遗物：'+r.name);emit(s,'relic',{id:r.id})}s.slots=Math.min(8,6+Math.floor(s.floor/4));heal(s,8)}
 }
 function reward(s,id,replaceId){
  phase(s,'reward');if(s.rewardChosen)fail('已经选择奖励');if(id==='gold'){s.gold+=6;s.rewardChosen=true;log(s,'跳过形态，获得6金币');return}
  if(!s.offers.includes(id))fail('这张牌不在奖励中');const existing=s.forms.find(g=>g.id===id);
  if(existing){if(existing.level<2){existing.level++;log(s,D.form(id).name+'强化至+'+existing.level)}else{s.gold+=8;log(s,'已满级，转为8金币')}}
  else{if(s.forms.length>=s.slots){const index=s.forms.findIndex(g=>g.id===replaceId);if(index<0)fail('形态槽已满，请指定替换哪种形态');s.forms.splice(index,1)}s.forms.push({id,level:0});log(s,'获得形态：'+D.form(id).name)}s.rewardChosen=true;
 }
 function route(s,id){phase(s,'reward');if(!s.rewardChosen)fail('请先选择战斗奖励');if(!['safe','danger','camp','shop'].includes(id))fail('未知道路');if(id==='camp'&&s.gold<8)fail('扎营需要8金币');s.route=id;if(id==='camp'){s.gold-=8;heal(s,Math.ceil(s.maxHp*.22));s.risk=Math.max(0,s.risk-10);advance(s)}else if(id==='shop'){s.phase='shop';s.shop=[{kind:'heal',cost:10,sold:false},{kind:'upgrade',cost:14,sold:false},{kind:'relic',id:choose(s,D.relics.filter(r=>!s.relics.includes(r.id)))?.id||null,cost:20,sold:false}]}else advance(s)}
 function advance(s){s.floor++;battle(s)}
 function buy(s,index,id){phase(s,'shop');const item=s.shop[index];if(!item||item.sold||s.gold<item.cost)fail('金币不足或商品已售罄');if(item.kind==='upgrade'){const g=s.forms.find(g=>g.id===id);if(!g||g.level>=2)fail('请选择未满级形态');g.level++}if(item.kind==='heal')heal(s,20);if(item.kind==='relic'){if(!item.id)fail('遗物已经收集齐');s.relics.push(item.id)}s.gold-=item.cost;item.sold=true;log(s,'交易完成')}
 function leaveShop(s){phase(s,'shop');advance(s)}
 function settle(s,p){validateProfile(p);if(!['lost','won'].includes(s.phase))fail('冒险尚未结束');if(p.claims.includes(s.id))return clone(p);const next=clone(p);next.claims.push(s.id);next.runs++;if(s.phase==='won')next.wins++;next.best=Math.max(next.best,s.floor);next.ink+=s.stats.battles*2+(s.phase==='won'?12:0);next.unlocked=[...new Set([...next.unlocked,...s.metaUnlocks])];return next}
 function research(p,id){validateProfile(p);const f=D.form(id);if(!f||p.unlocked.includes(id))fail('这个形态已经解锁');const gates=[0,4,8,12],cost=[4,10,20,35][f.tier];if(p.best<gates[f.tier])fail('需要抵达第'+gates[f.tier]+'层才能研究');if(p.ink<cost)fail('研究墨水不足');const next=clone(p);next.ink-=cost;next.unlocked.push(id);return next}
 function preview(s,id,target){const copy=load(save(s));transform(copy,id,target);return copy}
 function save(s){const copy=clone(s);delete copy.events;return JSON.stringify(copy)}
 function load(raw){
  const s=JSON.parse(raw);if(!s||s.version!==VERSION||!['battle','reward','shop','lost','won'].includes(s.phase))fail('存档版本不兼容');
  if(!Array.isArray(s.forms)||s.forms.length>s.slots||s.forms.length<1||new Set(s.forms.map(g=>g.id)).size!==s.forms.length||s.forms.some(g=>!D.form(g.id)||!Number.isInteger(g.level)||g.level<0||g.level>2))fail('形态存档无效');
  for(const k of ['hp','maxHp','floor','gold','energy','risk','rng','turn','slots','block','strength','focus','rage','echo','reflect','weak','ward','bonusEnergy','bonusGold','transforms'])if(!Number.isFinite(s[k])||s[k]<0)fail('存档数值无效');
  if(s.hp>s.maxHp||s.floor<1||s.floor>MAX_FLOORS||s.risk>100||s.slots<6||s.slots>8||s.energy>8)fail('存档数值超限');
  if(!Array.isArray(s.enemies)||s.enemies.length>4||s.enemies.some(e=>!D.enemyTypes[e.type]||!Number.isFinite(e.hp)||e.hp<0||e.hp>e.maxHp||!Array.isArray(e.pattern)))fail('敌人存档无效');
  for(const key of ['metaUnlocks','newUnlocks'])if(!Array.isArray(s[key])||s[key].some(id=>!D.form(id)))fail('解锁记录无效');
  if(!Array.isArray(s.offers)||s.offers.some(id=>!D.form(id))||!Array.isArray(s.relics)||s.relics.some(id=>!D.relics.some(r=>r.id===id))||!Array.isArray(s.log)||s.log.some(t=>typeof t!=='string')||!Array.isArray(s.history)||!Array.isArray(s.events||[])||typeof s.id!=='string'||s.shape!=='JOKER'&&!D.form(s.shape))fail('存档结构无效');
  s.events=[];return s;
 }
 return {VERSION,MAX_FLOORS,newRun,profile,validateProfile,alive,intent,canTransform,transform,revert,endTurn,reward,route,buy,leaveShop,settle,research,save,load,preview};
})();
