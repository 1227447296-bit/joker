/* 所有形态的技能、稀有度与说明同源；引擎逐项执行，不按花色兜底。 */
const WanpaiData=(()=>{
 const suits={H:{name:'心灵',symbol:'♥',color:'#dd8393'},S:{name:'战斗',symbol:'♠',color:'#aebcde'},D:{name:'变化',symbol:'♦',color:'#e8b773'},C:{name:'规则',symbol:'♣',color:'#93cbb6'}};
 const forms=[];
 const add=(id,name,effects,opts={})=>{const [s,r]=id.split('-'),tier=r==='A'?3:['J','Q','K'].includes(r)?2:+r>=7?1:0;forms.push({id,s,r,name,tier,cost:tier===3?3:tier===2?2:1,cooldown:tier>=2?2:1,effects,...opts})};
 add('H-2','护念',[['block',6]]);
 add('H-3','共情',[['link',2],['block',3]]);
 add('H-4','宁神',[['heal',4],['risk',-6]]);
 add('H-5','灵光',[['focus',2],['block',2]]);
 add('H-6','回声',[['echo',1]]);
 add('H-7','镜湖',[['reflect',6],['block',5]]);
 add('H-8','安魂',[['weak',2],['heal',3]]);
 add('H-9','洞察',[['vulnerable',3],['focus',2]]);
 add('H-10','心海',[['mindburst',3]]);
 add('H-J','救赎',[['heal',10],['block',8]],{cost:2});
 add('H-Q','心链',[['linkAll',3],['weakAll',1]]);
 add('H-K','不动心',[['barrier',1],['risk',-15]]);
 add('H-A','梦境君主',[['stunAll',1],['heal',12],['focus',4]]);
 add('S-2','突刺',[['damage',7]]);
 add('S-3','连斩',[['hits',3,3]]);
 add('S-4','盾击',[['block',4],['shieldStrike',3]]);
 add('S-5','燃血',[['selfDamage',3],['damage',14]]);
 add('S-6','斩杀',[['execute',9]]);
 add('S-7','疾风',[['allDamage',6],['energy',1]]);
 add('S-8','怒涛',[['rage',3],['damage',8]]);
 add('S-9','蓄势',[['strength',3],['block',4]]);
 add('S-10','战鼓',[['allDamage',5],['strength',2]]);
 add('S-J','破军',[['shatter',1],['damage',23]]);
 add('S-Q','战利品',[['damage',17],['bounty',1]]);
 add('S-K','霸王',[['allDamage',18],['rage',4]]);
 add('S-A','弑神之刃',[['godslayer',32]]);
 add('D-2','置换',[['shift',1],['block',3]]);
 add('D-3','裂变',[['damage',4],['block',4]]);
 add('D-4','复制',[['copy',1]]);
 add('D-5','点金',[['damage',5],['gold',3]]);
 add('D-6','转化',[['convert',5]]);
 add('D-7','变色龙',[['wild',1],['block',5]]);
 add('D-8','镜像',[['mirror',1]]);
 add('D-9','熔铸',[['burnBlock',2]]);
 add('D-10','虹彩',[['rainbow',4]]);
 add('D-J','嬗变',[['cleanse',1],['energy',2],['damage',8]]);
 add('D-Q','炼金之心',[['heal',6],['gold',5],['block',9]]);
 add('D-K','量子纠缠',[['entangle',2],['damage',12]]);
 add('D-A','万象',[['allDamage',18],['energy',2],['reset',1]]);
 add('C-2','聚财',[['gold',4],['block',2]]);
 add('C-3','宽限',[['delay',1]]);
 add('C-4','同源律',[['sameLaw',1],['block',4]]);
 add('C-5','商人',[['trade',6]]);
 add('C-6','秩序',[['block',5],['risk',-8]]);
 add('C-7','天平',[['balance',1]]);
 add('C-8','抗灾',[['ward',2],['block',8]]);
 add('C-9','循环',[['loop',1]]);
 add('C-10','税收',[['tax',2],['block',5]]);
 add('C-J','规则改写',[['rewrite',1],['block',6]]);
 add('C-Q','虚席',[['emptyPower',5]]);
 add('C-K','契约之王',[['contract',1],['allDamage',12]]);
 add('C-A','立法者',[['law',1]]);
 const tiers=['初阶 · 2—6','进阶 · 7—10','王庭 · J—K','唯一 · A'];
 const relics=[
  {id:'redThread',name:'红线',desc:'每场首次红桃→黑桃额外造成5伤害。'},
  {id:'brass',name:'黄铜牌套',desc:'每次回归Joker额外获得4护盾。'},
  {id:'prism',name:'碎棱镜',desc:'每场第一次方块变身返还1能量。'},
  {id:'crown',name:'无主冠冕',desc:'每场开始获得1力量。'},
  {id:'candle',name:'静心烛',desc:'每回合结束降低3失序。'},
  {id:'heart',name:'玻璃心',desc:'每场战斗胜利回复5生命。'},
  {id:'hourglass',name:'沙漏',desc:'每场第一回合额外获得1能量。'},
  {id:'seal',name:'旧印章',desc:'每回合第一次梅花变身额外获得3护盾。'}
 ];
 const enemyTypes={
  sentinel:{name:'空壳守卫',hp:32,pattern:[['attack',7],['block',7],['attack',11]],art:'sentinel'},
  moth:{name:'窃梦蛾',hp:24,pattern:[['risk',5],['attack',6],['attack',9]],art:'moth'},
  hound:{name:'纸刃猎犬',hp:28,pattern:[['attack',5],['attack',8],['attack',11]],art:'hound'},
  scribe:{name:'禁言书记',hp:30,pattern:[['weak',1],['attack',8],['block',8]],art:'scribe'},
  knight:{name:'裂甲骑士',hp:54,pattern:[['block',12],['attack',15],['attack',9]],art:'knight',elite:true},
  collector:{name:'收牌人',hp:66,pattern:[['attack',10],['risk',8],['attack',19]],art:'collector',elite:true},
  bell:{name:'钟楼典狱长',hp:90,pattern:[['attack',9],['charge',5],['attack',20]],art:'bell',boss:true},
  queen:{name:'镜中皇后',hp:120,pattern:[['block',15],['attack',17],['risk',12],['attack',26]],art:'queen',boss:true},
  king:{name:'无面国王',hp:160,pattern:[['attack',16],['weak',2],['attack',30]],art:'king',boss:true},
  joker:{name:'第一位持牌者',hp:220,pattern:[['attack',18],['charge',6],['attack',35],['risk',15]],art:'joker',boss:true}
 };
 const starter=['H-2','S-2','D-3'];
 const initialUnlocks=['H-2','H-3','H-4','S-2','S-3','S-4','D-2','D-3','D-4','C-2','C-3','C-4'];
 const bridges={'H>S':'洞察：本次攻击额外+4','S>D':'破局：获得4护盾','D>C':'定形：返还1能量（每回合一次）','C>H':'归心：回复2生命'};
 function description(f){return f.effects.map(([op,n,t])=>({
  damage:`造成${n}伤害`,allDamage:`对所有敌人造成${n}伤害`,hits:`连续攻击${t}次，每次${n}伤害`,block:`获得${n}护盾`,heal:`回复${n}生命`,risk:`失序${n>0?'+':''}${n}`,focus:`获得${n}专注（下一次伤害增加）`,weak:`目标虚弱${n}回合（攻击-25%）`,weakAll:`所有敌人虚弱${n}回合`,vulnerable:`目标破绽${n}回合（受伤+25%）`,strength:`本场力量+${n}`,rage:`本场每次黑桃伤害额外+${n}`,energy:`恢复${n}能量`,gold:`获得${n}金币（每场最多12额外金币）`,selfDamage:`失去${n}生命（不穿过致死保护）`,link:`将目标标记${n}回合，伤害的50%传给其他被标记者`,linkAll:`所有敌人标记${n}回合`,echo:'下一种形态的直接技能结算两次（不可复制回声/复制类效果）',reflect:`本回合反射最多${n}点敌方攻击`,mindburst:`消耗全部专注，每点造成${n}伤害；至少造成6伤害`,barrier:'本回合受到的每次生命伤害最多为1',stunAll:'所有敌人跳过一次行动',shieldStrike:`造成当前护盾+${n}伤害`,execute:`造成${n}伤害；目标生命低于40%时翻倍`,shatter:'清除目标全部护盾',bounty:'本次击杀额外获得6金币',godslayer:`造成${n}伤害；对首领额外+20`,shift:'目标下一次行动改为防御6',copy:'重放上一次非复制形态的技能（不复制变身连锁）',convert:`清除自身虚弱，造成${n}+本回合变身次数×3伤害`,wild:'下一次花色连锁可将前置花色视作你需要的花色',mirror:'按目标攻击预告值造成伤害；非攻击预告时造成6伤害',burnBlock:`消耗全部护盾，每点造成${n}伤害`,rainbow:`本场每使用过一种花色，对全体造成${n}伤害`,cleanse:'清除自身虚弱，失序-10',entangle:`目标标记${n}回合，额外破绽2回合`,reset:'解除其他已装备形态本回合冷却，但每种形态每回合仍最多使用2次',delay:'目标下一次行动改为蓄力（只增加1攻击）',sameLaw:'本回合同花色变身返还1能量（最多一次）',trade:`支付3金币，回复${n}生命并获得${n}护盾；金币不足时只获3护盾`,balance:'护盾低于已损生命时补至已损生命的一半；否则造成护盾值伤害',ward:`虚弱免疫${n}回合`,loop:'下回合额外获得1能量（最多叠加2）',tax:`目标接下来${n}次攻击各返还2金币`,rewrite:'目标下一次行动改为虚弱自身2回合',emptyPower:`每个空装备槽提供${n}伤害；至少造成${n}伤害`,contract:'本回合击杀返还1能量；没有击杀则回合结束失去3生命',law:'本回合所有敌人的攻击最多造成5点原始伤害'
 }[op]||op)).join('；')}
 return {suits,forms,tiers,relics,enemyTypes,starter,initialUnlocks,bridges,description,form:id=>forms.find(f=>f.id===id)};
})();
