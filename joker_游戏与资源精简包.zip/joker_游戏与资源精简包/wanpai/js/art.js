/* 使用本地彩色功能牌作为异化敌人的本体，不依赖目录外资源。 */
const WanpaiArt={
 sentinel:'assets/cards-medium/color_yellow_empty.png',
 moth:'assets/cards-medium/color_purple_reverse.png',
 hound:'assets/cards-medium/color_red_draw.png',
 scribe:'assets/cards-medium/color_green_skip.png',
 knight:'assets/cards-medium/color_red_skip.png',
 collector:'assets/cards-medium/color_draw.png',
 bell:'assets/cards-medium/color_yellow_reverse.png',
 queen:'assets/cards-medium/color_purple_draw.png',
 king:'assets/cards-medium/color_wild.png',
 joker:'assets/cards-large/card_joker_black.png'
};
