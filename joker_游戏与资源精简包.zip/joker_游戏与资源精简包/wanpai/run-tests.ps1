param([string]$Chrome="C:\Program Files\Google\Chrome\Application\chrome.exe")
$ErrorActionPreference='Stop'
$node=Join-Path $env:USERPROFILE 'nodejs-v24\node.exe'
if (-not (Test-Path $node)) { $node='node' }
& $node (Join-Path $PSScriptRoot 'tests\engine-tests.cjs')
if ($LASTEXITCODE -ne 0) { throw 'Engine tests failed' }
if (-not (Test-Path $Chrome)) { throw 'Chrome not found; pass -Chrome with a Chromium browser path' }
$profile=Join-Path $env:TEMP ('wanpai-test-'+[guid]::NewGuid().ToString('N'))
$out=Join-Path $PSScriptRoot 'tests\browser-output.html'
$err=Join-Path $PSScriptRoot 'tests\browser-stderr.log'
$url=([System.Uri](Join-Path $PSScriptRoot 'tests\browser-tests.html')).AbsoluteUri
$args=@('--headless=new','--disable-gpu','--no-first-run','--allow-file-access-from-files','--disable-background-timer-throttling','--virtual-time-budget=25000','--dump-dom',('--user-data-dir="'+$profile+'"'),$url)
try {
 $proc=Start-Process -FilePath $Chrome -ArgumentList $args -RedirectStandardOutput $out -RedirectStandardError $err -Wait -PassThru
 if ($proc.ExitCode -ne 0) { throw ('Chrome exited '+$proc.ExitCode) }
 $text=[System.IO.File]::ReadAllText($out)
 $match=[regex]::Match($text,'<pre id="result">([\s\S]*?)</pre>')
 if (-not $match.Success) { throw 'No browser report' }
 $json=[System.Net.WebUtility]::HtmlDecode($match.Groups[1].Value)
 $report=$json|ConvertFrom-Json
 $json
 if ($report.status -ne 'ALL_PASS') { throw 'Browser tests failed; see tests/browser-output.html' }
} finally {
 if (Test-Path $profile) { try { Remove-Item -LiteralPath $profile -Recurse -Force -Confirm:$false -ErrorAction Stop } catch { Write-Warning 'Temporary Chrome profile is still in use.' } }
}
