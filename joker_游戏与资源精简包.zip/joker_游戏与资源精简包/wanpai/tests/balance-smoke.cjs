/* 使用公开操作自动试玩；不修改生命、能量、敌人或掉落。它不是人类趣味性测试。 */
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');const c=vm.createContext({});for(const f of ['data.js','engine.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'../js',f),'utf8'),c);const E=vm.runInContext('WanpaiEngine',c),D=vm.runInContext('WanpaiData',c);
function value(s){return s.hp*2.8+s.stats.damage*.7+s.kills*7+s.stats.battles*100+s.strength*3+s.rage*2+s.focus*.5-s.risk*.08+(s.phase==='won'?1000:s.phase==='lost'?-1000:0)}
function bestTurn(s,depth=0){const end=E.load(E.save(s));E.endTurn(end);let best={score:value(end),move:['end']};if(depth>=2)return best;const options=[];for(const g of s.forms)if(!E.canTransform(s,g.id))for(const e of E.alive(s))options.push(['transform',g.id,e.uid]);if(s.shape!=='JOKER'&&!s.reverted)options.push(['revert']);for(const move of options){const n=E.load(E.save(s));if(move[0]==='revert')E.revert(n);else E.transform(n,move[1],move[2]);const score=n.phase==='battle'?bestTurn(n,depth+1).score:value(n);if(score>best.score)best={score,move}}return best}
function cardValue(id){const f=D.form(id);const scores={damage:9,allDamage:16,hits:12,block:7,heal:18,strength:23,rage:20,energy:16,shift:15,delay:10,copy:13,echo:12,ward:2,law:12,godslayer:20,execute:13,rainbow:18,shieldStrike:14,convert:12,burnBlock:8,mirror:10};return f.effects.reduce((n,e)=>n+(scores[e[0]]||2),0)/f.cost}
const reports=[];for(let seed=0;seed<3;seed++){
 const s=E.newRun('natural-'+seed);let commands=0;
 while(['battle','reward','shop'].includes(s.phase)&&commands<1800){commands++;
  if(s.phase==='battle'){const move=bestTurn(s).move;if(move[0]==='end')E.endTurn(s);else if(move[0]==='revert')E.revert(s);else E.transform(s,move[1],move[2])}
  else if(s.phase==='reward'){if(!s.rewardChosen){const id=s.offers.slice().sort((a,b)=>cardValue(b)-cardValue(a))[0],worst=s.forms.slice().sort((a,b)=>cardValue(a.id)-cardValue(b.id))[0];if(s.forms.length>=s.slots&&!s.forms.some(g=>g.id===id)&&cardValue(id)<cardValue(worst.id))E.reward(s,'gold');else E.reward(s,id,worst.id)}else E.route(s,s.hp<s.maxHp-12&&s.gold>=8?'camp':'safe')}
 }
 reports.push({seed:s.seed,outcome:s.phase,floor:s.floor,battles:s.stats.battles,commands,forms:s.forms.map(g=>g.id+'+'+g.level),hp:s.hp});
}
console.log(JSON.stringify(reports,null,2));if(reports.some(r=>r.commands>=1800))process.exitCode=1;
