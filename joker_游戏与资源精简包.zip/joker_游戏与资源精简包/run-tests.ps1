# Windows PowerShell 5.1. A temporary browser profile protects normal saves.
$ErrorActionPreference = 'Stop'
$browser = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $browser) { throw 'Chrome or Edge is required to run browser tests.' }
$work = Join-Path ([IO.Path]::GetTempPath()) ('joker-tests-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
try {
  foreach ($suite in @(@{Page='tests.html'; Output='test-output.html'}, @{Page='ui-tests.html'; Output='ui-test-output.html'}, @{Page='loom-tests.html'; Output='loom-test-output.html'})) {
    $url = ([Uri](Join-Path $PSScriptRoot $suite.Page)).AbsoluteUri
    $out = Join-Path $PSScriptRoot $suite.Output
    $args = @('--headless=new', '--disable-gpu', '--no-first-run', '--allow-file-access-from-files', ('--user-data-dir="' + (Join-Path $work 'profile') + '"'), '--virtual-time-budget=12000', '--dump-dom', $url)
    $process = Start-Process -FilePath $browser -ArgumentList $args -RedirectStandardOutput $out -RedirectStandardError (Join-Path $work ($suite.Page + '.log')) -Wait -PassThru -NoNewWindow
    if ($process.ExitCode -ne 0) { throw ($suite.Page + ' browser exit: ' + $process.ExitCode) }
    $html = [IO.File]::ReadAllText($out, [Text.Encoding]::UTF8)
    $match = [regex]::Match($html, '<pre id="result">([\s\S]*?)</pre>')
    if (-not $match.Success) { throw ($suite.Page + ' did not produce a report') }
    $report = [Net.WebUtility]::HtmlDecode($match.Groups[1].Value) | ConvertFrom-Json
    if ($report.status -ne 'ALL_PASS') {
      $report.results | Where-Object { -not $_.pass } | Format-List
      throw ($suite.Page + ' FAILED')
    }
    '{0}: {1}/{2} ALL_PASS' -f $suite.Page, $report.passed, $report.total
  }
} finally {
  # Only remove the random temporary directory created by this script.
  try { Remove-Item -LiteralPath $work -Recurse -Force -Confirm:$false -ErrorAction Stop } catch { Write-Warning ('Temporary browser profile still in use: ' + $work) }
}
