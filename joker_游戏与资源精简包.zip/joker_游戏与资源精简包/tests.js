(() => {
  const E=JokerEngine,results=[],stats={};
  function assert(v,msg='断言失败'){if(!v)throw Error(msg);}
  function equal(a,b,msg=''){assert(JSON.stringify(a)===JSON.stringify(b),msg+' '+JSON.stringify(a)+' !== '+JSON.stringify(b));}
  function throws(fn){let threw=false;try{fn();}catch(e){threw=true;}assert(threw,'应当拒绝此操作');}
  function test(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
  function rig(ids=[],tier=0){const s=E.newRun('test','H-5');s.act=8;s.gods=ids.map(id=>({id,tier}));s.log=[];return s;}
  function hand(s,codes){const used=[];for(const code of codes){const [suit,r]=code.split('-');const c=s.deck.find(c=>c.s===suit&&c.r===r&&!used.includes(c.uid));assert(c,'测试凡牌缺失 '+code);used.push(c.uid);}s.hand=used;s.draw=s.deck.map(c=>c.uid).filter(id=>!used.includes(id));s.discard=[];return used;}
  function fixtureCards(codes){return codes.map((str,i)=>{const [s,r]=str.split('-');return {s,r,uid:i,ink:'plain'};});}
  test('四个双牌开局有明确资源且同种子复现',()=>{for(const [id,k] of Object.entries(E.STARTERS)){const s=E.startAdventure('kit',id);equal(s.gods.map(g=>g.id),[id,k.companion]);equal(s.res[k.resource],k.amount);equal(E.save(s),E.save(E.startAdventure('kit',id)));s.phase='shop';E.next(s);equal(s.res[k.resource],k.amount);}throws(()=>E.startAdventure('bad','H-A'));});
  test('红桃回声重复真实点数/铭刻/资源，且只持续一手',()=>{const s=rig();s.relics=[];s.res.mind=3;const ids=hand(s,['H-K']);E.card(s,ids[0]).ink='chips';E.prepare(s,'echo',ids[0]);equal(s.res.mind,0);const saved=E.load(E.save(s));equal(saved.tactics.echoUid,ids[0]);E.play(s,ids);equal(s.lastScore.total,85);equal(s.res.mind,2);equal(s.tactics,{echoUid:null,rally:false});});
  test('标记未成型牌/封印牌不会获得回声分数',()=>{for(const seal of [false,true]){const s=rig();s.relics=[];s.res.mind=3;const ids=hand(s,seal?['D-Q']:['S-8','C-8','H-Q']);if(seal){s.act=3;s.blind=2;}E.prepare(s,'echo',ids[ids.length-1]);const clean=E.load(E.save(s));clean.tactics.echoUid=null;equal(E.play(s,ids).total,E.play(clean,ids).total);equal(s.tactics.echoUid,null);}});
  test('黑桃爆发花2能量换下一手+5倍数，重复准备原子拒绝',()=>{const s=rig();s.res.will=2;E.prepare(s,'rally');equal(s.res.will,0);const before=E.save(s);throws(()=>E.prepare(s,'rally'));equal(E.save(s),before);const ids=hand(s,['S-K']);equal(E.play(s,ids).mult,6);equal(s.tactics.rally,false);});
  test('策略资源不足/非法目标/阶段错误均不扣费',()=>{const s=rig();for(const fn of [()=>E.prepare(s,'echo',999),()=>E.prepare(s,'echo',s.hand[0]),()=>E.prepare(s,'rally'),()=>E.prepare(s,'invalid')]){const before=E.save(s);throws(fn);equal(E.save(s),before);}s.res.mind=3;s.phase='shop';const before=E.save(s);throws(()=>E.prepare(s,'echo',s.hand[0]));equal(E.save(s),before);});
  test('弃掉标记牌取消回声；旧存档补齐策略，坏策略拒绝',()=>{const s=rig();s.res.mind=3;E.prepare(s,'echo',s.hand[0]);E.discard(s,[s.hand[0]]);equal(s.tactics.echoUid,null);const old=JSON.parse(E.save(s));delete old.tactics;equal(E.load(JSON.stringify(old)).tactics,{echoUid:null,rally:false});old.tactics={echoUid:999,rally:false};throws(()=>E.load(JSON.stringify(old)));old.tactics={echoUid:null,rally:5};throws(()=>E.load(JSON.stringify(old)));});
  test('改牌同花教学真实触发转化+变色龙并补充改牌资源',()=>{const s=E.startAdventure('lesson','D-6'),ids=hand(s,['D-2','D-5','D-9','D-K','S-Q']);const before=E.save(s);const copy=E.load(before);E.transform(copy,ids[4],'suit','D');const result=E.play(copy,ids);equal(result.type,'flush');equal(copy.blindState.spent,1);equal(copy.res.plastic,7);assert(copy.log.some(x=>x.startsWith('转化 →')));assert(copy.log.some(x=>x.startsWith('变色龙 →')));assert(result.total>E.play(E.load(before),ids).total);equal(E.save(s),before);});
  test('双牌冒险首手保底四张路线花色，红桃回声与开局加成正向配合',()=>{for(const id of Object.keys(E.STARTERS)){const s=E.startAdventure('opening',id);equal(s.hand.map(uid=>E.card(s,uid)).filter(c=>c.s===id[0]).length,4);equal(new Set([...s.hand,...s.draw]).size,52);equal(E.target(s),360);}const a=E.startAdventure('echo','H-5');const uid=a.hand.find(id=>E.card(a,id).s==='H'),b=E.load(E.save(a));E.prepare(b,'echo',uid);assert(E.play(b,[uid]).total>E.play(a,[uid]).total,'回声不应削弱开局加成');});
  test('默认52张规则验证 / ID唯一',()=>{assert(RULES.validate(RULES.cards));equal(new Set(RULES.cards.map(c=>c.id)).size,52);});
  test('标准52张凡牌与三区唯一性',()=>{const s=E.newRun('a');equal(s.deck.length,52);equal(s.hand.length,8);equal(new Set([...s.hand,...s.draw,...s.discard]).size,52);});
  test('相同种子与操作完全复现',()=>{const a=E.newRun('固定'),b=E.newRun('固定');equal(E.save(a),E.save(b));E.play(a,a.hand.slice(0,3));E.play(b,b.hand.slice(0,3));equal(E.save(a),E.save(b));});
  test('A2345 / 10JQKA / 四张同花 / 五条 / 同花五条',()=>{
    equal(E.evaluate(fixtureCards(['H-A','S-2','D-3','C-4','H-5'])).type,'straight');
    equal(E.evaluate(fixtureCards(['H-10','H-J','H-Q','H-K','H-A'])).type,'sf');
    equal(E.evaluate(fixtureCards(['H-2','H-5','H-8','H-J']),{fourFlush:true}).type,'flush');
    equal(E.evaluate(fixtureCards(['H-A','H-A','S-A','D-A','C-A'])).type,'five');
    equal(E.evaluate(fixtureCards(['H-A','H-A','H-A','H-A','H-A'])).type,'ff');
  });
  test('预览是纯函数，不推进随机数/资源/日志',()=>{const s=rig(),before=E.save(s);E.preview(s,s.hand.slice(0,5));equal(E.save(s),before);});
  test('空选择/重复选择/牌外ID均被拒绝',()=>{const s=rig();throws(()=>E.play(s,[]));throws(()=>E.play(s,[s.hand[0],s.hand[0]]));throws(()=>E.play(s,[999]));});
  test('基础皇家同花顺准确为151×8=1208',()=>{const s=rig();E.play(s,hand(s,['H-10','H-J','H-Q','H-K','H-A']));equal(s.lastScore.total,1208);});
  test('留手不包含已打出的牌',()=>{const s=rig(['H-3']);E.play(s,hand(s,['H-2']));equal(s.lastScore.mult,1);});
  test('弃牌不会误触发计分神牌 / 产生旧分数',()=>{const s=rig(['H-5']);const score=s.score;E.discard(s,s.hand.slice(0,2));equal(s.score,score);assert(!s.log.some(x=>x.includes('灵光 → 灵能')));});
  test('四相导线成环依然有界 / 不残留事件',()=>{const s=rig(['H-7'],1);s.relics=['empathy','forge','contract','return','echo'];s.res={mind:0,will:0,plastic:0,law:0};E.discard(s,hand(s,['H-2','H-3','H-4','H-5','H-6']));assert(s.queue.length===0);assert(s.flow.used.length<=4);assert(s.flow.budget>=0);for(const k of Object.keys(s.res))assert(s.res[k]<=E.cap(s,k));});
  test('银读心者不会递归计分',()=>{const s=rig(['H-A'],1);hand(s,['H-2','H-3','H-4','S-8']);E.play(s,[s.hand[3]]);assert(s.log.filter(x=>x.startsWith('读心者 → 乘算倍率')).length===1);equal(s.queue.length,0);});
  test('按卡位顺序：先加算后乘算与反向不同',()=>{const a=rig(['S-2','C-7']),b=rig(['C-7','S-2']);E.play(a,hand(a,['S-2']));E.play(b,hand(b,['S-2']));assert(a.lastScore.mult>b.lastScore.mult);});
  test('复刻禁用 / 品质上限 / 失序反噬',()=>{const s=rig(['C-2']);throws(()=>E.setMirror(s,'C-2'));s.gods=[{id:'S-2',tier:4}];s.disorder=99;E.setMirror(s,'S-2');equal(s.disorder,40);equal(s.mirror,null);equal(s.gold,4);});
  test('复刻不会复制同源：铜Joker复刻上限银',()=>{const a=rig(['S-2'],4),b=rig(['S-2'],4);E.setMirror(b,'S-2');E.play(a,hand(a,['S-2']));E.play(b,hand(b,['S-2']));assert(b.lastScore.mult>a.lastScore.mult);assert(b.log.some(x=>x.includes('锋刃·复刻')));assert(!b.log.some(x=>x.includes('复刻·同源')));});
  test('弃牌清战意 / 怒涛保留',()=>{const a=rig(),b=rig(['S-8']);a.res.will=5;b.res.will=5;E.discard(a,a.hand.slice(0,1));E.discard(b,b.hand.slice(0,1));equal(a.res.will,0);equal(b.res.will,5);});
  test('永久变相花费可塑 / 改动持久牌组',()=>{const s=rig(['D-6']);const uid=hand(s,['H-2'])[0];E.transform(s,uid,'rank','A');equal(E.card(s,uid).r,'A');equal(s.res.plastic,1);equal(s.blindState.spent,1);E.play(s,[uid]);assert(s.lastScore.chips>=31);});
  test('无效变相不会扣资源',()=>{const s=rig();const uid=s.hand[0],before=E.save(s);throws(()=>E.transform(s,uid,'rank',E.card(s,uid).r));equal(E.save(s),before);});
  test('永久复制每劫限一次且新UID独立',()=>{const s=rig(['D-4']),uid=s.hand[0];E.transform(s,uid,'copy');equal(s.deck.length,53);equal(new Set(s.deck.map(c=>c.uid)).size,53);throws(()=>E.transform(s,uid,'copy'));});
  test('律令消费真实律能并限制重复颁布',()=>{const s=rig();s.res.law=6;E.enact(s,'flush');equal(s.res.law,4);throws(()=>E.enact(s,'flush'));equal(E.preview(s,hand(s,['H-2','H-5','H-8','H-J'])).type,'flush');});
  test('旁证法使陪打牌提供点数与资源',()=>{const a=rig(),b=rig();b.res.law=2;E.enact(b,'kicker');E.play(a,hand(a,['H-2','S-2','D-A']));E.play(b,hand(b,['H-2','S-2','D-A']));assert(b.lastScore.chips-a.lastScore.chips===11);assert(b.res.plastic>a.res.plastic);});
  test('噬心封印不产红桃资源；安魂可解封',()=>{const a=rig(),b=rig(['H-8']);a.act=b.act=1;a.blind=b.blind=2;E.play(a,hand(a,['H-A']));E.play(b,hand(b,['H-A']));equal(a.res.mind,0);equal(b.res.mind,1);});
  test('断刃/凝滞封印对应花色',()=>{for(const [act,code,res] of [[2,'S-A','will'],[3,'D-A','plastic']]){const s=rig();s.act=act;s.blind=2;const before=s.res[res];E.play(s,hand(s,[code]));equal(s.res[res],before);}});
  test('轮转沉默不累积到下一手',()=>{const s=rig(['S-2','S-3']);s.act=4;s.blind=2;E.play(s,hand(s,['S-2']));assert(s.log.some(x=>x==='锋刃：本手被沉默'));E.play(s,hand(s,['S-3']));assert(s.log.some(x=>x==='连斩：本手被沉默'));assert(s.log.some(x=>x.startsWith('锋刃 →')));});
  test('断流保留0.5基础倍率',()=>{const s=rig();s.act=5;s.blind=2;E.play(s,hand(s,['H-2']));equal(s.lastScore.mult,.5);});
  test('审判庭重复牌型得分0',()=>{const s=rig();s.act=6;s.blind=2;E.play(s,hand(s,['H-2']));E.play(s,hand(s,['H-3']));equal(s.lastScore.total,0);});
  test('镜之魔禁止复制并加变相失序',()=>{const s=rig(['H-5']);s.act=7;s.blind=2;throws(()=>E.setMirror(s,'H-5'));const uid=s.hand[0];E.transform(s,uid,'rank',E.card(s,uid).r==='A'?'K':'A');equal(s.disorder,2);});
  test('终焉单手35%上限',()=>{const s=rig();s.blind=2;s.levels.sf=1000;E.play(s,hand(s,['H-10','H-J','H-Q','H-K','H-A']));equal(s.lastScore.total,Math.floor(E.target(s)*.35));equal(s.phase,'blind');});
  test('救赎补回一次出牌；失败结算不发经济奖励',()=>{const s=rig(['H-J','C-2']);s.plays=1;s.score=E.target(s)*.6;const before=s.gold;E.play(s,hand(s,['H-2']));equal(s.plays,1);equal(s.gold,before);E.play(s,hand(s,['H-3']));equal(s.phase,'lost');equal(s.gold,before);});
  test('不能在劫局中买牌/升阶/跳关',()=>{const s=rig();throws(()=>E.buy(s,0));throws(()=>E.upgrade(s,'H-5'));throws(()=>E.next(s));});
  test('奖励只结算一次，不能通关后再出牌',()=>{const s=rig();s.act=1;s.score=E.target(s);E.play(s,s.hand.slice(0,1));const before=s.gold;throws(()=>E.play(s,s.hand.slice(0,1)));equal(s.gold,before);equal(s.phase,'route');E.route(s,'market');throws(()=>E.route(s,'market'));});
  test('商品售罄不可重购，刷新真实扣费',()=>{const s=rig();s.phase='route';E.route(s,'market');s.gold=100;const i=s.shop.findIndex(x=>x.kind==='shard');E.buy(s,i);throws(()=>E.buy(s,i));const before=s.gold;E.refresh(s);equal(s.gold,before-3);equal(s.refresh,1);});
  test('升阶/唯一神座/高阶代价显示',()=>{const s=rig(['H-5','S-2'],3);s.phase='shop';s.gold=100;s.shards=100;E.upgrade(s,'H-5');equal(s.gods[0].tier,4);throws(()=>E.upgrade(s,'S-2'));assert(RULES.describe(E.def(s,'H-5'),4).includes('代价'));});
  test('星辰/永久铭刻/焚牌与消耗品栏',()=>{const s=rig();s.bag=['star','etch','erase'];E.use(s,0);equal(s.levels.pair,2);const uid=s.hand[0];E.use(s,0,uid);equal(E.card(s,uid).ink,'chips');E.use(s,0,uid);equal(s.deck.length,51);equal(s.bag.length,0);});
  test('存档加载后下一步与原状态一致',()=>{const a=rig(['H-5']);E.play(a,a.hand.slice(0,2));const b=E.load(E.save(a));E.play(a,a.hand.slice(0,3));E.play(b,b.hand.slice(0,3));equal(E.save(a),E.save(b));});
  test('拒绝损坏存档和非法规则配置',()=>{const s=rig(),x=JSON.parse(E.save(s));x.deck[0].uid=x.deck[1].uid;throws(()=>E.load(JSON.stringify(x)));const rules=JSON.parse(JSON.stringify(RULES.cards));rules[0].base.op='eval';throws(()=>RULES.validate(rules));rules[0].base.op='chips';rules[0].base.n=Infinity;throws(()=>RULES.validate(rules));});
  test('260张五阶神牌事件烟测：真实引擎无NaN / 队列清空',()=>{let n=0;for(const d of RULES.cards)for(let tier=0;tier<5;tier++){
    const s=rig([d.id],tier);s.phase='shop';E.next(s);s.res={mind:5,will:5,plastic:5,law:4};s.laws=['flush','kicker'];E.play(s,hand(s,['H-A','S-A','D-A','C-A','H-2']));assert(Number.isFinite(s.lastScore.total),d.id+' tier '+tier);assert(s.queue.length===0,d.id+' 队列残留');if(s.phase==='blind'){E.discard(s,s.hand.slice(0,1));s.score=E.target(s);E.play(s,s.hand.slice(0,1));}assert(Number.isFinite(s.gold)&&s.queue.length===0,d.id+' 结束事件异常');n++;
  }stats.tierCases=n;});
  test('24劫完整状态机夹具（非自然平衡通关）',()=>{const s=E.newRun('完整流程');s.gold=10000;s.shards=1000;for(const k of Object.keys(s.levels))s.levels[k]=1000;let guard=200;while(!['won','lost'].includes(s.phase)&&guard--){if(s.phase==='blind')E.play(s,s.hand.slice(0,5));else if(s.phase==='route')E.route(s,'market');else if(s.phase==='shop')E.next(s);}equal(s.phase,'won');equal(s.stats.blinds,24);stats.fullRunHands=s.stats.hands;});
  test('20种子常规规则自动探索（不注入资源，记录可达性）',()=>{let sum=0,best=0;for(let i=0;i<20;i++){const s=E.newRun('balance-'+i,['H-5','S-2','D-6','C-9'][i%4]);let guard=150;while(!['won','lost'].includes(s.phase)&&guard--){if(s.phase==='blind'){
      const handIds=s.hand;let choice=[handIds[0]],weight=-1;for(let mask=1;mask<(1<<handIds.length);mask++){const ids=handIds.filter((_,j)=>mask&(1<<j));if(ids.length>5)continue;const ev=E.preview(s,ids),h=E.HANDS[ev.type],w=(h[1]+ev.scoring.reduce((n,c)=>n+(c.r==='A'?11:['J','Q','K'].includes(c.r)?10:+c.r),0))*h[2];if(w>weight){choice=ids;weight=w;}}
      E.play(s,choice);
    }else if(s.phase==='route')E.route(s,'forge');else {const g=s.gods[0],cost=E.upgradeCost(g);if(g.tier<4&&s.gold>=cost.gold&&s.shards>=cost.shards)E.upgrade(s,g.id);E.next(s);}}
    assert(guard>0,'自动探索未终止');assert(Number.isFinite(s.stats.score));sum+=s.stats.blinds;best=Math.max(best,s.stats.blinds);
  }stats.autoplay={runs:20,averageBlinds:sum/20,bestBlinds:best,note:'简陋策略，不购买协同神牌/圣物、不用弃牌；不作为人工通关或平衡结论'};});
  const report={status:results.every(x=>x.pass)?'ALL_PASS':'FAILED',passed:results.filter(x=>x.pass).length,total:results.length,stats,results};document.getElementById('result').textContent=JSON.stringify(report,null,2);document.title=report.status+' '+report.passed+'/'+report.total;window.TEST_REPORT=report;
})();
